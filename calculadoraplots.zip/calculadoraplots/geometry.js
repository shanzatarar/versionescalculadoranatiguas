function isPointInTriangle(p, p0, p1, p2) {
    const A = 0.5 * (-p1.y * p2.x + p0.y * (-p1.x + p2.x) + p0.x * (p1.y - p2.y) + p1.x * p2.y);
    const sign = A < 0 ? -1 : 1;
    const s = (p0.y * p2.x - p0.x * p2.y + (p2.y - p0.y) * p.x + (p0.x - p2.x) * p.y) * sign;
    const t = (p0.x * p1.y - p0.y * p1.x + (p0.y - p1.y) * p.x + (p1.x - p0.x) * p.y) * sign;
    const area2 = 2 * Math.abs(A);
    const eps = 1e-6;
    return s >= -eps && t >= -eps && (s + t) <= area2 + eps;
}

function distToSegment(p, v, w) {
    const l2 = (v.x - w.x)**2 + (v.y - w.y)**2;
    if (l2 === 0) return Math.sqrt((p.x - v.x)**2 + (p.y - v.y)**2);
    let t = ((p.x - v.x) * (w.x - v.x) + (p.y - v.y) * (w.y - v.y)) / l2;
    t = Math.max(0, Math.min(1, t));
    return Math.sqrt((p.x - (v.x + t * (w.x - v.x)))**2 + (p.y - (v.y + t * (w.y - v.y)))**2);
}

function updateTriangulation() {
    triangles = [];
    const N = points.length;
    if (N < 3) return;
    let vertices = points.map((p, i) => ({ x: p.x, y: p.y, z: p.z, id: i }));
    drainagePoints.forEach((p, i) => {
        vertices.push({ x: p.x, y: p.y, z: p.z, id: N + i });
    });
    const minX = Math.min(...vertices.map(p => p.x)) - 1000;
    const minY = Math.min(...vertices.map(p => p.y)) - 1000;
    const maxX = Math.max(...vertices.map(p => p.x)) + 1000;
    const maxY = Math.max(...vertices.map(p => p.y)) + 1000;

    const superTriangle = [
        { x: minX, y: minY, id: -1 },
        { x: maxX + (maxX - minX), y: minY, id: -2 },
        { x: minX, y: maxY + (maxY - minY), id: -3 }
    ];
    let tempTriangles = [superTriangle];
    for (let point of vertices) {
        let badTriangles = [];
        for (let tri of tempTriangles) {
            if (isPointInCircumcircle(point, tri[0], tri[1], tri[2])) {
                badTriangles.push(tri);
            }
        }

        let polygon = [];
        for (let tri of badTriangles) {
            for (let i = 0; i < 3; i++) {
                let edge = { a: tri[i], b: tri[(i + 1) % 3] };
                let isShared = false;
                for (let otherTri of badTriangles) {
                    if (tri === otherTri) continue;
                    for (let j = 0; j < 3; j++) {
                        let otherEdge = { a: otherTri[j], b: otherTri[(j + 1) % 3] };
                        if ((edge.a.id === otherEdge.a.id && edge.b.id === otherEdge.b.id) ||
                            (edge.a.id === otherEdge.b.id && edge.b.id === otherEdge.a.id)) {
                            isShared = true;
                            break;
                        }
                    }
                    if (isShared) break;
                }
                if (!isShared) polygon.push(edge);
            }
        }
        tempTriangles = tempTriangles.filter(t => !badTriangles.includes(t));
        for (let edge of polygon) {
            tempTriangles.push([edge.a, edge.b, point]);
        }
    }
    triangles = [];
    for (let tri of tempTriangles) {
        if (tri[0].id < 0 || tri[1].id < 0 || tri[2].id < 0) continue;
        const cx = (tri[0].x + tri[1].x + tri[2].x) / 3;
        const cy = (tri[0].y + tri[1].y + tri[2].y) / 3;
        const sumideroCount = tri.filter(v => v.id >= N).length;
        if (sumideroCount >= 2 || isPointInPoly(cx, cy)) {
             triangles.push({ v: [tri[0].id, tri[1].id, tri[2].id] });
        }
    }
}

function isPointInCircumcircle(p, a, b, c) {
    const adx = a.x - p.x;
    const ady = a.y - p.y;
    const bdx = b.x - p.x;
    const bdy = b.y - p.y;
    const cdx = c.x - p.x;
    const cdy = c.y - p.y;

    const abdet = adx * bdy - bdx * ady;
    const bcdet = bdx * cdy - cdx * bdy;
    const cadet = cdx * ady - adx * cdy;
    const alift = adx * adx + ady * ady;
    const blift = bdx * bdx + bdy * bdy;
    const clift = cdx * cdx + cdy * cdy;

    return (alift * bcdet + blift * cadet + clift * abdet) > 0;
}

function isPointInPolyOrBorder(x, y) {
    if (isPointInPoly(x, y)) return true;
    const tol = 2; 
    for (let i = 0, j = points.length - 1; i < points.length; j = i++) {
        const a = points[j];
        const b = points[i];
        if (distToSegment({x, y}, a, b) <= tol) return true;
    }
    return false;
}

function isPointInPoly(x, y) {
    let inside = false;
    for (let i = 0, j = points.length - 1; i < points.length; j = i++) {
        const xi = points[i].x, yi = points[i].y;
        const xj = points[j].x, yj = points[j].y;
        const intersect = ((yi > y) !== (yj > y)) && (x < (xj - xi) * (y - yi) / (yj - yi) + xi);
        if (intersect) inside = !inside;
    }
    return inside;
}

