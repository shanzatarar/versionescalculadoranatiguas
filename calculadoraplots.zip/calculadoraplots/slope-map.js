const slopeCanvas = document.getElementById('slopeCanvas');
const sCtx = slopeCanvas ? slopeCanvas.getContext('2d') : null;

function setupSlopeCanvasResolution() {
    if (!slopeCanvas || !sCtx) return;
    const rect = slopeCanvas.getBoundingClientRect();
    const logicalWidth = rect.width || 300;
    const logicalHeight = rect.height || 200;
    slopeCanvas.width = logicalWidth * DPR;
    slopeCanvas.height = logicalHeight * DPR;
    sCtx.setTransform(DPR, 0, 0, DPR, 0, 0);
    if (typeof sCtx.imageSmoothingEnabled !== 'undefined') sCtx.imageSmoothingEnabled = true;
    try { sCtx.imageSmoothingQuality = 'high'; } catch (e) {}
}

if (slopeCanvas) {
    setupSlopeCanvasResolution();
}

function renderSlopeMap() {
    if (!sCtx || !slopeCanvas || !isClosed || points.length < 3) return;

    const cw = slopeCanvas.width / DPR;
    const ch = slopeCanvas.height / DPR;

    const minX = Math.min(...points.map(p => p.x));
    const maxX = Math.max(...points.map(p => p.x));
    const minY = Math.min(...points.map(p => p.y));
    const maxY = Math.max(...points.map(p => p.y));
    const paso = 4;
    let minH = Infinity;
    let maxH = -Infinity;
    const muestras = [];
    for (let x = minX; x <= maxX; x += paso) {
        for (let y = minY; y <= maxY; y += paso) {
            if (!isPointInPoly(x, y)) continue;
            const h = calcularAlturaPlotEn(x, y);
            if (h != null && typeof h === 'number') {
                minH = Math.min(minH, h);
                maxH = Math.max(maxH, h);
                muestras.push({ x, y, h });
            }
        }
    }
    if (muestras.length === 0) return;
    const escala = Math.min(
        (cw - 100) / (maxX - minX || 1),
        (ch - 100) / (maxY - minY || 1)
    );

    sCtx.setTransform(1, 0, 0, 1, 0, 0);
    sCtx.clearRect(0, 0, slopeCanvas.width, slopeCanvas.height);
    sCtx.setTransform(DPR, 0, 0, DPR, 0, 0);

    sCtx.save();
    sCtx.translate(cw / 2, ch / 2);
    sCtx.scale(escala, escala);
    sCtx.translate(-(minX + (maxX - minX) / 2), -(minY + (maxY - minY) / 2));

    sCtx.beginPath();
    points.forEach((p, i) => i === 0 ? sCtx.moveTo(p.x, p.y) : sCtx.lineTo(p.x, p.y));
    sCtx.closePath();
    sCtx.clip();

    const rangoH = Math.max(1, maxH - minH);
    muestras.forEach(({ x, y, h }) => {
        const t = Math.min(1, Math.max(0, (h - minH) / rangoH));
        const r = Math.round(0 + t * (239 - 0));
        const g = Math.round(106 + t * (68 - 106));
        const b = Math.round(255 + t * (68 - 255));
        sCtx.fillStyle = `rgb(${r},${g},${b})`;
        sCtx.fillRect(x, y, paso + 1, paso + 1);
    });

    sCtx.beginPath();
    points.forEach((p, i) => i === 0 ? sCtx.moveTo(p.x, p.y) : sCtx.lineTo(p.x, p.y));
    sCtx.closePath();
    sCtx.strokeStyle = "#1e293b";
    sCtx.lineWidth = 2 / escala;
    sCtx.stroke();

    drainagePoints.forEach((dp) => {
        const rOuter = 4 / escala;
        const rInner = 2 / escala;

        sCtx.fillStyle = "#ffffff";
        sCtx.strokeStyle = "#facc15";
        sCtx.lineWidth = 1.5 / escala;
        sCtx.beginPath();
        sCtx.arc(dp.x, dp.y, rOuter, 0, Math.PI * 2);
        sCtx.fill();
        sCtx.stroke();

        sCtx.fillStyle = "#facc15";
        sCtx.beginPath();
        sCtx.arc(dp.x, dp.y, rInner, 0, Math.PI * 2);
        sCtx.fill();
    });

    sCtx.restore();

    const pad = 8;
    const legW = 170;
    const legH = 40;
    const x0 = pad;
    const y0 = ch - legH - pad;

    sCtx.fillStyle = "rgba(255,255,255,0.96)";
    sCtx.strokeStyle = "#cbd5e1";
    sCtx.lineWidth = 1;
    sCtx.strokeRect(x0, y0, legW, legH);
    sCtx.fillRect(x0, y0, legW, legH);

    sCtx.textAlign = "left";
    sCtx.font = "9px Arial";
    sCtx.fillStyle = "#0f172a";
    sCtx.fillText("Altura más baja → más alta", x0 + 8, y0 + 14);

    const gradX = x0 + 10;
    const gradY = y0 + 20;
    const gradW = legW - 20;
    const gradH = 8;
    const grad = sCtx.createLinearGradient(gradX, gradY, gradX + gradW, gradY);
    grad.addColorStop(0, "rgb(0,106,255)");
    grad.addColorStop(1, "rgb(239,68,68)");
    sCtx.fillStyle = grad;
    sCtx.fillRect(gradX, gradY, gradW, gradH);
}

