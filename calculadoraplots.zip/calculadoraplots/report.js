function generarInformeDetallado() {
    const metricas = calcularMetricas();
    const overlay = document.getElementById('pg-report-overlay');
    const numPlots = document.getElementById('piezasVal').innerText;
    const serieById = {};
    if (Array.isArray(PLOTS_SERIES)) {
        PLOTS_SERIES.forEach(s => { serieById[s.id] = s; });
    }

    const DB_ARK = {
        ARK10:  { 
            ref: (serieById.ARK10 && serieById.ARK10.refs && serieById.ARK10.refs[0]) || "TER09-1147/4A4M",
            nom: serieById.ARK10 ? (serieById.ARK10.nombre + (serieById.ARK10.rango_mm ? ` (${serieById.ARK10.rango_mm}mm)` : "")) : "ARKIMEDE 10 (10-20mm)",
            precio: 2.84,
            caja: 30
        },
        ARK18:  { 
            ref: (serieById.ARK18 && serieById.ARK18.refs && serieById.ARK18.refs[0]) || "TER09-1145/4A4M",
            nom: serieById.ARK18 ? (serieById.ARK18.nombre + (serieById.ARK18.rango_mm ? ` (${serieById.ARK18.rango_mm}mm)` : "")) : "ARKIMEDE 18 (18-36mm)",
            precio: 2.95,
            caja: 30
        },
        ARK35:  { 
            ref: (serieById.ARK35 && serieById.ARK35.refs && serieById.ARK35.refs[0]) || "TER09-1143/4A4M",
            nom: serieById.ARK35 ? (serieById.ARK35.nombre + (serieById.ARK35.rango_mm ? ` (${serieById.ARK35.rango_mm}mm)` : "")) : "ARKIMEDE 35 (35-60mm)",
            precio: 2.60,
            caja: 30
        },
        ARK60:  { 
            ref: (serieById.ARK60 && serieById.ARK60.refs && serieById.ARK60.refs[0]) || "TER09-1163/4A4M",
            nom: serieById.ARK60 ? (serieById.ARK60.nombre + (serieById.ARK60.rango_mm ? ` (${serieById.ARK60.rango_mm}mm)` : "")) : "ARKIMEDE 60 (60-115mm)",
            precio: 3.85,
            caja: 30
        },
        ARK115: { 
            ref: (serieById.ARK115 && serieById.ARK115.refs && serieById.ARK115.refs[0]) || "TER09-1173/4A4M",
            nom: serieById.ARK115 ? (serieById.ARK115.nombre + (serieById.ARK115.rango_mm ? ` (${serieById.ARK115.rango_mm}mm)` : "")) : "ARKIMEDE 115 (115-220mm)",
            precio: 5.36,
            caja: 15
        },
        P100:   { 
            ref: (serieById.P100 && serieById.P100.refs && serieById.P100.refs[0]) || "TER09-1143/P100",
            nom: serieById.P100 ? (serieById.P100.nombre + (serieById.P100.rango_mm ? ` (${serieById.P100.rango_mm}mm)` : "")) : "Extensión P100 (100mm)",
            precio: 2.15,
            caja: 30
        }
    };

    let resumen = { ARK10:0, ARK18:0, ARK35:0, ARK60:0, ARK115:0, ARK_EXT:0, EXT_P100:0, totalEuros:0 };
    const grosorBaldosa = 20;
    const margen = parseFloat(document.getElementById('alturaExtra')?.value) || 50;
    const maxZActual = Math.max(...points.map(p => p.z), ...drainagePoints.map(p => p.z));
    const nivelAcabadoSuperior = drainagePoints.length > 0
        ? Math.max(...drainagePoints.map(dp => (dp.z != null ? Number(dp.z) : 0) + margen))
        : maxZActual + margen;

    if (typeof tempPlots !== 'undefined') {
        tempPlots.forEach(pStr => {
            const [px, py] = pStr.split(',').map(Number);
            const h = calcularAlturaPlotEn(px, py);
            if (h !== null) {
                const infoSop = getInfoSoporte(h);
                if (infoSop.id === "ARK10") { resumen.ARK10++; resumen.totalEuros += DB_ARK.ARK10.precio; }
                else if (infoSop.id === "ARK18") { resumen.ARK18++; resumen.totalEuros += DB_ARK.ARK18.precio; }
                else if (infoSop.id === "ARK35") { resumen.ARK35++; resumen.totalEuros += DB_ARK.ARK35.precio; }
                else if (infoSop.id === "ARK60") { resumen.ARK60++; resumen.totalEuros += DB_ARK.ARK60.precio; }
                else if (infoSop.id === "ARK115") { resumen.ARK115++; resumen.totalEuros += DB_ARK.ARK115.precio; }
                else if (infoSop.id === "ARK_EXT") {
                    resumen.ARK_EXT++;
                    resumen.totalEuros += DB_ARK.ARK115.precio;
                    const nExt = Math.ceil((h - 220) / 100);
                    resumen.EXT_P100 += nExt;
                    resumen.totalEuros += (nExt * DB_ARK.P100.precio);
                }
            }
        });
    }

    const safeToDataURL = (cv) => {
        try {
            return cv.toDataURL("image/png");
        } catch (e) {
            console.warn("No se pudo generar imagen para el informe (restricciones del navegador):", e);
            return "";
        }
    };

    const imgPrincipal = safeToDataURL(canvas);
    let imgMapaPendientes = "";
    if (typeof renderSlopeMap === "function" && slopeCanvas && sCtx) {
        const prevWidth = slopeCanvas.width;
        const prevHeight = slopeCanvas.height;

        try {
            const exportLogicalWidth = 1200;
            const exportLogicalHeight = 800;
            slopeCanvas.width = exportLogicalWidth * DPR;
            slopeCanvas.height = exportLogicalHeight * DPR;
            sCtx.setTransform(DPR, 0, 0, DPR, 0, 0);
            if (typeof sCtx.imageSmoothingEnabled !== "undefined") sCtx.imageSmoothingEnabled = true;
            try { sCtx.imageSmoothingQuality = "high"; } catch (e) {}

            renderSlopeMap();
            imgMapaPendientes = safeToDataURL(slopeCanvas);
        } finally {
            slopeCanvas.width = prevWidth;
            slopeCanvas.height = prevHeight;
            setupSlopeCanvasResolution();
            renderSlopeMap();
        }
    }
    const numCortes = calcularCortesPerimetrales();

    const areasPorSumidero = (() => {
        if (!isClosed || drainagePoints.length === 0 || triangles.length === 0) return [];
        const allNodes = [...points, ...drainagePoints];
        const areas = new Array(drainagePoints.length).fill(0);

        triangles.forEach(tri => {
            const p0 = allNodes[tri.v[0]];
            const p1 = allNodes[tri.v[1]];
            const p2 = allNodes[tri.v[2]];
            if (!p0 || !p1 || !p2) return;
            const areaPx2 = Math.abs(
                p0.x * (p1.y - p2.y) +
                p1.x * (p2.y - p0.y) +
                p2.x * (p0.y - p1.y)
            ) / 2;
            const areaM2 = areaPx2 / (ESCALA_PX_METRO * ESCALA_PX_METRO);

            drainagePoints.forEach((dp, idx) => {
                if (isPointInTriangle(dp, p0, p1, p2)) {
                    areas[idx] += areaM2;
                }
            });
        });

        return areas.map((a, idx) => ({ index: idx, area: a }));
    })();

    const drenajesHTML = drainagePoints.length > 0  
        ? drainagePoints.map((d, i) => {
            const areaInfo = areasPorSumidero.find(a => a.index === i);
            const areaTxt = areaInfo && areaInfo.area > 0 ? `${areaInfo.area.toFixed(2)} m²` : "-";
            return `<tr>
                <td style="padding:5px 0;">Sumidero ${i+1}</td>
                <td style="text-align:right;"><strong>${d.z} mm</strong></td>
                <td style="text-align:right; color:#004a8e;">${areaTxt}</td>
            </tr>`;
        }).join('')
        : '<tr><td colspan="3" style="padding:10px 0; color:#999;">No se han definido sumideros</td></tr>';
    const serieSelect = document.getElementById('pedestal-series');
    const serieKey = serieSelect ? serieSelect.value : "ARK115";
    const infoSerie = SERIES_SOPORTES[serieKey] || { nombre: "Gama Arkimede", max: 1000 };
    const todasLasZ = [...points.map(p => p.z), ...drainagePoints.map(p => p.z)];
    const maxZProyecto = Math.max(...todasLasZ);
    const esValido = maxZProyecto <= infoSerie.max;
    const projectName = document.getElementById('projectName')?.value || "Proyecto sin nombre";
    const projectClient = document.getElementById('projectClient')?.value || "";
    const projectLocation = document.getElementById('projectLocation')?.value || "";
    const projectRef = document.getElementById('projectRef')?.value || "";
    
    const keys = [
        {k:'ARK10', d:DB_ARK.ARK10}, {k:'ARK18', d:DB_ARK.ARK18}, 
        {k:'ARK35', d:DB_ARK.ARK35}, {k:'ARK60', d:DB_ARK.ARK60}, 
        {k:'ARK115', d:DB_ARK.ARK115}
    ];

    let filasHTML = keys.map(item => {
        const cant = (item.k === 'ARK115') ? resumen.ARK115 + resumen.ARK_EXT : resumen[item.k];
        if (cant === 0) return '';
        const nCajas = Math.ceil(cant / item.d.caja);
        return `
            <tr style="border-bottom: 1px solid #eee;">
                <td style="padding:8px 0; font-size:11px; color:#666;">${item.d.ref}</td>
                <td style="padding:8px 0;"><strong>${item.d.nom}</strong></td>
                <td style="padding:8px 0; text-align:center;">${cant} ud</td>
                <td style="padding:8px 0; text-align:center; color:#004a8e;">${nCajas} cjas</td>
                <td style="padding:8px 0; text-align:right;">${(cant * item.d.precio).toFixed(2)} €</td>
            </tr>`;
    }).join('');

    if (resumen.EXT_P100 > 0) {
        filasHTML += `
            <tr style="border-bottom: 1px solid #eee; background:#fff9f0;">
                <td style="padding:8px 0; font-size:11px; color:#666;">${DB_ARK.P100.ref}</td>
                <td style="padding:8px 0;"><strong>${DB_ARK.P100.nom}</strong></td>
                <td style="padding:8px 0; text-align:center;">${resumen.EXT_P100} ud</td>
                <td style="padding:8px 0; text-align:center; color:#004a8e;">${Math.ceil(resumen.EXT_P100/30)} cjas</td>
                <td style="padding:8px 0; text-align:right;">${(resumen.EXT_P100 * DB_ARK.P100.precio).toFixed(2)} €</td>
            </tr>`;
    }
    const reportId = Math.random().toString(36).substr(2, 9).toUpperCase();
    const totalEuros = resumen.totalEuros.toFixed(2);
    const totalRow = `<tr class="pg-report-total-row"><td colspan="4" style="text-align:right;">Total estimado</td><td style="text-align:right;">${totalEuros} €</td></tr>`;

    overlay.style.display = "flex";
    overlay.innerHTML = `
    <div class="pg-report-card">
        <header class="pg-report-header">
            <div style="display:flex; align-items:center; justify-content:space-between; gap:16px;">
                <div>
                    <h1>Informe técnico de obra</h1>
                    <p class="report-subtitle">Calculator ® — Análisis de pavimento elevado Dakota Arkimede</p>
                </div>
                <div style="background:#ffffff; padding:6px 10px; border-radius:6px;">
                    <img src="assets/LOGO-DAKOTA.svg" alt="Dakota" style="height:32px; width:auto; display:block;">
                </div>
            </div>
            <div class="pg-report-meta">
                <div>
                    ${projectName ? `<strong>Obra:</strong> ${projectName}<br>` : ""}
                    ${projectClient ? `<strong>Cliente:</strong> ${projectClient}<br>` : ""}
                    ${projectLocation ? `<strong>Ubicación:</strong> ${projectLocation}<br>` : ""}
                    ${projectRef ? `<strong>Ref.:</strong> ${projectRef}` : ""}
                </div>
                <div style="text-align: right;">
                    <strong>Fecha:</strong> ${new Date().toLocaleDateString('es-ES', { day: '2-digit', month: 'short', year: 'numeric' })}<br>
                    <span style="opacity: 0.9;">ID ${reportId}</span>
                </div>
            </div>
        </header>

        <div class="pg-report-body">
            <section class="pg-report-section">
                <h2 class="pg-report-section-title">1. Resumen de pedido</h2>
                <div class="pg-report-box">
                    <table>
                        <thead>
                            <tr>
                                <th>Ref.</th>
                                <th>Modelo</th>
                                <th style="text-align:center;">Cant.</th>
                                <th style="text-align:center;">Cajas</th>
                                <th style="text-align:right;">Subtotal</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${filasHTML}
                            ${totalRow}
                        </tbody>
                    </table>
                    <p style="font-size:11px; color:#64748b; margin:12px 0 0 0;">* Precios según tarifa. IVA no incluido. Cajas con redondeo al alza.</p>
                </div>
            </section>

            <section class="pg-report-section">
                <h2 class="pg-report-section-title">2. Planos</h2>
                <div class="pg-report-box" style="margin-bottom:18px;">
                    <h3>Planta de replanteo</h3>
                    <img src="${imgPrincipal}" alt="Planta de replanteo" style="width:100%; max-height:650px; object-fit:contain;">
                </div>
                ${imgMapaPendientes ? `
                <div class="pg-report-box">
                    <h3>Mapa de pendientes</h3>
                    <img src="${imgMapaPendientes}" alt="Mapa de pendientes" style="width:100%; max-height:400px; object-fit:contain;">
                </div>` : ``}
            </section>

            <section class="pg-report-section">
                <h2 class="pg-report-section-title">3. Datos técnicos</h2>
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                    <div class="pg-report-box">
                        <h3>Desglose gama Arkimede</h3>
                        <table>
                            <tbody>
                                <tr><td>Arkimede 10 (10-20 mm)</td><td style="text-align:right; font-weight:600;">${resumen.ARK10} uds.</td></tr>
                                <tr><td>Arkimede 18 (18-36 mm)</td><td style="text-align:right; font-weight:600;">${resumen.ARK18} uds.</td></tr>
                                <tr><td>Arkimede 35 (35-60 mm)</td><td style="text-align:right; font-weight:600;">${resumen.ARK35} uds.</td></tr>
                                <tr><td>Arkimede 60 (60-115 mm)</td><td style="text-align:right; font-weight:600;">${resumen.ARK60} uds.</td></tr>
                                <tr><td>Arkimede 115 (115-220 mm)</td><td style="text-align:right; font-weight:600;">${resumen.ARK115} uds.</td></tr>
                                ${resumen.ARK_EXT > 0 ? `<tr style="color:#b45309;"><td>ARK 115 + Extensiones P100</td><td style="text-align:right; font-weight:600;">${resumen.ARK_EXT} uds.</td></tr>` : ''}
                                ${resumen.FUERA_DE_RANGO > 0 ? `<tr style="color:#b91c1c; font-weight:700;"><td>⚠ Fuera de rango (&gt;1000 mm)</td><td style="text-align:right;">${resumen.FUERA_DE_RANGO} uds.</td></tr>` : ''}
                            </tbody>
                        </table>
                    </div>
                    <div class="pg-report-box">
                        <h3>Cotas y zonas de sumideros</h3>
                        <table>
                            <thead><tr><th>Sumidero</th><th style="text-align:right;">Cota Z (mm)</th><th style="text-align:right;">Superficie (m²)</th></tr></thead>
                            <tbody>${drenajesHTML}</tbody>
                        </table>
                    </div>
                </div>
            </section>

            <section class="pg-report-section">
                <h2 class="pg-report-section-title">4. Validación</h2>
                <div class="pg-report-validation ${esValido ? 'ok' : 'alert'}">
                    <h4 style="margin:0 0 12px 0; font-size:14px;">${esValido ? '✅ Validación técnica correcta' : '⚠ Revisar compatibilidad'}</h4>
                    <div style="display: grid; grid-template-columns: 1.5fr 1fr; gap: 24px;">
                        <div>
                            <p style="margin:0 0 8px 0;">Proyecto según gama <strong>Dakota Arkimede</strong>, baldosa <strong>${tileWidth}×${tileHeight} cm</strong>.</p>
                            <ul style="margin:0; padding-left:18px;">
                                <li>Cota máx. suelo: <strong>${maxZProyecto} mm</strong></li>
                                <li>Altura acabado (sup.): <strong>${nivelAcabadoSuperior} mm</strong></li>
                                <li>Estado: <strong>${esValido ? 'Apto para instalación' : 'Revisar limitaciones'}</strong></li>
                            </ul>
                        </div>
                        <div style="border-left:2px solid currentColor; padding-left:16px; font-size:13px;">
                            <strong>Resumen</strong><br>
                            Soportes: <strong>${numPlots}</strong> uds.<br>
                            Corte perimetral: <strong>${numCortes}</strong> uds.<br>
                            Superficie: <strong>${metricas.area.toFixed(2)} m²</strong><br>
                            Densidad: <strong>${(numPlots / metricas.area).toFixed(2)} </strong>plots/m²
                        </div>
                    </div>
                </div>
            </section>

            <div class="pg-report-actions no-print">
                <a href="${imgPrincipal}" download="dakota-planta-replanteo.png" style="background:#0f766e; color:#fff;">Descargar planta (PNG)</a>
                ${imgMapaPendientes ? `<a href="${imgMapaPendientes}" download="dakota-mapa-pendientes.png" style="background:#2563eb; color:#fff;">Descargar mapa pendientes (PNG)</a>` : ``}
                <button type="button" onclick="window.print()" style="background:#004a8e; color:#fff; border:none;">Imprimir</button>
                <button type="button" onclick="document.getElementById('pg-report-overlay').style.display='none';" style="background:#fff; color:#475569; border:1px solid #cbd5e1;">Cerrar</button>
            </div>

            <footer class="pg-report-footer">
                Informe generado con Dakota Calculator · ID ${reportId} · ${new Date().toLocaleDateString('es-ES')}
            </footer>
        </div>
    </div>
    `;
}

