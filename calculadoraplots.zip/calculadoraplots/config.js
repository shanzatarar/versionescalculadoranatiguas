// Configuración global compartida entre varios módulos
// Factor de resolución para todos los canvas (principal y de pendientes).
// Se mantiene en 1 para evitar problemas de zoom/corte en algunos navegadores.
const DPR = 1;

