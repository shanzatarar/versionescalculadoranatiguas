const SERIES_SOPORTES = {
    "ARK10":  { nombre: "Arkimede 10 (10-20mm)",  max: 20,  color: "#ffcc00" },
    "ARK18":  { nombre: "Arkimede 18 (18-36mm)",  max: 36,  color: "#ff8400" },
    "ARK35":  { nombre: "Arkimede 35 (35-60mm)",  max: 60,  color: "#54c32d" },
    "ARK60":  { nombre: "Arkimede 60 (60-115mm)", max: 115, color: "#3b9cff" },
    "ARK115": { nombre: "Arkimede 115 (115-220mm)", max: 220, color: "#4228e0" },
    "ARK_EXT": { nombre: "ARK 115 + Extensiones", max: 1000, color: "#a200ee" }
};

let PLOTS_SERIES = [];

let SERIES_CONFIG = [
    { id: "ARK10",  enabled: true },
    { id: "ARK18",  enabled: true },
    { id: "ARK35",  enabled: true },
    { id: "ARK60",  enabled: true },
    { id: "ARK115", enabled: true }
];

function cargarSeriesDesdeJson() {
    fetch('plots.json')
        .then(r => r.json())
        .then(data => {
            PLOTS_SERIES = Array.isArray(data) ? data : [];
            PLOTS_SERIES.forEach(item => {
                const serie = SERIES_SOPORTES[item.id];
                if (serie) {
                    if (item.nombre) {
                        const sufijo = item.rango_mm ? ` (${item.rango_mm}mm)` : "";
                        serie.nombre = item.nombre + sufijo;
                    }
                    if (item.altura_max) serie.max = item.altura_max;
                    if (item.color) serie.color = item.color;
                }
            });
        })
        .catch(() => {});
}

cargarSeriesDesdeJson();

function cargarSeriesConfigDesdeStorage() {
    try {
        const raw = window.localStorage.getItem("dakotaSeriesConfig");
        if (!raw) return;
        const parsed = JSON.parse(raw);
        if (!Array.isArray(parsed)) return;
        SERIES_CONFIG = SERIES_CONFIG.map(def => {
            const found = parsed.find(p => p.id === def.id);
            return found ? { id: def.id, enabled: !!found.enabled } : def;
        });
    } catch (e) {}
}

function guardarSeriesConfigEnStorage() {
    try {
        window.localStorage.setItem("dakotaSeriesConfig", JSON.stringify(SERIES_CONFIG));
    } catch (e) {}
}

function renderSeriesConfigUI() {
    const cont = document.getElementById('ark-config-list');
    if (!cont) return;
    cont.innerHTML = "";

    SERIES_CONFIG.forEach((cfg, idx) => {
        const serie = SERIES_SOPORTES[cfg.id];
        if (!serie) return;
        const row = document.createElement('label');
        row.style.display = "flex";
        row.style.alignItems = "center";
        row.style.gap = "6px";
        row.style.marginBottom = "4px";

        row.innerHTML = `
            <input type="checkbox" data-idx="${idx}" ${cfg.enabled ? "checked" : ""} />
            <span style="width:10px;height:10px;border-radius:999px;background:${serie.color};border:1px solid #94a3b8;"></span>
            <span>${serie.nombre}</span>
        `;
        cont.appendChild(row);
    });

    cont.querySelectorAll('input[type="checkbox"]').forEach(input => {
        input.addEventListener('change', (e) => {
            const idx = parseInt(e.target.dataset.idx, 10);
            if (Number.isNaN(idx) || !SERIES_CONFIG[idx]) return;
            SERIES_CONFIG[idx].enabled = e.target.checked;
            guardarSeriesConfigEnStorage();
            if (typeof draw === "function") draw();
        });
    });
}

cargarSeriesConfigDesdeStorage();
window.addEventListener('load', renderSeriesConfigUI);

window.mostrarInfoSeries = () => {
    let soportes;
    if (Array.isArray(PLOTS_SERIES) && PLOTS_SERIES.length) {
        soportes = PLOTS_SERIES.filter(s => s.categoria === "soporte");
    } else {
        soportes = Object.entries(SERIES_SOPORTES).map(([id, serie]) => ({
            id,
            nombre: serie.nombre,
            rango_mm: serie.max ? `0-${serie.max}` : "",
            refs: []
        }));
    }

    let msg = "Series Arkimede (rangos de altura):\n\n";
    soportes.forEach(s => {
        const refs = (s.refs && s.refs.length) ? ` · refs: ${s.refs.join(', ')}` : "";
        msg += `- ${s.nombre}${s.rango_mm ? ` (${s.rango_mm} mm)` : ""}${refs}\n`;
    });
    alert(msg);
};

function getInfoSoporte(altura) {
    if (altura <= 0) return { nombre: "Sin altura", color: "#ecf0f1" };

    const activas = SERIES_CONFIG
        .filter(cfg => cfg.enabled && SERIES_SOPORTES[cfg.id])
        .map(cfg => ({ id: cfg.id, ...SERIES_SOPORTES[cfg.id] }))
        .sort((a, b) => (a.max || 9999) - (b.max || 9999));

    for (const serie of activas) {
        if (altura <= serie.max) {
            return { id: serie.id, ...serie };
        }
    }

    const numExt = Math.ceil((altura - 220) / 100);
    return { 
        id: "ARK_EXT", 
        nombre: `ARK 115 + ${numExt} Ext. P100`, 
        color: SERIES_SOPORTES.ARK_EXT.color 
    };
}

