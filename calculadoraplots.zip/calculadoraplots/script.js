// ========== CANVAS Y ESTADO GLOBAL ==========
const canvas = document.getElementById('pgCanvas');
const ctx = canvas.getContext('2d');
let points = [], drainagePoints = [], triangles = [], isClosed = false, currentStep = 1;
let mousePos = { x: 0, y: 0 }, hoveredPoint = null, hoveredDrainage = null;
let tempPlots = new Set();
let tileWidth = 60, tileHeight = 60, rotationAngle = 0;
let gridOrigin = { x: 500, y: 350 }, isDraggingOrigin = false;
// Replanteo: selección de origen y ángulo interactivo
let pendingTileOriginSelection = false;
let anglePreviewActive = false;
let anglePreviewDragging = false;
let anglePreviewStart = null;    // { x, y } punto del perímetro
let anglePreviewCurrent = null;  // { x, y } posición actual del ratón
let anglePreviewPointIndex = null;
let backgroundImage = null;
let draggingPoint = null, draggingDrainage = null, hoveredPlot = null;
let planMode = 'perimeter';
let isMovingAll = false;
// Grosor de la baldosa en mm (editable desde el panel)
let tileThicknessMm = 20;

// Edición de cotas Z en popup
let zEditIndex = null;

// Zoom propio de la vista (independiente del zoom del navegador)
let viewZoom = 1;

function applyViewZoom(newZoom) {
    const inner = document.getElementById('pg-canvas-inner');
    if (!inner) return;
    viewZoom = newZoom;
    inner.style.transform = `scale(${viewZoom})`;
    // Redibujar para asegurarnos de que overlays y mapas se recalculan correctamente.
    draw();
}

// Calcula el ángulo (en grados) que se aplicaría a la malla
// si el usuario hace clic rápido en el punto de perímetro idx,
// alineando el lado corto de la baldosa con el tramo hacia el siguiente punto.
function getAngleForPerimeterPoint(idx) {
    if (!points || points.length < 2) return null;
    const p = points[idx];
    const next = points[(idx + 1) % points.length];
    if (!p || !next) return null;
    const dx = next.x - p.x;
    const dy = next.y - p.y;
    if (Math.hypot(dx, dy) <= 0.001) return null;

    let baseAng = (Math.atan2(dy, dx) * 180 / Math.PI);
    if (baseAng < 0) baseAng += 360;

    const formatoSelect = document.getElementById('tileFormat')?.value || "60,60";
    const [selectedW, selectedH] = formatoSelect.split(',').map(Number);
    const ladoCortoEsW = selectedW <= selectedH;

    // En renderReplanteo, el lado de longitud tW va en la dirección rotationAngle,
    // y el de tH va en rotationAngle + 90°. Si W es el lado corto, lo alineamos
    // directamente con el tramo (rotationAngle = baseAng). Si H es el corto,
    // lo alineamos con el tramo usando rotationAngle = baseAng - 90.
    const offset = ladoCortoEsW ? 0 : -90;
    return baseAng + offset;
}

// Capas de visibilidad en el dibujo principal
let showBgImage = true;              // mostrar / ocultar imagen de fondo
let showPerimeterHeights = true;     // mostrar / ocultar cotas Z en los puntos perimetrales
let showSlopes = true;               // mostrar / ocultar pendientes (flechas entre perímetro y sumideros)
let showAngles = true;               // mostrar / ocultar % y distancia en los lados del perímetro
let showPerimeterPoints = true;      // mostrar / ocultar los nodos del perímetro (círculos A, B, C…)

// Hover de cierre del perímetro (snap al primer punto)
let hoverCloseFirst = false;

// Gizmo de direcciones para definir siguiente punto por distancia/ángulo
// directionGizmo: { index, cx, cy, size, hoverDir }
let directionGizmo = null;

// Imágenes para el nuevo gizmo (marco + flecha)
const dirFrameImg = new Image();
dirFrameImg.src = "assets/img/CRUZ.svg";
const dirArrowImg = new Image();
dirArrowImg.src = "assets/img/FLECHA.svg";

// Modo de plots centrales: 'auto' (por tamaño/desnivel) u 'off' (desactivado)
let centralMode = 'auto';
const MAX_HISTORY = 50;
let undoHistory = [], undoIndex = -1;

function getUndoState() {
    return {
        points: JSON.parse(JSON.stringify(points)),
        drainagePoints: JSON.parse(JSON.stringify(drainagePoints)),
        isClosed: isClosed
    };
}

function setUndoState(state) {
    points.length = 0;
    points.push(...state.points);
    drainagePoints.length = 0;
    drainagePoints.push(...state.drainagePoints);
    isClosed = state.isClosed;
    updateTriangulation();
    syncPointsTable();
    draw();
}

function pushUndoState() {
    const state = getUndoState();
    if (undoIndex < undoHistory.length - 1) {
        undoHistory = undoHistory.slice(0, undoIndex + 1);
    }
    undoHistory.push(state);
    if (undoHistory.length > MAX_HISTORY) undoHistory.shift();
    undoIndex = undoHistory.length - 1;
}

function undo() {
    if (undoIndex <= 0) return;
    undoIndex--;
    setUndoState(undoHistory[undoIndex]);
}

function redo() {
    if (undoIndex >= undoHistory.length - 1) return;
    undoIndex++;
    setUndoState(undoHistory[undoIndex]);
}

// Atajos de teclado: deshacer / rehacer
window.addEventListener('keydown', (e) => {
    const key = e.key.toLowerCase();
    const meta = e.metaKey || e.ctrlKey;
    if (!meta) return;

    // Cmd/Ctrl + Z → deshacer
    if (key === 'z' && !e.shiftKey) {
        e.preventDefault();
        undo();
        return;
    }
    // Cmd/Ctrl + Shift + Z o Cmd/Ctrl + Y → rehacer
    if ((key === 'z' && e.shiftKey) || key === 'y') {
        e.preventDefault();
        redo();
    }
});

syncPointsTable();

// ========== IMAGEN DE FONDO ==========
window.loadBackground = (event) => {
    const file = event.target.files[0];
    if (!file) return;

    const bgControls = document.getElementById('bg-controls');
    if (bgControls) bgControls.style.display = "block";

    const reader = new FileReader();
    reader.onload = (e) => {
        const img = new Image();
        img.onload = () => {
            backgroundImage = img;
            showBgImage = true;
            const btnClear = document.getElementById('pg-upload-clear-btn');
            if (btnClear) btnClear.style.display = 'inline-block';
            const btnToggle = document.getElementById('pg-toggle-bg-btn');
            if (btnToggle) {
                btnToggle.style.display = 'inline-block';
                btnToggle.classList.toggle('active', !showBgImage);
                btnToggle.textContent = showBgImage ? 'Ocultar fondo' : 'Mostrar fondo';
            }
            draw();
        };
        img.src = e.target.result;
    };
    reader.readAsDataURL(file);
};

window.clearBackground = () => {
    backgroundImage = null;
    showBgImage = false;
    const clearBtn = document.getElementById('pg-upload-clear-btn');
    if (clearBtn) clearBtn.style.display = 'none';
    const bgToggle = document.getElementById('pg-toggle-bg-btn');
    if (bgToggle) {
        bgToggle.style.display = 'none';
        bgToggle.classList.remove('active');
        bgToggle.textContent = 'Ocultar fondo';
    }
    const bgControls = document.getElementById('bg-controls');
    if (bgControls) bgControls.style.display = "none";
    const bgInput = document.getElementById('bgInput');
    if (bgInput) bgInput.value = "";

    const bgScale = document.getElementById('bgScale');
    const bgPosX = document.getElementById('bgPosX');
    const bgPosY = document.getElementById('bgPosY');
    if (bgScale) bgScale.value = "1";
    if (bgPosX) bgPosX.value = "0";
    if (bgPosY) bgPosY.value = "0";

    draw();
};

// Mostrar / ocultar la imagen de fondo sin perderla
window.toggleBackgroundVisibility = () => {
    if (!backgroundImage) return;
    showBgImage = !showBgImage;
    const btnToggle = document.getElementById('pg-toggle-bg-btn');
    if (btnToggle) {
        btnToggle.classList.toggle('active', !showBgImage);
        btnToggle.textContent = showBgImage ? 'Ocultar fondo' : 'Mostrar fondo';
    }
    draw();
};

const GRID_SIZE = 10;
// Para evitar problemas de zoom/corte en algunos navegadores (iPad, etc.),
// trabajamos en píxeles lógicos y fijamos DPR=1 en todos los canvas.

function setupMainCanvasResolution() {
    if (!canvas) return;
    // Usamos el tamaño real del canvas en la interfaz (responsive)
    const rect = canvas.getBoundingClientRect();
    let logicalWidth = rect.width;
    let logicalHeight = rect.height;
    // Fallback inicial si todavía no tiene tamaño
    if (!logicalWidth || !logicalHeight) {
        logicalWidth = 1500;
        logicalHeight = 1000;
        canvas.style.width = logicalWidth + "px";
        canvas.style.height = logicalHeight + "px";
    }
    canvas.width = logicalWidth * DPR;
    canvas.height = logicalHeight * DPR;
    // Escalado para pantallas HiDPI (Retina). Mantener dibujo nítido.
    ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
    // Mejorar calidad de muestreo al redimensionar imágenes
    if (typeof ctx.imageSmoothingEnabled !== 'undefined') ctx.imageSmoothingEnabled = true;
    try { ctx.imageSmoothingQuality = 'high'; } catch (e) { /* no soportado */ }
}
setupMainCanvasResolution();
const getLabel = (i) => String.fromCharCode(65 + i);

// Reajustar resolución y re-dibujar en redimensiones (evita que se vea pixelado en pantallas grandes)
let __pg_resize_timer = null;
window.addEventListener('resize', () => {
    if (__pg_resize_timer) clearTimeout(__pg_resize_timer);
    __pg_resize_timer = setTimeout(() => {
        setupMainCanvasResolution();
        setupSlopeCanvasResolution();
        draw();
    }, 150);
});

// Capa HTML para etiquetas nítidas por encima del canvas
function renderHtmlOverlays() {
    const layer = document.getElementById('pg-label-layer');
    if (!layer) return;
    // Vaciar siempre para evitar “fantasmas”
    layer.innerHTML = "";
    if (!points || !points.length) return;

    // 1) Letras de puntos (A, B, C...)
    if (showPerimeterPoints) {
        points.forEach((p, i) => {
            // No dibujar la etiqueta HTML del último punto cuando está activo el gizmo
            if (currentStep === 1 && !isClosed && i === points.length - 1) return;
            const el = document.createElement('div');
            el.className = 'pg-point-label-html';
            el.textContent = getLabel(i);
            el.style.left = `${p.x}px`;
            el.style.top = `${p.y}px`;
            layer.appendChild(el);
        });
    }

    // 2) Cotas Z en pastilla blanca/roja
    if (isClosed && showPerimeterHeights) {
        points.forEach((p) => {
            const el = document.createElement('div');
            el.className = 'pg-z-label-html';
            el.textContent = `${p.z ?? 0} mm`;
            el.style.left = `${p.x}px`;
            el.style.top = `${p.y - 22}px`;
            layer.appendChild(el);
        });
        // Cotas Z de sumideros (mismo estilo pero con clase diferenciada)
        drainagePoints.forEach((dp) => {
            const el = document.createElement('div');
            el.className = 'pg-z-label-html pg-z-label-html--drain';
            el.textContent = `${dp.z ?? 0} mm`;
            el.style.left = `${dp.x}px`;
            el.style.top = `${dp.y - 22}px`;
            layer.appendChild(el);
        });
    }

    // 3) Distancias / pendientes en los lados del perímetro
    if (isClosed && showSlopes) {
        // 3.a) Tramos del perímetro
        for (let i = 0; i < points.length; i++) {
            const p1 = points[i];
            const p2 = points[(i + 1) % points.length];
            const dx = p2.x - p1.x;
            const dy = p2.y - p1.y;
            const distPx = Math.sqrt(dx * dx + dy * dy);
            if (distPx < 15) continue;
            const distM = distPx / ESCALA_PX_METRO;
            const slopeVal = distM > 0.01 ? ((p1.z - p2.z) / (distM * 1000)) * 100 : 0;
            const absSlope = Math.abs(slopeVal).toFixed(1);
            const midX = (p1.x + p2.x) / 2;
            const midY = (p1.y + p2.y) / 2;

            const el = document.createElement('div');
            el.className = 'pg-segment-label-html';
            const textoDist = `${distM.toFixed(2)} m`;
            if (showAngles) {
                el.innerHTML = `<span class="pg-seg-dist">${textoDist}</span><span class="pg-seg-sep">·</span><span class="pg-seg-slope">${absSlope} %</span>`;
            } else {
                el.textContent = textoDist;
            }
            el.style.left = `${midX}px`;
            el.style.top = `${midY - 20}px`;
            layer.appendChild(el);
        }

        // 3.b) Tramos desde sumideros a vértices (diagonales interiores)
        if (drainagePoints && drainagePoints.length && triangles && triangles.length) {
            const allNodes = [...points, ...drainagePoints];
            const yaPintados = new Set();

            triangles.forEach((tri) => {
                const p0 = allNodes[tri.v[0]];
                const p1 = allNodes[tri.v[1]];
                const p2 = allNodes[tri.v[2]];
                if (!p0 || !p1 || !p2) return;

                drainagePoints.forEach(dp => {
                    if (!isPointInTriangle(dp, p0, p1, p2)) return;

                    [p0, p1, p2].forEach(v => {
                        const key = `${v.x},${v.y}|${dp.x},${dp.y}`;
                        if (yaPintados.has(key)) return;
                        yaPintados.add(key);

                        const dx = dp.x - v.x;
                        const dy = dp.y - v.y;
                        const distPx = Math.sqrt(dx * dx + dy * dy);
                        if (distPx < 15) return;
                        const distM = distPx / ESCALA_PX_METRO;
                        const slopeVal = distM > 0.01 ? ((v.z - dp.z) / (distM * 1000)) * 100 : 0;
                        const absSlope = Math.abs(slopeVal).toFixed(1);
                        const midX = (v.x + dp.x) / 2;
                        const midY = (v.y + dp.y) / 2;

                        const el = document.createElement('div');
                        el.className = 'pg-segment-label-html pg-segment-label-html--drain';
                        const textoDist = `${distM.toFixed(2)} m`;
                        if (showAngles) {
                            el.innerHTML = `<span class="pg-seg-dist">${textoDist}</span><span class="pg-seg-sep">·</span><span class="pg-seg-slope">${absSlope} %</span>`;
                        } else {
                            el.textContent = textoDist;
                        }
                        el.style.left = `${midX}px`;
                        el.style.top = `${midY - 20}px`;
                        layer.appendChild(el);
                    });
                });
            });
        }
    }
}

// Reajustar en cambios de tamaño de ventana
window.addEventListener('resize', () => {
    setupMainCanvasResolution();
    setupSlopeCanvasResolution();
    renderHtmlOverlays();
    draw();
});

// ========== INICIALIZACIÓN CONTROLES UI =============
window.addEventListener('load', () => {
    const thickInput = document.getElementById('tileThickness');
    if (thickInput) {
        thickInput.value = String(tileThicknessMm);
        thickInput.addEventListener('change', () => {
            const v = parseFloat(thickInput.value);
            if (Number.isFinite(v) && v >= 0) {
                tileThicknessMm = v;
                draw();
            }
        });
        // Al hacer foco, seleccionar automáticamente el valor para poder sobrescribirlo
        thickInput.addEventListener('focus', () => {
            // pequeño timeout para que funcione bien en todos los navegadores
            setTimeout(() => {
                thickInput.select();
            }, 0);
        });
    }

    // Atajo: en el popup de distancia/ángulo, Enter acepta "Siguiente punto"
    const distInput = document.getElementById('dk-dir-dist');
    const angInput = document.getElementById('dk-dir-angle');
    const handleEnter = (ev) => {
        if (ev.key === 'Enter') {
            ev.preventDefault();
            if (typeof window.aplicarDireccionSiguientePunto === 'function') {
                window.aplicarDireccionSiguientePunto();
            }
        }
    };
    if (distInput) distInput.addEventListener('keydown', handleEnter);
    if (angInput) angInput.addEventListener('keydown', handleEnter);

    // Atajo: en el popup de cota Z, Enter acepta "Guardar"
    const zInput = document.getElementById('dk-z-value');
    if (zInput) {
        zInput.addEventListener('keydown', (ev) => {
            if (ev.key === 'Enter') {
                ev.preventDefault();
                if (typeof window.aplicarPopupZ === 'function') {
                    window.aplicarPopupZ();
                }
            }
        });
    }
});

// ========== TABLA PUNTOS PERIMETRALES (COTAS Z) ==========
function syncPointsTable() {
    const table = document.getElementById('pg-points-table');
    if (!table) return;
    const tbody = table.querySelector('tbody');
    if (!tbody) return;
    tbody.innerHTML = "";
    if (!points || points.length === 0) return;

    points.forEach((p, i) => {
        const tr = document.createElement('tr');
        tr.dataset.index = i;

        const xM = (p.x || 0) / ESCALA_PX_METRO;
        const yM = (p.y || 0) / ESCALA_PX_METRO;

        tr.innerHTML = `
            <td>${getLabel(i)}</td>
            <td>${xM.toFixed(2)}</td>
            <td>${yM.toFixed(2)}</td>
            <td>
                <input type="number" class="pg-point-z-input" value="${p.z ?? 0}" step="1">
            </td>
        `;
        tbody.appendChild(tr);
    });
    if (!table.dataset.bound) {
        table.addEventListener('change', (e) => {
            const input = e.target;
            if (!(input instanceof HTMLInputElement)) return;
            if (!input.classList.contains('pg-point-z-input')) return;

            const tr = input.closest('tr');
            if (!tr) return;
            const idx = parseInt(tr.dataset.index, 10);
            if (Number.isNaN(idx) || !points[idx]) return;

            const val = parseFloat(input.value);
            if (!Number.isFinite(val)) return;

            points[idx].z = val;
            updateTriangulation();
            pushUndoState();
            draw();
        });
        table.dataset.bound = "1";
    }
}

// ========== MÉTRICAS Y CÁLCULOS ==========
// Escala base: 1 m ≈ 75 px a tamaño "normal".
// La usamos como referencia y, si hace falta, aplicamos zoom de vista
// (viewZoom) para ver más o menos metros sin tocar esta relación métrica.
const ESCALA_PX_METRO = 75;

function calcularMetricas() {
    let area = 0, perimetro = 0;
    if (points.length > 2) {
        for (let i = 0; i < points.length; i++) {
            let j = (i + 1) % points.length;
            area += points[i].x * points[j].y;
            area -= points[j].x * points[i].y;
            perimetro += Math.sqrt(
                Math.pow(points[j].x - points[i].x, 2) + Math.pow(points[j].y - points[i].y, 2)
            );
        }
        area = (Math.abs(area) / 2) / (ESCALA_PX_METRO * ESCALA_PX_METRO);
        perimetro = perimetro / ESCALA_PX_METRO;
    }
    if (document.getElementById('areaVal')) {
        document.getElementById('areaVal').innerText = area.toFixed(2);
    }
    
    return { area, perimetro };
}

// Resumen numérico de pendientes en el perímetro
function calcularResumenPendientesPerimetro() {
    if (!isClosed || points.length < 2) {
        return { min: null, max: null, media: null, numTramos: 0 };
    }

    let min = Infinity;
    let max = 0;
    let suma = 0;
    let cuenta = 0;

    for (let i = 0; i < points.length; i++) {
        const j = (i + 1) % points.length;
        const p1 = points[i], p2 = points[j];
        const distM = Math.sqrt((p2.x - p1.x)**2 + (p2.y - p1.y)**2) / ESCALA_PX_METRO;
        if (distM <= 0.05) continue;
        const slope = Math.abs(((p1.z - p2.z) / (distM * 1000)) * 100);
        if (slope <= 0) continue;
        if (slope < min) min = slope;
        if (slope > max) max = slope;
        suma += slope;
        cuenta++;
    }

    if (!Number.isFinite(min)) {
        return { min: null, max: null, media: null, numTramos: 0 };
    }

    return { min, max, media: suma / cuenta, numTramos: cuenta };
}

// ========== NAVEGACIÓN Y PASOS ==========
function updateTopNavActive() {
    document.querySelectorAll('.pg-steps-nav .pg-step').forEach(el => el.classList.remove('active'));
    const activeId = (currentStep === 3) ? 'step3-nav' : (currentStep === 4 ? 'step4-nav' : 'step1-nav');
    const el = document.getElementById(activeId);
    if (el) el.classList.add('active');
}

function updatePlanToolbarUI() {
    const toolbar = document.getElementById('pg-plan-toolbar');
    const isPlan = (currentStep === 1 || currentStep === 2);
    if (toolbar) toolbar.style.display = isPlan ? 'inline-flex' : 'none';

    const b1 = document.getElementById('pg-mode-perimeter');
    const b2 = document.getElementById('pg-mode-drainage');
    const b3 = document.getElementById('pg-mode-move');
    if (b1) b1.classList.toggle('active', planMode === 'perimeter');
    if (b2) b2.classList.toggle('active', planMode === 'drainage');
    if (b3) b3.classList.toggle('active', planMode === 'move');

    const hint = document.getElementById('pg-plan-hint');
    if (hint) {
        if (!isPlan) {
            hint.textContent = "";
        } else if (planMode === 'perimeter') {
            hint.textContent = "Haz clic para dibujar los puntos que delimitan el perímetro y doble clic en cada punto para definir su altura.";
        } else if (planMode === 'drainage') {
            hint.textContent = "Haz clic dentro del área para colocarlos (doble clic para su cota).";
        
        } else {
            hint.textContent = "";
        }
    }

    if (canvas) {
        canvas.style.cursor = (isPlan && planMode === 'move') ? (isMovingAll ? 'grabbing' : 'grab') : 'crosshair';
    }
}

window.setStep = (step) => {
    currentStep = step;
    const slopeCard = document.getElementById('slope-analysis-card');
    if (slopeCard) slopeCard.style.display = (step === 3) ? '' : 'none';
    const visCard = document.getElementById('pg-visibility-card');
    if (visCard) visCard.style.display = (step === 3) ? '' : 'none';
    const arkCard = document.getElementById('pg-ark-series-card');
    if (arkCard) arkCard.style.display = (step === 3) ? '' : 'none';
    const rotSec = document.getElementById('pg-rotation-section');
    if (rotSec) rotSec.style.display = 'none';
    const bgCard = document.getElementById('pg-bg-card');
    if (bgCard) bgCard.style.display = (step === 1 || step === 2) ? '' : 'none';
    const patternSec = document.getElementById('pg-pattern-section');
    // Tipo de colocación visible en los pasos 1, 2 y 3
    if (patternSec) patternSec.style.display = (step === 1 || step === 2 || step === 3) ? '' : 'none';
    const posSec = document.getElementById('pg-position-section');
    if (posSec) posSec.style.display = (step === 3) ? '' : 'none';
    const view3DSec = document.getElementById('pg-3d-section');
    if (view3DSec) view3DSec.style.display = (step === 3) ? '' : 'none';
    const msg = document.getElementById('pg-msg');
    const guides = {
        1: "Haz clic para dibujar los puntos que delimitan el perímetro y doble clic en cada punto para definir su altura.",
        2: "Sumideros: Haz clic dentro del área para colocar cada sumidero. Doble clic para cambiar cota Z. Para borrar: ratón y clic en la papelera roja.",
        3: "Replanteo: Elige formato y, a continuación, haz clic en un punto del perímetro para definir el origen de las baldosas.",
        4: "Informe listo. Puedes imprimir o cerrar."
    };
    if (msg) msg.innerText = guides[step] || "";
        const instBlock = document.getElementById('pg-instructions-content');
        if (instBlock) {
            const steps = {
                1: "• Arriba: elige «Puntos perimetrales».<br>• Haz clic en el lienzo para crear cada esquina.<br>• Cierra el polígono haciendo clic de nuevo en el primer punto.<br>• Con el polígono cerrado: haz clic en medio de un lado para añadir otro punto en ese lado.<br>• Doble clic en un punto para darle cota Z (mm). Para borrar: ratón sobre el punto y clic en la papelera roja.",
                2: "• Arriba: elige «Sumideros».<br>• Haz clic dentro del área para colocar cada sumidero.<br>• Doble clic en un sumidero para editar su cota Z (mm).<br>• Para borrar: pasa el ratón y clic en la papelera roja.",
                3: "• Elige formato de baldosa y tipo (Alineada/Trabada).<br>• Haz clic en un punto del perímetro para definir el origen y la orientación de la malla de baldosas.<br>• Mantén pulsado y arrastra desde un punto del perímetro para ajustar el ángulo con la línea verde.<br>• La calculadora puede añadir plots centrales de refuerzo cuando el formato de baldosa es grande o hay mucho desnivel entre esquinas; puedes quitar estos refuerzos marcando la casilla «Quitar plots centrales sugeridos».",
                4: "• Revisa el informe generado.<br>• Usa «Imprimir» o «Cerrar» según necesites."
            };
            const baseHtml = steps[step] || "";
            const videoHtml = `
                <div class="pg-instructions-video">
                    <div class="pg-instructions-video-embed">
                        <iframe 
                            src="https://www.youtube.com/embed/6KbMwsqiLgQ?si=_p9AmhQfu8RyTX2j" 
                            title="Vídeo informativo Dakota Calculator"
                            frameborder="0"
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                            referrerpolicy="strict-origin-when-cross-origin"
                            allowfullscreen
                            loading="lazy">
                        </iframe>
                    </div>
                    <div class="pg-instructions-video-text">
                        <span class="pg-instructions-video-title">Vídeo informativo de la calculadora Dakota</span>
                        <span class="pg-instructions-video-sub">Guía rápida paso a paso</span>
                    </div>
                </div>
            `;
            if (step === 1) {
                instBlock.innerHTML = baseHtml + videoHtml;
            } else {
                instBlock.innerHTML = baseHtml;
            }
        }
    // En el paso 3 mostramos el mapa de pendientes en el lateral.
    // Reajustamos el canvas cuando se hace visible (especialmente en iPad)
    // para que no aparezca recortado ni exageradamente “zoomeado”.
    if (step === 3 && typeof setupSlopeCanvasResolution === 'function' && slopeCanvas && sCtx) {
        setupSlopeCanvasResolution();
        renderSlopeMap();
    }
    if (step === 1) {
        if (planMode !== 'move') planMode = 'perimeter';
    } else if (step === 2) {
        planMode = 'drainage';
    } else if (step === 3) {
        // Al entrar en replanteo pedimos al usuario que escoja un punto de inicio.
        pendingTileOriginSelection = true;
        anglePreviewActive = false;
        anglePreviewDragging = false;
        anglePreviewStart = null;
        anglePreviewCurrent = null;
        anglePreviewPointIndex = null;
    }

    updateTopNavActive();
    updatePlanToolbarUI();

    if (step === 4) {
        generarInformeDetallado();
    } else {
        const overlay = document.getElementById('pg-report-overlay');
        if (overlay) overlay.style.display = "none";
    }
    draw();
};

window.goToPlan = () => {
    if (planMode === 'drainage') {
        window.setStep(2);
    } else {
        window.setStep(1);
    }
};

window.setPlanMode = (mode) => {
    planMode = mode;
    if (mode === 'perimeter') {
        window.setStep(1);
        return;
    }
    if (mode === 'drainage') {
        window.setStep(2);
        return;
    }
    if (currentStep === 3 || currentStep === 4) {
        window.setStep(1);
        return;
    }
    updateTopNavActive();
    updatePlanToolbarUI();
    draw();
};

window.setPatternType = (type) => {
    const sel = document.getElementById('patternType');
    if (sel) sel.value = type;

    const bGrid = document.getElementById('pattern-grid');
    const bBrick = document.getElementById('pattern-brick');
    if (bGrid) bGrid.classList.toggle('active', type === 'grid');
    if (bBrick) bBrick.classList.toggle('active', type === 'brick');

    draw();
};

// ========== CORTES PERIMETRALES Y REGLAS ==========
function calcularCortesPerimetrales() {
    if (!isClosed) return 0;
    let piezasConCorte = 0;
    const rad = (rotationAngle * Math.PI) / 180;
    const tW = tileWidth * 0.5;
    const tH = tileHeight * 0.5;

    for (let y = -800; y < 800; y += tH) {
        for (let x = -800; x < 800; x += tW) {
            const corners = [{x,y}, {x:x+tW, y}, {x:x+tW, y:y+tH}, {x, y:y+tH}];
            const realC = corners.map(c => ({
                x: c.x * Math.cos(rad) - c.y * Math.sin(rad) + gridOrigin.x,
                y: c.x * Math.sin(rad) + c.y * Math.cos(rad) + gridOrigin.y
            }));
            const adentro = realC.filter(c => isPointInPoly(c.x, c.y)).length;
            if (adentro > 0 && adentro < 4) piezasConCorte++;
        }
    }
    return piezasConCorte;
}


// (Lógica de replanteo y alturas de plots movida a `replanteo.js`)

// Distancia de un punto a un segmento; devuelve dist, punto más cercano y t (0..1) sobre el segmento
function distanceToSegment(px, py, x1, y1, x2, y2) {
    const vx = x2 - x1, vy = y2 - y1;
    const wx = px - x1, wy = py - y1;
    const v2 = vx * vx + vy * vy;
    if (v2 < 1e-6) return { dist: Math.hypot(wx, wy), closestX: x1, closestY: y1, t: 0 };
    let t = (wx * vx + wy * vy) / v2;
    t = Math.max(0, Math.min(1, t));
    const closestX = x1 + t * vx, closestY = y1 + t * vy;
    const dist = Math.hypot(px - closestX, py - closestY);
    return { dist, closestX, closestY, t };
}

// ========== EVENTOS CANVAS (ratón / táctil) ==========
function getCanvasCoordsFromEvent(e) {
    const rect = canvas.getBoundingClientRect();
    const point = (e.touches && e.touches[0]) || (e.changedTouches && e.changedTouches[0]) || e;
    // El contenedor interno pg-canvas-inner se escala con transform: scale(viewZoom).
    // getBoundingClientRect devuelve coordenadas ya escaladas, así que para volver
    // a las coordenadas "lógicas" en las que dibujamos (las mismas que usan points[],
    // drainagePoints, etc.), tenemos que dividir por viewZoom.
    const rawX = point.clientX - rect.left;
    const rawY = point.clientY - rect.top;
    const x = rawX / viewZoom;
    const y = rawY / viewZoom;
    return { x, y };
}

canvas.addEventListener('mousedown', (e) => {
    const { x, y } = getCanvasCoordsFromEvent(e);

    const isPlanStep = (currentStep === 1 || currentStep === 2);

    // Click en el gizmo de direcciones (solo paso 1):
    // solo se acepta cuando estamos exactamente sobre una flecha (estado hover amarillo)
    if (currentStep === 1 && directionGizmo && typeof directionGizmo.hoverDir === "number") {
        const bestDir = directionGizmo.hoverDir;
        const popup = document.getElementById('dk-direction-popup');
        const angInput = document.getElementById('dk-dir-angle');
        const distInput = document.getElementById('dk-dir-dist');
        if (popup) popup.style.display = 'flex';
        if (angInput) angInput.value = String(bestDir);
        // Preseleccionar el valor de distancia para que puedas escribir directamente.
        // Lo hacemos en un timeout corto para asegurar que el popup ya está pintado.
        if (distInput) {
            setTimeout(() => {
                distInput.focus();
                distInput.select();
            }, 0);
        }
        directionGizmo.selectedDir = bestDir;
        return;
    }

    // Eliminar puntos/sumideros solo en pasos de plano (1 y 2)
    if (isPlanStep) {
        for (let i = 0; i < drainagePoints.length; i++) {
        if (isClickOnTrash(x, y, drainagePoints[i].x, drainagePoints[i].y, TRASH_DRAINAGE_OFFSET_X, TRASH_DRAINAGE_OFFSET_Y)) {
            drainagePoints.splice(i, 1);
            updateTriangulation();
            pushUndoState();
            draw();
            return;
        }
        }
        for (let i = 0; i < points.length; i++) {
        if (isClickOnTrash(x, y, points[i].x, points[i].y)) {
            points.splice(i, 1);
            if (points.length < 3) isClosed = false;
            updateTriangulation();
            syncPointsTable();
            pushUndoState();
            draw();
            return;
        }
        }
    }

    // Arrastrar puntos solo en pasos de plano
    if (isPlanStep) {
        for (let i = 0; i < drainagePoints.length; i++) {
        const dp = drainagePoints[i];
        const dist = Math.hypot(x - dp.x, y - dp.y);
        if (dist < POINT_HIT_RADIUS) {
            draggingDrainage = i;
            return;
        }
    }

        for (let i = 0; i < points.length; i++) {
        const p = points[i];
        const dist = Math.hypot(x - p.x, y - p.y);
        if (dist < POINT_HIT_RADIUS) {
            if (i === 0 && !isClosed && points.length > 2) {
                isClosed = true;
                updateTriangulation();
                syncPointsTable();
                pushUndoState();
                draw();
            } else {
                draggingPoint = i;
                draw();
            }
            return;
        }
        }
    }

    if (currentStep === 3) {
        // En replanteo, al pulsar cerca de un punto del perímetro (A, B, C...),
        // activamos la selección de origen/ángulo (primera vez o posteriores).
        let bestIdx = -1;
        let bestDist = Infinity;
        for (let i = 0; i < points.length; i++) {
            const p = points[i];
            const dist = Math.hypot(x - p.x, y - p.y);
            if (dist < bestDist) {
                bestDist = dist;
                bestIdx = i;
            }
        }
        if (bestIdx >= 0 && bestDist <= POINT_HIT_RADIUS * 1.5) {
            const p = points[bestIdx];
            anglePreviewStart = { x: p.x, y: p.y };
            anglePreviewCurrent = { x: p.x, y: p.y };
            anglePreviewPointIndex = bestIdx;
            anglePreviewDragging = true;
            anglePreviewActive = false; // se activará al mover
            return;
        }

        // Desactivamos el arrastre manual del origen de la malla con el ratón:
        // el usuario no quiere que la malla se mueva con el cursor en este paso.
        if (Math.hypot(x - gridOrigin.x, y - gridOrigin.y) < 20) {
            // ignoramos arrastre de origen en este paso
            return;
        }
    }

    if ((currentStep === 1 || currentStep === 2) && planMode === 'move') {
        draw();
        return;
    }

    if (currentStep === 1 && isClosed && points.length >= 3) {
        const SEGMENT_HIT = 18;
        for (let i = 0; i < points.length; i++) {
            const j = (i + 1) % points.length;
            const A = points[i], B = points[j];
            const r = distanceToSegment(x, y, A.x, A.y, B.x, B.y);
            if (r.dist < SEGMENT_HIT && r.t > 0.05 && r.t < 0.95) {
                const z = Math.round((1 - r.t) * (A.z ?? 0) + r.t * (B.z ?? 0));
                points.splice(j, 0, { x: Math.round(r.closestX), y: Math.round(r.closestY), z });
                updateTriangulation();
                syncPointsTable();
                pushUndoState();
                draw();
                return;
            }
        }
    }

    if (currentStep === 1 && !isClosed) {
        // Snap al primer punto si estamos cerca y ya hay al menos 3 puntos
        if (points.length > 2 && points[0] && Math.hypot(x - points[0].x, y - points[0].y) < 18) {
            isClosed = true;
            updateTriangulation();
            syncPointsTable();
            pushUndoState();
        } else {
            const sx = Math.round(x / GRID_SIZE) * GRID_SIZE;
            const sy = Math.round(y / GRID_SIZE) * GRID_SIZE;
            points.push({ x: sx, y: sy, z: 0 });
            pushUndoState();
        }
    } else if (currentStep === 2 && isPointInPoly(x, y)) {
        drainagePoints.push({ x: x, y: y, z: 0 });
        updateTriangulation();
        pushUndoState();
    }

    draw();
});

canvas.addEventListener('contextmenu', (e) => {
    e.preventDefault();
    const { x, y } = getCanvasCoordsFromEvent(e);
    // Borrado con botón derecho solo en pasos 1 y 2
    if (!(currentStep === 1 || currentStep === 2)) return;
    for (let i = drainagePoints.length - 1; i >= 0; i--) {
        if (Math.hypot(x - drainagePoints[i].x, y - drainagePoints[i].y) < POINT_HIT_RADIUS) {
            drainagePoints.splice(i, 1);
            updateTriangulation();
            pushUndoState();
            draw();
            return;
        }
    }
    for (let i = points.length - 1; i >= 0; i--) {
        if (Math.hypot(x - points[i].x, y - points[i].y) < POINT_HIT_RADIUS) {
            points.splice(i, 1);
            if (points.length < 3) isClosed = false;
            updateTriangulation();
            syncPointsTable();
            pushUndoState();
            draw();
            return;
        }
    }
});

canvas.addEventListener('dblclick', (e) => {
    const { x, y } = getCanvasCoordsFromEvent(e);

    // Editar cotas solo en pasos 1 y 2
    if (!(currentStep === 1 || currentStep === 2)) return;
    
    for (let i = 0; i < points.length; i++) {
        const p = points[i];
        if (Math.hypot(x - p.x, y - p.y) < 20) {
            zEditIndex = i;
            const popup = document.getElementById('dk-z-popup');
            const input = document.getElementById('dk-z-value');
            const chk = document.getElementById('dk-z-apply-all');
            if (popup && input && chk) {
                input.value = p.z ?? 0;
                chk.checked = false;
                popup.style.display = "flex";
                // Enfocar y seleccionar automáticamente el valor para editar rápido
                setTimeout(() => {
                    input.focus();
                    input.select();
                }, 0);
            }
            return;
        }
    }

    drainagePoints.forEach((dp, i) => {
        if (Math.sqrt((x - dp.x) ** 2 + (y - dp.y) ** 2) < 20) {
            let h = prompt(`Nueva cota Z para el sumidero ${i + 1} (en mm):`, dp.z);
            if (h !== null && h !== "") {
                dp.z = parseFloat(h);
                updateTriangulation();
                pushUndoState();
                draw();
            }
        }
    });
});
canvas.addEventListener('mousemove', (e) => {
    const { x, y } = getCanvasCoordsFromEvent(e);
    mousePos = {x, y};

    if (currentStep === 3 && anglePreviewDragging) {
        anglePreviewCurrent = { x, y };
        anglePreviewActive = true;
        draw();
        return;
    }

    if (isDraggingOrigin) { 
        gridOrigin = {x, y}; 
    } else {
        hoveredPoint = null;
        points.forEach((p, i) => {
            const d = Math.hypot(x - p.x, y - p.y);
            const dTrash = Math.hypot(x - (p.x + TRASH_OFFSET_X), y - (p.y + TRASH_OFFSET_Y));
            if (d < POINT_HIT_RADIUS || dTrash < TRASH_HIT_RADIUS + 6) hoveredPoint = i;
        });
        hoveredDrainage = null;
        drainagePoints.forEach((dp, i) => {
            const d = Math.hypot(x - dp.x, y - dp.y);
            const dTrash = Math.hypot(x - (dp.x + TRASH_DRAINAGE_OFFSET_X), y - (dp.y + TRASH_DRAINAGE_OFFSET_Y));
            if (d < POINT_HIT_RADIUS || dTrash < TRASH_HIT_RADIUS + 6) hoveredDrainage = i;
        });
    }

    // Hover sobre las flechas del gizmo (solo paso 1)
    if (currentStep === 1 && directionGizmo) {
        const { cx, cy, size } = directionGizmo;
        const dx = x - cx;
        const dy = y - cy;
        const dist = Math.hypot(dx, dy);
        const maxR = size * 0.7;
        const minR = 8;
        let hover = null;
        if (dist >= minR && dist <= maxR) {
            if (Math.abs(dx) >= Math.abs(dy)) {
                hover = dx >= 0 ? 0 : 180;
            } else {
                hover = dy >= 0 ? 90 : -90;
            }
        }
        directionGizmo.hoverDir = hover;
    }

    // Cuando estamos dibujando el perímetro, detectar si el ratón está "sobre" el primer punto
    if (currentStep === 1 && !isClosed && points.length > 2 && points[0]) {
        hoverCloseFirst = Math.hypot(x - points[0].x, y - points[0].y) < 18;
    } else {
        hoverCloseFirst = false;
    }
    hoveredPlot = null;
    if (currentStep === 3) {
        const threshold = 8;
        for (let p of tempPlots) {
            const [px, py] = p.split(',').map(Number);
            if (Math.hypot(x - px, y - py) < threshold) {
                hoveredPlot = { x: px, y: py };
                break;
            }
        }
    }
    draw();
    if (draggingPoint !== null) {
        points[draggingPoint].x = Math.round(x/GRID_SIZE)*GRID_SIZE;
        points[draggingPoint].y = Math.round(y/GRID_SIZE)*GRID_SIZE;
        updateTriangulation();
    } else if (draggingDrainage !== null) {
        drainagePoints[draggingDrainage].x = x;
        drainagePoints[draggingDrainage].y = y;
        updateTriangulation();
    }

});

window.addEventListener('mouseup', () => {
    // Finalizar selección de ángulo/origen en replanteo
    if (currentStep === 3 && anglePreviewDragging && anglePreviewStart) {
        const start = anglePreviewStart;
        const current = anglePreviewCurrent || anglePreviewStart;
        const dx = current.x - start.x;
        const dy = current.y - start.y;

        if (anglePreviewActive && Math.hypot(dx, dy) > 5) {
            // Caso arrastre: usar la línea verde como referencia de ángulo
            let angDeg = (Math.atan2(dy, dx) * 180 / Math.PI);
            if (angDeg < 0) angDeg += 360;
            rotationAngle = Math.round(angDeg);
            const angleInput = document.getElementById('tileAngle');
            if (angleInput) angleInput.value = rotationAngle;
            const angleVal = document.getElementById('angleVal');
            if (angleVal) angleVal.innerText = rotationAngle + "°";
        } else if (anglePreviewPointIndex != null) {
            // Caso clic rápido: alinear con el tramo del perímetro (punto → siguiente),
            // haciendo que el lado corto de la baldosa quede sobre ese tramo.
            const idx = anglePreviewPointIndex;
            const angDeg = getAngleForPerimeterPoint(idx);
            if (angDeg != null) {
                rotationAngle = Math.round(angDeg);
                const angleInput = document.getElementById('tileAngle');
                if (angleInput) angleInput.value = rotationAngle;
                const angleVal = document.getElementById('angleVal');
                if (angleVal) angleVal.innerText = rotationAngle + "°";
            }
        }

        // Fijar origen en el punto elegido y desbloquear replanteo
        gridOrigin = { x: start.x, y: start.y };
        pendingTileOriginSelection = false;
        anglePreviewDragging = false;
        anglePreviewActive = false;
        anglePreviewStart = null;
        anglePreviewCurrent = null;
        anglePreviewPointIndex = null;
        draw();
        return;
    }

    if (draggingPoint !== null || draggingDrainage !== null) pushUndoState();
    draggingPoint = null;
    draggingDrainage = null;
    isMovingAll = false;
    updatePlanToolbarUI();
});

// Popup edición cota Z
window.cerrarPopupZ = () => {
    const popup = document.getElementById('dk-z-popup');
    if (popup) popup.style.display = "none";
    zEditIndex = null;
};

window.aplicarPopupZ = () => {
    const popup = document.getElementById('dk-z-popup');
    const input = document.getElementById('dk-z-value');
    const chk = document.getElementById('dk-z-apply-all');
    if (!popup || !input || !chk) return;
    if (zEditIndex == null || !points[zEditIndex]) {
        window.cerrarPopupZ();
        return;
    }
    const val = parseFloat(input.value);
    if (!Number.isFinite(val)) {
        return;
    }
    const aplicarATodos = chk.checked;
    if (aplicarATodos) {
        points.forEach(pt => { pt.z = val; });
    } else {
        points[zEditIndex].z = val;
    }

    updateTriangulation();
    pushUndoState();
    draw();
    syncPointsTable();
    window.cerrarPopupZ();
};

// Control del zoom de vista (botones +/−). factor > 1 acerca, < 1 aleja.
window.ajustarZoomVista = (factor) => {
    const nuevoZoom = Math.min(4, Math.max(0.25, viewZoom * factor));
    applyViewZoom(nuevoZoom);
};

// Ajusta el zoom para que el polígono actual se vea grande y centrado.
window.ajustarVistaPlano = () => {
    if (!points || points.length === 0) return;
    const holder = document.getElementById('pg-canvas-layer');
    const inner = document.getElementById('pg-canvas-inner');
    if (!holder || !inner) return;

    // Bounding box del perímetro
    let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;
    points.forEach(p => {
        minX = Math.min(minX, p.x);
        maxX = Math.max(maxX, p.x);
        minY = Math.min(minY, p.y);
        maxY = Math.max(maxY, p.y);
    });
    if (!Number.isFinite(minX) || !Number.isFinite(maxX)) return;

    const bboxW = Math.max(100, maxX - minX);
    const bboxH = Math.max(100, maxY - minY);

    const rect = holder.getBoundingClientRect();
    const padding = 80; // margen visual alrededor
    const availableW = Math.max(100, rect.width - padding * 2);
    const availableH = Math.max(100, rect.height - padding * 2);

    // Zoom que hace que el polígono quepa dentro del área disponible
    const zoomW = availableW / bboxW;
    const zoomH = availableH / bboxH;
    const targetZoom = Math.min(4, Math.max(0.25, Math.min(zoomW, zoomH)));
    applyViewZoom(targetZoom);

    // Centrar el polígono dentro del área visible desplazando el scroll del contenedor
    const holderScroll = document.getElementById('canvas-main-holder');
    if (!holderScroll) return;
    const centerX = (minX + maxX) / 2 * viewZoom;
    const centerY = (minY + maxY) / 2 * viewZoom;
    const viewportW = holderScroll.clientWidth;
    const viewportH = holderScroll.clientHeight;
    holderScroll.scrollLeft = Math.max(0, centerX - viewportW / 2);
    holderScroll.scrollTop = Math.max(0, centerY - viewportH / 2);
};

// Soporte táctil básico (iPad, tablets): reutiliza la misma lógica de ratón
canvas.addEventListener('touchstart', (e) => {
    e.preventDefault();
    const touch = e.touches[0] || e.changedTouches[0];
    if (!touch) return;
    const synthetic = new MouseEvent('mousedown', {
        clientX: touch.clientX,
        clientY: touch.clientY,
        button: 0,
        bubbles: true
    });
    canvas.dispatchEvent(synthetic);
}, { passive: false });

canvas.addEventListener('touchmove', (e) => {
    e.preventDefault();
    const touch = e.touches[0] || e.changedTouches[0];
    if (!touch) return;
    const synthetic = new MouseEvent('mousemove', {
        clientX: touch.clientX,
        clientY: touch.clientY,
        bubbles: true
    });
    canvas.dispatchEvent(synthetic);
}, { passive: false });

canvas.addEventListener('touchend', (e) => {
    e.preventDefault();
    const synthetic = new MouseEvent('mouseup', {
        clientX: 0,
        clientY: 0,
        bubbles: true
    });
    window.dispatchEvent(synthetic);
}, { passive: false });

// ========== DIBUJO AUXILIAR ==========
const TRASH_OFFSET_X = 28, TRASH_OFFSET_Y = -26;
const TRASH_DRAINAGE_OFFSET_X = 0, TRASH_DRAINAGE_OFFSET_Y = -28;
const TRASH_HIT_RADIUS = 22;
const POINT_HIT_RADIUS = 28;

function isClickOnTrash(clickX, clickY, pointX, pointY, offsetX = TRASH_OFFSET_X, offsetY = TRASH_OFFSET_Y) {
    return Math.hypot(clickX - (pointX + offsetX), clickY - (pointY + offsetY)) < TRASH_HIT_RADIUS;
}

// (Funciones de dibujo principales movidas a `canvas-draw.js`)

// ========== ACCIONES GLOBALES (window) ==========
window.centrarReplanteo = () => {
    if (!isClosed || points.length === 0) return;
    let sumX = 0, sumY = 0;
    points.forEach(p => { sumX += p.x; sumY += p.y; });
    gridOrigin = { x: sumX / points.length, y: sumY / points.length };
    const btnCentrar = document.getElementById('btn-centrar');
    const btnDescentrar = document.getElementById('btn-descentrar');
    if (btnCentrar) btnCentrar.classList.add('active');
    if (btnDescentrar) btnDescentrar.classList.remove('active');
    draw();
};

window.descentrarReplanteo = () => {
    gridOrigin = { x: canvas.width / 2, y: canvas.height / 2 };
    const btnCentrar = document.getElementById('btn-centrar');
    const btnDescentrar = document.getElementById('btn-descentrar');
    if (btnDescentrar) btnDescentrar.classList.add('active');
    if (btnCentrar) btnCentrar.classList.remove('active');
    draw();
};

// ====== Toggles de visibilidad de capas ======
window.togglePerimeterPoints = () => {
    showPerimeterPoints = !showPerimeterPoints;
    const btn = document.getElementById('btn-vis-points');
    if (btn) btn.classList.toggle('active', showPerimeterPoints);
    draw();
};

window.togglePerimeterHeights = () => {
    showPerimeterHeights = !showPerimeterHeights;
    const btn = document.getElementById('btn-vis-heights');
    if (btn) btn.classList.toggle('active', showPerimeterHeights);
    draw();
};

window.toggleSlopes = () => {
    showSlopes = !showSlopes;
    const btn = document.getElementById('btn-vis-slopes');
    if (btn) btn.classList.toggle('active', showSlopes);
    draw();
};

window.toggleAngles = () => {
    showAngles = !showAngles;
    const btn = document.getElementById('btn-vis-angles');
    if (btn) btn.classList.toggle('active', showAngles);
    draw();
};

// Abrir vista 3D en nueva pestaña
window.abrirVista3D = () => {
    if (!isClosed) {
        alert("Primero cierra el perímetro y genera los plots (Paso 3).");
        return;
    }
    if (!tempPlots || tempPlots.size === 0) {
        renderReplanteo();
        if (!tempPlots || tempPlots.size === 0) {
            alert("No hay plots generados para mostrar en 3D.");
            return;
        }
    }

    const plots = [];
    tempPlots.forEach(pStr => {
        const [px, py] = pStr.split(',').map(Number);
        const h = calcularAlturaPlotEn(px, py);
        if (h == null || h <= 0) return;
        const info = getInfoSoporte(h);
        plots.push({
            x: px,
            y: py,
            h,
            color: info && info.color ? info.color : "#0070c0"
        });
    });

    if (!plots.length) {
        alert("No hay alturas de plots positivas para mostrar en 3D.");
        return;
    }

    const perimeter = points.map(p => ({
        x: p.x,
        y: p.y,
        z: p.z || 0
    }));
    const center = drainagePoints.map(dp => ({
        x: dp.x,
        y: dp.y,
        z: dp.z || 0
    }));

    const payload = {
        plots,
        perimeter,
        center,
        tileSize: { w: tileWidth, h: tileHeight },
        rotation: rotationAngle,
        origin: gridOrigin
    };

    // Guardamos en localStorage (cuando el navegador lo permite)
    try {
        window.localStorage.setItem("dakota3dData", JSON.stringify(payload));
    } catch (e) {
        // ignore
    }

    // Y también colgamos los datos del window actual para que 3d.html pueda leerlos vía window.opener
    window.__dakota3dData = payload;

    window.open("3d.html", "_blank");
};

function analizarSeguridadPendientes() {
    let alertas = [];
    for (let i = 0; i < points.length; i++) {
        let j = (i + 1) % points.length;
        const p1 = points[i], p2 = points[j];
        const distM = Math.sqrt((p2.x - p1.x)**2 + (p2.y - p1.y)**2) / ESCALA_PX_METRO;
        const slope = distM > 0.05 ? Math.abs(((p1.z - p2.z) / (distM * 1000)) * 100) : 0;

        if (slope > 4) alertas.push(`Tramo ${getLabel(i)}-${getLabel(j)}: Pendiente excesiva (${slope.toFixed(1)}%). Riesgo de deslizamiento.`);
        if (slope < 1 && slope > 0) alertas.push(`Tramo ${getLabel(i)}-${getLabel(j)}: Pendiente escasa (${slope.toFixed(1)}%). Riesgo de estancamiento.`);
    }
    return alertas;
}

window.generarPresupuestoSoportes = () => {
    if (!isClosed || tempPlots.size === 0) {
        alert("Primero completa el replanteo (Paso 3) para generar el desglose.");
        return;
    }

    let desglose = {};
    let totalExtensiones = 0;
    const grosorBaldosa = 20;
    const margen = parseFloat(document.getElementById('alturaExtra')?.value) || 50;
    const maxZ = Math.max(...points.map(p => p.z), ...drainagePoints.map(p => p.z));
    const nivelAcabadoSuperior = drainagePoints.length > 0
        ? Math.max(...drainagePoints.map(dp => (dp.z != null ? Number(dp.z) : 0) + margen))
        : maxZ + margen;

    tempPlots.forEach(pStr => {
        const [px, py] = pStr.split(',').map(Number);
        const alturaNecesaria = calcularAlturaPlotEn(px, py);
        const info = getInfoSoporte(alturaNecesaria);
        const modelo = info.nombre;
        desglose[modelo] = (desglose[modelo] || 0) + 1;
        if (info.id === "ARK_EXT") {
            const numExt = Math.ceil((alturaNecesaria - 220) / 100);
            totalExtensiones += numExt;
        }
    });
    if (totalExtensiones > 0) {
        desglose["Extensión ARK P100 (100mm)"] = totalExtensiones;
    }
    console.log("%c--- DESGLOSE DE MATERIALES DAKOTA ARKIMEDE ---", "color: #004a8e; font-weight: bold; font-size: 12px;");
    console.table(desglose);
    let mensaje = `📦 RESUMEN DE PEDIDO ARKIMEDE\n`;
    mensaje += `Nivel de acabado: ${nivelAcabadoSuperior} mm\n`;
    mensaje += `-------------------------------------------\n`;
    
    for (const [modelo, cantidad] of Object.entries(desglose)) {
        mensaje += `${cantidad.toString().padEnd(5)} x  ${modelo}\n`;
    }
    
    mensaje += `-------------------------------------------\n`;
    mensaje += `Total puntos de apoyo: ${tempPlots.size} uds.`;

    alert(mensaje);
    
    return desglose;
};


window.actualizarFormatoDakota = function() {
    const select = document.getElementById('tileFormat');
    const [w, h] = select.value.split(',').map(Number);
    tileWidth = w;
    tileHeight = h;
    draw();
};
window.updateAngle = (val) => { rotationAngle = val; const el = document.getElementById('angleVal'); if (el) el.innerText = val + '°'; draw(); };

// Popup de dirección/distancia para siguiente punto
window.cerrarPopupDireccion = () => {
    const popup = document.getElementById('dk-direction-popup');
    if (popup) popup.style.display = 'none';
};

window.aplicarDireccionSiguientePunto = () => {
    if (!directionGizmo || directionGizmo.index == null || !points[directionGizmo.index]) {
        window.cerrarPopupDireccion();
        return;
    }
    const base = points[directionGizmo.index];
    const distInput = document.getElementById('dk-dir-dist');
    const angInput = document.getElementById('dk-dir-angle');
    if (!(distInput instanceof HTMLInputElement) || !(angInput instanceof HTMLInputElement)) {
        window.cerrarPopupDireccion();
        return;
    }
    const distM = parseFloat(distInput.value);
    const angDeg = parseFloat(angInput.value);
    if (!Number.isFinite(distM) || !Number.isFinite(angDeg)) {
        window.cerrarPopupDireccion();
        return;
    }
    const distPx = distM * ESCALA_PX_METRO;
    const angRad = (angDeg * Math.PI) / 180;
    const nx = base.x + distPx * Math.cos(angRad);
    // Y hacia abajo debe ser positivo en canvas, por eso sumamos
    const ny = base.y + distPx * Math.sin(angRad);
    points.push({ x: Math.round(nx), y: Math.round(ny), z: 0 });
    updateTriangulation();
    syncPointsTable();
    pushUndoState();
    window.cerrarPopupDireccion();
    draw();
};

// Pantalla de bienvenida: entrar en calculadora Arkimede
window.iniciarCalculadora = (sistema) => {
    // Por ahora solo usamos 'ARKIMEDE', pero dejamos el parámetro por si se amplía.
    const landing = document.getElementById('dakota-landing');
    const app = document.getElementById('dakota-app');
    if (landing) landing.style.display = 'none';
    if (app) app.style.display = 'flex';
};

// Modo plots centrales (auto / nunca) controlado por checkbox
window.toggleCentralPlots = () => {
    const chk = document.getElementById('chk-central-disable');
    const off = chk ? chk.checked : false;
    centralMode = off ? 'off' : 'auto';
    // Recalcular replanteo para aplicar el nuevo modo
    if (isClosed) {
        renderReplanteo();
        draw();
    }
};

window.resetCanvas = () => {
    points = [];
    drainagePoints = [];
    triangles = [];
    isClosed = false;
    planMode = 'perimeter';
    isMovingAll = false;
    setStep(1);
    syncPointsTable();
    undoHistory = [];
    undoIndex = -1;
    pushUndoState();
};

setStep(1);
pushUndoState();

(function initInstructionsPanel() {
    const wrap = document.getElementById('pg-instructions-wrap');
    const panel = document.getElementById('pg-instructions-panel');
    const tab = document.getElementById('pg-instructions-tab');
    const closeBtn = document.getElementById('pg-instructions-close');
    if (!wrap || !panel || !tab || !closeBtn) return;
    closeBtn.addEventListener('click', () => {
        wrap.classList.add('pg-instructions--closed');
    });
    tab.addEventListener('click', () => {
        wrap.classList.remove('pg-instructions--closed');
    });
})();

(function initProjectPanel() {
    const wrap = document.getElementById('pg-project-wrap');
    const card = document.getElementById('pg-project-card');
    const tab = document.getElementById('pg-project-tab');
    const closeBtn = document.getElementById('pg-project-close');
    if (!wrap || !card || !tab || !closeBtn) return;
    closeBtn.addEventListener('click', () => {
        wrap.classList.add('pg-project--closed');
    });
    tab.addEventListener('click', () => {
        wrap.classList.remove('pg-project--closed');
    });
})();

window.addEventListener('keydown', (e) => {
    if (e.ctrlKey && e.key === 'z') {
        e.preventDefault();
        if (e.shiftKey) redo();
        else undo();
    }
    if (e.ctrlKey && e.key === 'y') {
        e.preventDefault();
        redo();
    }
});
