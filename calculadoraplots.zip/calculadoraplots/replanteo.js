// ========== REPLANTEO (PASO 3): BALDOSAS Y PLOTS ==========

// Interpola cota Z en (x,y) usando triangulación baricéntrica
function getZAt(x, y) {
    if (!isClosed || !triangles || triangles.length === 0) return null;
    const todosLosPuntos = [...points, ...drainagePoints];
    for (let tri of triangles) {
        const p0 = todosLosPuntos[tri.v[0]];
        const p1 = todosLosPuntos[tri.v[1]];
        const p2 = todosLosPuntos[tri.v[2]];
        if (!p0 || !p1 || !p2) continue;
        if (isPointInTriangle({ x, y }, p0, p1, p2)) {
            let det = (p1.y - p2.y) * (p0.x - p2.x) + (p2.x - p1.x) * (p0.y - p2.y);
            if (Math.abs(det) < 0.0001) continue;
            let l1 = ((p1.y - p2.y) * (x - p2.x) + (p2.x - p1.x) * (y - p2.y)) / det;
            let l2 = ((p2.y - p0.y) * (x - p2.x) + (p0.x - p2.x) * (y - p2.y)) / det;
            let l3 = 1 - l1 - l2;
            return l1 * p0.z + l2 * p1.z + l3 * p2.z;
        }
    }
    return null;
}

function renderReplanteo() {
    if (!isClosed) return;
    // Mientras el usuario aún no ha definido el origen/ángulo de inicio,
    // no generamos plots ni rejilla de baldosas.
    // Después de fijar el primer origen, mantenemos visibles las baldosas
    // incluso si se está arrastrando la línea verde de previsualización,
    // para que el usuario use esa línea solo como guía sin mover la malla
    // hasta soltar el botón.
    if (pendingTileOriginSelection) {
        tempPlots = new Set();
        return;
    }
    const rad = (rotationAngle * Math.PI) / 180;
    const formatoSelect = document.getElementById('tileFormat')?.value || "60,60";
    const [selectedW, selectedH] = formatoSelect.split(',').map(Number);

    const tW = selectedW * 0.75;
    const tH = selectedH * 0.75;
    const patternType = document.getElementById('patternType')?.value || 'grid';
    const todosLosPuntos = [...points, ...drainagePoints];
    const maxZProyectada = todosLosPuntos.length > 0 ? Math.max(...todosLosPuntos.map(p => p.z || 0)) : 0;
    const margenCliente = parseFloat(document.getElementById('alturaExtra')?.value) || 50;
    const nivelAcabado = maxZProyectada + margenCliente;
    tempPlots = new Set();
    let rowIndex = 0;
    let contadorRefuerzosDesnivel = 0;
    ctx.save();

    // Queremos que el origen de la malla (gridOrigin) coincida exactamente
    // con la intersección de líneas de la rejilla (esquina de baldosa)
    // para TODOS los formatos. Para ello, generamos la malla en coordenadas
    // locales donde (0,0) es SIEMPRE un nodo de la rejilla, y luego
    // trasladamos todo a gridOrigin.
    const alcance = 3000; // alcance aproximado que cubre el plano
    const numFilas = Math.ceil(alcance / tH);
    const numCols = Math.ceil(alcance / tW);
    const yInicio = -numFilas * tH;
    const yFin = numFilas * tH;
    const xInicio = -numCols * tW;
    const xFin = numCols * tW;

    for (let y = yInicio; y <= yFin; y += tH) {
        rowIndex++;
        for (let x = xInicio; x <= xFin; x += tW) {
            let offsetX = 0;
            let offsetY = 0;
            if (patternType === 'brick') {
                if (selectedW >= selectedH) {
                    if (rowIndex % 2 === 0) offsetX = tW / 2;
                } else {
                    let colIndex = Math.round(x / tW);
                    if (colIndex % 2 === 0) offsetY = tH / 2;
                }
            }

            const curX = x + offsetX;
            const curY = y + offsetY;

            const corners = [
                { x: curX, y: curY }, { x: curX + tW, y: curY },
                { x: curX + tW, y: curY + tH }, { x: curX, y: curY + tH }
            ];

            const realC = corners.map(c => ({
                x: c.x * Math.cos(rad) - c.y * Math.sin(rad) + gridOrigin.x,
                y: c.x * Math.sin(rad) + c.y * Math.cos(rad) + gridOrigin.y
            }));
            const adentro = realC.filter(c => isPointInPoly(c.x, c.y)).length;
            const insideCorners = realC.filter(c => isPointInPolyOrBorder(c.x, c.y));
            const outsideCorners = realC.filter(c => !isPointInPolyOrBorder(c.x, c.y));

            if (realC.some(c => isPointInPolyOrBorder(c.x, c.y))) {
                ctx.strokeStyle = "rgba(0, 74, 142, 0.2)";
                ctx.beginPath();
                ctx.moveTo(realC[0].x, realC[0].y);
                realC.forEach(c => ctx.lineTo(c.x, c.y));
                ctx.closePath();
                ctx.stroke();
                const zEsquinas = realC.map(c => getZAt(c.x, c.y) || 0);
                const diferenciaZ = Math.max(...zEsquinas) - Math.min(...zEsquinas);
                const desnivelCritico = diferenciaZ > 5;
                const apoyosRelativos = [{ rx: 0, ry: 0 }, { rx: 1, ry: 0 }, { rx: 1, ry: 1 }, { rx: 0, ry: 1 }];
                if (selectedW > 60) apoyosRelativos.push({ rx: 0.5, ry: 0 }, { rx: 0.5, ry: 1 });
                if (selectedH > 60) apoyosRelativos.push({ rx: 0, ry: 0.5 }, { rx: 1, ry: 0.5 });

                const centralPorTam = (selectedW >= 60 && selectedH >= 60);
                const centralPorDesnivel = desnivelCritico;

                let usarCentral = false;
                if (centralMode === 'off') {
                    usarCentral = false;
                } else {
                    usarCentral = centralPorTam || centralPorDesnivel;
                }

                if (usarCentral) {
                    apoyosRelativos.push({ rx: 0.5, ry: 0.5 });
                    if (centralPorDesnivel && centralMode === 'auto' && (selectedW < 60 || selectedH < 60)) {
                        contadorRefuerzosDesnivel++;
                    }
                }

                apoyosRelativos.forEach(p => {
                    const px = (curX + p.rx * tW) * Math.cos(rad) - (curY + p.ry * tH) * Math.sin(rad) + gridOrigin.x;
                    const py = (curX + p.rx * tW) * Math.sin(rad) + (curY + p.ry * tH) * Math.cos(rad) + gridOrigin.y;
                    if (isPointInPolyOrBorder(px, py)) {
                        tempPlots.add(`${Math.round(px)},${Math.round(py)}`);
                    }
                });
                if (insideCorners.length > 0 && outsideCorners.length > 0) {
                    const addedCorte = new Set();
                    for (let i = 0; i < 4; i++) {
                        const a = realC[i];
                        const b = realC[(i + 1) % 4];
                        const aIn = isPointInPolyOrBorder(a.x, a.y);
                        const bIn = isPointInPolyOrBorder(b.x, b.y);
                        if (aIn === bIn) continue;
                        const from = aIn ? a : b;
                        const to = aIn ? b : a;
                        let t0 = 0, t1 = 1;
                        for (let k = 0; k < 14; k++) {
                            const tm = (t0 + t1) / 2;
                            const mx = from.x + (to.x - from.x) * tm;
                            const my = from.y + (to.y - from.y) * tm;
                            if (isPointInPolyOrBorder(mx, my)) t0 = tm;
                            else t1 = tm;
                        }
                        const tIn = Math.min(0.85, t0 * 0.9);
                        const bx = from.x + (to.x - from.x) * tIn;
                        const by = from.y + (to.y - from.y) * tIn;
                        const key = `${Math.round(bx)},${Math.round(by)}`;
                        if (!addedCorte.has(key)) {
                            addedCorte.add(key);
                            tempPlots.add(key);
                        }
                    }
                }
            }
        }
    }
    ctx.restore();
    const divAlertas = document.getElementById('contenedor-alertas');
    if (divAlertas) {
        if (contadorRefuerzosDesnivel > 0) {
            divAlertas.style.display = "block";
            divAlertas.innerHTML = `<div style="background: #fff3cd; color: #856404; padding: 12px; border-left: 5px solid #ffc107;">
                <strong>⚠️ NOTA TÉCNICA DAKOTA:</strong> Desniveles críticos en ${contadorRefuerzosDesnivel} puntos. Refuerzo central aplicado.</div>`;
        } else {
            divAlertas.style.display = "none";
        }
    }
    // Info global sobre plots centrales
    const centralInfo = document.getElementById('central-info');
    if (centralInfo) {
        if (centralMode === 'off') {
            centralInfo.textContent = "Plots centrales desactivados manualmente.";
        } else if (contadorRefuerzosDesnivel > 0 || (selectedW >= 60 && selectedH >= 60)) {
            const motivos = [];
            if (selectedW >= 60 && selectedH >= 60) motivos.push("formato de baldosa ≥ 60×60 cm");
            if (contadorRefuerzosDesnivel > 0) motivos.push("desnivel > 5 mm entre esquinas");
            centralInfo.textContent = "Plots centrales de refuerzo añadidos automáticamente por " + motivos.join(" y ") + ".";
        } else {
            centralInfo.textContent = "Sin plots centrales añadidos automáticamente en modo AUTO.";
        }
    }
    const todosLosPuntosZ = [...points, ...drainagePoints].map(p => p.z || 0);
    const zMedio = todosLosPuntosZ.length ? todosLosPuntosZ.reduce((a, b) => a + b, 0) / todosLosPuntosZ.length : 0;
    const offsets = [[0, 0], [2, 0], [-2, 0], [0, 2], [0, -2], [3, 3], [-3, -3]];
    tempPlots.forEach(p => {
        const [px, py] = p.split(',').map(Number);
        let zSuelo = getZAt(px, py);
        if (zSuelo === null) {
            for (const [dx, dy] of offsets) {
                zSuelo = getZAt(px + dx, py + dy);
                if (zSuelo !== null) break;
            }
        }
        if (zSuelo === null) zSuelo = zMedio;
        const alturaRealPlot = calcularAlturaPlotEn(px, py);
        const infoSoporte = getInfoSoporte(alturaRealPlot);

        ctx.save();
        ctx.fillStyle = infoSoporte.color;
        ctx.strokeStyle = "white";
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.arc(px, py, 5, 0, Math.PI * 2);
        ctx.fill();
        ctx.stroke();
        ctx.restore();
    });
}

// Resumen de pendientes en panel lateral
function updateSlopeSummary() {
    const box = document.getElementById('slope-summary');
    if (!box) return;

    if (!isClosed || points.length < 2) {
        box.textContent = "Dibuja el perímetro y define las cotas para analizar las pendientes.";
        return;
    }

    const resumen = calcularResumenPendientesPerimetro();
    if (resumen.numTramos === 0 || resumen.min === null) {
        box.textContent = "No hay tramos de perímetro suficientes para analizar la pendiente.";
        return;
    }

    const min = resumen.min.toFixed(1);
    const max = resumen.max.toFixed(1);
    const media = resumen.media.toFixed(1);

    let estado;
    if (resumen.min < 1) {
        estado = "RIESGO de estancamiento (mín. < 1%)";
    } else if (resumen.min < 2) {
        estado = "Pendiente baja, revisar (mín. entre 1% y 2%)";
    } else {
        estado = "Pendiente OK (mín. ≥ 2%)";
    }

    box.innerHTML = `
        <strong>Pendiente mínima:</strong> ${min}% · 
        <strong>máxima:</strong> ${max}% · 
        <strong>media:</strong> ${media}%<br>
        <span style="color:${resumen.min < 1 ? '#b91c1c' : (resumen.min < 2 ? '#b45309' : '#166534')}; font-weight:600;">
            ${estado}
        </span>
    `;
}

function getNivelAcabadoSuperior() {
    const todos = [...points, ...drainagePoints];
    if (!todos.length) return 0;

    const maxZ = Math.max(...todos.map(p => p.z || 0));
    const margen = parseFloat(document.getElementById('alturaExtra')?.value) || 50;
    return maxZ + margen;
}

// Lógica de pendiente (sin triangulación, solo distancia al punto central).
// 1. Si punto sumidero y perímetro están todos a 0 mm → no se calcula pendiente (superficie plana).
// 2. Si hay puntos perimetrales con altura y sumidero a 0 → se calcula pendiente hacia el sumidero.
// 3. Se tiene en cuenta la altura de los puntos perimetrales (getZAt / suelo local).
// 4. Si el punto es más alto que el perímetro → es punto alto, agua a los bordes por todos los lados.
const PENDIENTE_DRENAJE_MM_M = 20;

// Distancia máxima desde un punto (dx,dy) hasta el perímetro (para pendiente hasta el borde).
function maxDistPxHastaPerimetro(dx, dy) {
    if (points.length === 0) return 0;
    let max = 0;
    points.forEach(p => {
        const d = Math.hypot(p.x - dx, p.y - dy);
        if (d > max) max = d;
    });
    return max;
}

function getNivelAcabadoEn(x, y) {
    const margen = parseFloat(document.getElementById('alturaExtra')?.value) || 50;
    const grosorBaldosa = 20;
    const todos = [...points, ...drainagePoints].filter(p => p.z != null && p.z !== '');
    const minZ = todos.length ? Math.min(...todos.map(p => Number(p.z) || 0)) : 0;
    const nivelBase = minZ + grosorBaldosa;
    const maxZ = todos.length ? Math.max(...todos.map(p => Number(p.z) || 0)) : 0;

    const maxZPerimetro = points.length ? Math.max(...points.map(p => Number(p.z) || 0)) : 0;
    const minZPerimetro = points.length ? Math.min(...points.map(p => Number(p.z) || 0)) : 0;
    const perimetroTodoCero = points.length === 0 || (minZPerimetro === 0 && maxZPerimetro === 0);
    const sumiderosTodosCero = drainagePoints.length > 0 && drainagePoints.every(dp => (dp.z != null ? Number(dp.z) : 0) === 0);

    if (drainagePoints.length === 0) {
        return maxZ + margen;
    }

    // 1. Sumidero(s) a 0 mm y perímetro todo a 0 mm → no pendiente, superficie plana.
    if (sumiderosTodosCero && perimetroTodoCero) {
        return nivelBase;
    }

    // Varios puntos: cada uno aporta un nivel según su lógica; se combinan con peso por distancia.
    let sumPeso = 0;
    let sumNivelPeso = 0;
    const eps = 50;

    for (const dp of drainagePoints) {
        const distPx = Math.hypot(x - dp.x, y - dp.y);
        const distM = distPx / ESCALA_PX_METRO;
        const z = dp.z != null ? Number(dp.z) : 0;

        // 4. Si el punto es más alto que el perímetro → punto alto (agua a los bordes). Si no → sumidero.
        const esPuntoAlto = z > maxZPerimetro;

        let nivelI;
        if (esPuntoAlto) {
            // Punto alto: baja hasta el borde.
            const nivelCentro = 2 * z + grosorBaldosa;
            const maxDistPx = maxDistPxHastaPerimetro(dp.x, dp.y);
            const maxDistM = Math.max(maxDistPx / ESCALA_PX_METRO, 0.01);
            let pendiente = (nivelCentro - nivelBase) / maxDistM;
            pendiente = Math.max(pendiente, 2);
            nivelI = nivelCentro - pendiente * distM;
            nivelI = Math.max(nivelI, nivelBase);
        } else {
            // Sumidero (z <= maxZPerimetro): sube desde este punto hacia fuera.
            nivelI = nivelBase + PENDIENTE_DRENAJE_MM_M * distM;
        }

        const peso = 1 / (distPx * distPx + eps);
        sumNivelPeso += nivelI * peso;
        sumPeso += peso;
    }

    let nivel = sumPeso > 0 ? sumNivelPeso / sumPeso : nivelBase;
    nivel = Math.max(nivel, nivelBase);

    // 3. Respetar altura de los puntos perimetrales: no bajar del suelo local + baldosa.
    const zSueloLocal = getZAt(x, y);
    const sueloLocal = zSueloLocal != null ? Number(zSueloLocal) : minZ;
    nivel = Math.max(nivel, sueloLocal + grosorBaldosa);

    return nivel;
}

// Interpolación RADIAL entre punto central (drainagePoint) y perímetro:
// Zacabado(x,y) = Zc + t * (Zborde_dir - Zc), donde t = dist(C, P) / dist(C, borde_en_esa_dirección).
function getZRadialAt(x, y) {
    if (drainagePoints.length !== 1 || points.length < 3) return null;
    const c = drainagePoints[0];
    const cx = c.x, cy = c.y, zc = Number(c.z) || 0;
    const dx = x - cx, dy = y - cy;
    const distP = Math.hypot(dx, dy);
    if (distP < 1e-3) return zc;

    let minT = Infinity;
    let edgeI = -1;
    let edgeU = 0;

    for (let i = 0; i < points.length; i++) {
        const j = (i + 1) % points.length;
        const x1 = points[i].x, y1 = points[i].y;
        const x2 = points[j].x, y2 = points[j].y;

        const sx = x2 - x1;
        const sy = y2 - y1;
        const rxs = dx * sy - dy * sx;
        if (Math.abs(rxs) < 1e-6) continue; // paralelos

        const qpx = x1 - cx;
        const qpy = y1 - cy;

        const t = (qpx * sy - qpy * sx) / rxs;         // parámetro sobre el rayo
        const u = (qpx * dy - qpy * dx) / rxs;         // parámetro sobre el segmento [0,1]

        if (t > 0 && u >= 0 && u <= 1 && t < minT) {
            minT = t;
            edgeI = i;
            edgeU = u;
        }
    }

    if (!isFinite(minT) || edgeI < 0) return null;

    const j = (edgeI + 1) % points.length;
    const z1 = Number(points[edgeI].z) || 0;
    const z2 = Number(points[j].z) || 0;
    const zborde = z1 + edgeU * (z2 - z1);

    const distBorde = minT * distP;
    if (distBorde < 1e-3) return zborde;
    const tRad = Math.max(0, Math.min(1, distP / distBorde));

    return zc + tRad * (zborde - zc);
}

// Altura del plot:
// - Con 1 punto central: superficie RADIAL entre Z del centro y Z del perímetro (piramidal).
//   H(x,y) = Zacabado_radial(x,y) (la altura que has definido como “suelo→baldosa”).
// - En otros casos: Zacabado via triangulación (getZAt).
function calcularAlturaPlotEn(x, y) {
    let zAcabado = null;

    // Caso 1: un solo punto central → usamos interpolación radial tipo “pirámide”.
    if (drainagePoints.length === 1 && points.length >= 3) {
        zAcabado = getZRadialAt(x, y);
    }

    // Fallback: sin punto central (o más de uno), usamos la triangulación clásica.
    if (zAcabado == null) {
        zAcabado = getZAt(x, y);
    }
    if (zAcabado == null) return null;

    // Interpretamos Zacabado como la altura total desde el forjado hasta la cara superior de la baldosa.
    const alturaSoporte = Number(zAcabado);
    return Math.max(0, alturaSoporte);
}

