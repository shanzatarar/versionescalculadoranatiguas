const RULER_SIZE = 30;

function getZoomedLineWidth(baseWidth) {
    const w = baseWidth / Math.sqrt(viewZoom || 1);
    return Math.min(Math.max(w, 0.6), baseWidth * 1.4);
}

function snapToPixel(v) {
    return Math.round(v) + 0.5;
}

function drawTrashIcon(x, y, offsetX = TRASH_OFFSET_X, offsetY = TRASH_OFFSET_Y) {
    const tx = x + offsetX, ty = y + offsetY;
    ctx.save();
    ctx.fillStyle = "#cc0000"; ctx.beginPath();
    ctx.arc(tx, ty, 12, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = "white"; ctx.lineWidth = 2; ctx.beginPath();
    ctx.moveTo(tx - 5, ty - 5); ctx.lineTo(tx + 5, ty + 5);
    ctx.moveTo(tx + 5, ty - 5); ctx.lineTo(tx - 5, ty + 5);
    ctx.stroke(); ctx.restore();
}

const drawSlopeInfo = (p1, p2, color = "#666") => {
    const dx = p2.x - p1.x;
    const dy = p2.y - p1.y;
    const distPx = Math.sqrt(dx * dx + dy * dy);
    if (distPx < 15) return;
    const distM = distPx / ESCALA_PX_METRO;
    const slopeVal = distM > 0.01 ? ((p1.z - p2.z) / (distM * 1000)) * 100 : 0;
    const absSlope = Math.abs(slopeVal).toFixed(1);
    const midX = (p1.x + p2.x) / 2;
    const midY = (p1.y + p2.y) / 2;
    if (Math.abs(slopeVal) <= 0.1) return;

    const angle = Math.atan2(dy, dx);
    const direction = slopeVal > 0 ? angle : angle + Math.PI;
    const len = 12;

    ctx.save();
    ctx.translate(midX, midY);
    ctx.rotate(direction);
    ctx.strokeStyle = (color === "#004a8e") ? "rgba(0, 74, 142, 0.9)" : "rgba(245, 158, 11, 0.92)";
    ctx.lineWidth = 2.2;
    ctx.lineCap = "round";
    ctx.beginPath();
    ctx.moveTo(-len / 2, 0);
    ctx.lineTo(len / 2, 0);
    ctx.moveTo(len / 2, 0);
    ctx.lineTo(len / 2 - 4, -4);
    ctx.moveTo(len / 2, 0);
    ctx.lineTo(len / 2 - 4, 4);
    ctx.stroke();
    ctx.restore();
};

function drawBigSlopeArrows() {
    if (!isClosed || !points.length || !showSlopes) return;

    let sumX = 0, sumY = 0;
    points.forEach(p => { sumX += p.x; sumY += p.y; });
    const cx = sumX / points.length;
    const cy = sumY / points.length;

    let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
    points.forEach(p => {
        minX = Math.min(minX, p.x);
        maxX = Math.max(maxX, p.x);
        minY = Math.min(minY, p.y);
        maxY = Math.max(maxY, p.y);
    });
    const ancho = maxX - minX;
    const alto  = maxY - minY;
    const baseLen = Math.max(60, Math.min(ancho, alto) * 0.25);

    let modo = "none";
    if (drainagePoints.length === 1 && points.length >= 3) {
        const dp = drainagePoints[0];
        const zPerimetroMedio = points.reduce((a, p) => a + (p.z || 0), 0) / points.length;
        modo = (dp.z || 0) <= zPerimetroMedio ? "inward" : "outward";
    }
    if (modo === "none") return;

    const drawArrowShape = (x1, y1, x2, y2) => {
        const dx = x2 - x1;
        const dy = y2 - y1;
        const len = Math.hypot(dx, dy);
        if (len < 30) return;
        const angle = Math.atan2(dy, dx);

        ctx.save();
        ctx.translate(x1, y1);
        ctx.rotate(angle);

        const cuerpo = len * 0.6;
        const altoF = 18;

        ctx.beginPath();
        ctx.moveTo(0, -altoF / 2);
        ctx.lineTo(cuerpo, -altoF / 2);
        ctx.lineTo(cuerpo, -altoF);
        ctx.lineTo(len, 0);
        ctx.lineTo(cuerpo, altoF);
        ctx.lineTo(cuerpo, altoF / 2);
        ctx.lineTo(0, altoF / 2);
        ctx.closePath();
        ctx.fill();

        ctx.restore();
    };

    ctx.save();
    ctx.globalAlpha = 0.22;
    ctx.fillStyle = "rgba(245, 158, 11, 1)";

    const dirs = [
        { dx:  1, dy:  0 },
        { dx: -1, dy:  0 },
        { dx:  0, dy:  1 },
        { dx:  0, dy: -1 }
    ];

    dirs.forEach(d => {
        const ux = d.dx;
        const uy = d.dy;
        const offset = baseLen * 0.3;

        let tailX, tailY, headX, headY;
        if (modo === "outward") {
            tailX = cx;
            tailY = cy;
            headX = cx + ux * baseLen;
            headY = cy + uy * baseLen;
        } else {
            tailX = cx + ux * (baseLen + offset);
            tailY = cy + uy * (baseLen + offset);
            headX = cx + ux * offset;
            headY = cy + uy * offset;
        }
        drawArrowShape(tailX, tailY, headX, headY);
    });

    ctx.restore();
}

function drawProfessionalRulers() {
    ctx.save();
    ctx.fillStyle = "#f1f3f4";
    ctx.fillRect(0, 0, canvas.width, RULER_SIZE);
    ctx.fillRect(0, 0, RULER_SIZE, canvas.height);
    ctx.strokeStyle = "#dadce0";
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(0, RULER_SIZE); ctx.lineTo(canvas.width, RULER_SIZE);
    ctx.moveTo(RULER_SIZE, 0); ctx.lineTo(RULER_SIZE, canvas.height);
    ctx.stroke();
    ctx.fillStyle = "#70757a";
    ctx.font = "10px Inter, Roboto, Arial";
    ctx.strokeStyle = "#bdc1c6";
    const ESCALA = 75;
    const SUBDIVISION = ESCALA / 5;
    ctx.textAlign = "center";
    for (let x = RULER_SIZE; x < canvas.width; x += SUBDIVISION) {
        let posRelativa = Math.round(x - RULER_SIZE);
        let esMetro = posRelativa % ESCALA === 0;
        let esEtiqueta = posRelativa % (ESCALA * 2) === 0;

        ctx.beginPath();
        ctx.moveTo(x, RULER_SIZE);
        ctx.lineTo(x, esMetro ? (esEtiqueta ? 5 : 12) : 22);
        ctx.stroke();

        if (esEtiqueta) {
            let metros = (posRelativa / ESCALA).toFixed(0);
            ctx.fillText(metros + "m", x, 14);
        }
    }
    ctx.textAlign = "left";
    for (let y = RULER_SIZE; y < canvas.height; y += SUBDIVISION) {
        let posRelativa = Math.round(y - RULER_SIZE);
        let esMetro = posRelativa % ESCALA === 0;
        let esEtiqueta = posRelativa % (ESCALA * 2) === 0;

        ctx.beginPath();
        ctx.moveTo(RULER_SIZE, y);
        ctx.lineTo(esMetro ? (esEtiqueta ? 5 : 12) : 22, y);
        ctx.stroke();

        if (esEtiqueta) {
            let metros = (posRelativa / ESCALA).toFixed(0);
            ctx.save();
            ctx.translate(12, y);
            ctx.rotate(-Math.PI / 2);
            ctx.fillText(metros + "m", 0, 0);
            ctx.restore();
        }
    }
    if (mousePos.x > RULER_SIZE && mousePos.y > RULER_SIZE) {
        ctx.strokeStyle = "#1a73e8";
        ctx.lineWidth = 1;

        ctx.beginPath();
        ctx.moveTo(mousePos.x, 0);
        ctx.lineTo(mousePos.x, RULER_SIZE);
        ctx.stroke();
        ctx.beginPath();
        ctx.moveTo(0, mousePos.y);
        ctx.lineTo(RULER_SIZE, mousePos.y);
        ctx.stroke();
        let mX = ((mousePos.x - RULER_SIZE) / ESCALA).toFixed(2);
        let mY = ((mousePos.y - RULER_SIZE) / ESCALA).toFixed(2);
        ctx.fillStyle = "#1a73e8";
        ctx.fillText(`${mX}, ${mY} m`, mousePos.x + 10, mousePos.y - 10);
    }
    ctx.fillStyle = "#fff";
    ctx.fillRect(0, 0, RULER_SIZE, RULER_SIZE);
    ctx.strokeRect(0, 0, RULER_SIZE, RULER_SIZE);

    ctx.restore();
}

function draw() {
    if (!ctx) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    if (isClosed) {
        calcularMetricas();
        renderSlopeMap();
    } else if (sCtx && slopeCanvas) {
        sCtx.clearRect(0, 0, slopeCanvas.width, slopeCanvas.height);
    }

    if (backgroundImage && showBgImage) {
        ctx.save();
        ctx.globalAlpha = 0.4;
        const imgScale = parseFloat(document.getElementById('bgScale')?.value) || 1;
        const offX = parseFloat(document.getElementById('bgPosX')?.value) || 0;
        const offY = parseFloat(document.getElementById('bgPosY')?.value) || 0;
        const imgW = backgroundImage.width * imgScale;
        const imgH = backgroundImage.height * imgScale;
        const x = (canvas.width - imgW) / 2 + offX;
        const y = (canvas.height - imgH) / 2 + offY;
        ctx.drawImage(backgroundImage, x, y, imgW, imgH);
        ctx.restore();
    }
    ctx.strokeStyle = "rgba(238, 238, 238, 0.5)"; 
    ctx.lineWidth = getZoomedLineWidth(0.9);
    for(let i=0; i<canvas.width; i+=GRID_SIZE){
        const x = snapToPixel(i);
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, canvas.height);
        ctx.stroke();
    }
    for(let i=0; i<canvas.height; i+=GRID_SIZE){
        const y = snapToPixel(i);
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(canvas.width, y);
        ctx.stroke();
    }
    ctx.save();
    ctx.setLineDash([5, 5]); 
    ctx.strokeStyle = "rgba(0, 74, 142, 0.3)";
    const mx = snapToPixel(mousePos.x);
    const my = snapToPixel(mousePos.y);
    ctx.beginPath(); ctx.moveTo(mx, 0); ctx.lineTo(mx, canvas.height); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(0, my); ctx.lineTo(canvas.width, my); ctx.stroke();
    ctx.restore();
    if (currentStep >= 3) renderReplanteo();

    if (!points.length) {
        drawProfessionalRulers();
        renderHtmlOverlays();
        return;
    }

    ctx.save();
    if(isClosed) {
        ctx.shadowColor = "rgba(0,0,0,0.2)";
        ctx.shadowBlur = 10;
        ctx.shadowOffsetY = 5;
    }
    ctx.beginPath();
    ctx.strokeStyle = "#004a8e"; ctx.lineWidth = getZoomedLineWidth(2);
    points.forEach((p, i) => {
        const x = snapToPixel(p.x);
        const y = snapToPixel(p.y);
        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
    });
    if (isClosed) {
        ctx.closePath(); ctx.stroke();
        ctx.restore();
        for (let i = 0; i < points.length; i++) {
            drawSlopeInfo(points[i], points[(i + 1) % points.length], "#004a8e");
        }
    } else { ctx.stroke(); ctx.restore(); }

    if (points.length > 0 && !isClosed) {
        const lastP = points[points.length - 1];
        let target = (hoverCloseFirst && points[0]) ? points[0] : mousePos;

        let snapDir = null;
        if (currentStep === 1 && directionGizmo && typeof directionGizmo.hoverDir === "number") {
            snapDir = directionGizmo.hoverDir;
        } else {
            const dx = target.x - lastP.x;
            const dy = target.y - lastP.y;
            if (Math.hypot(dx, dy) > 10) {
                let ang = (Math.atan2(dy, dx) * 180 / Math.PI);
                if (ang > 180) ang -= 360;
                const candidatos = [0, 90, 180, -90];
                let best = null;
                let bestDiff = 999;
                candidatos.forEach(a => {
                    const d = Math.abs(ang - a);
                    if (d < bestDiff) { bestDiff = d; best = a; }
                });
                const umbral = 5;
                if (best !== null && bestDiff <= umbral) {
                    snapDir = best;
                }
            }
        }

        if (snapDir !== null) {
            const dx = target.x - lastP.x;
            const dy = target.y - lastP.y;
            const angRad = (snapDir * Math.PI) / 180;
            let dist = dx * Math.cos(angRad) + dy * Math.sin(angRad);
            if (dist < 0) dist = 0;
            target = {
                x: lastP.x + dist * Math.cos(angRad),
                y: lastP.y + dist * Math.sin(angRad)
            };
        }

        ctx.save();
        ctx.beginPath();
        ctx.setLineDash([5, 5]);
        ctx.strokeStyle = "rgba(0, 74, 142, 0.5)";
        ctx.lineWidth = 2;
        ctx.moveTo(lastP.x, lastP.y);
        ctx.lineTo(target.x, target.y);
        ctx.stroke();
        ctx.restore();

        if (points.length >= 2) {
            const p0 = points[0];
            const preview = target;
            const sugerido = { x: p0.x, y: preview.y };

            ctx.save();
            ctx.setLineDash([4, 4]);
            ctx.strokeStyle = "rgba(148, 163, 184, 0.9)";
            ctx.lineWidth = 1;
            ctx.beginPath();
            ctx.moveTo(preview.x, preview.y);
            ctx.lineTo(sugerido.x, sugerido.y);
            ctx.stroke();
            ctx.beginPath();
            ctx.moveTo(p0.x, p0.y);
            ctx.lineTo(sugerido.x, sugerido.y);
            ctx.stroke();
            ctx.fillStyle = "#0f172a";
            ctx.beginPath();
            ctx.arc(sugerido.x, sugerido.y, 4, 0, Math.PI * 2);
            ctx.fill();
            ctx.restore();
        }

        const distM = Math.sqrt((target.x - lastP.x)**2 + (target.y - lastP.y)**2) / ESCALA_PX_METRO;
        
        ctx.fillStyle = "#004a8e";
        ctx.font = "bold 12px Arial";
        ctx.textAlign = "left";
        ctx.fillText(distM.toFixed(2) + " m", target.x + 15, target.y - 15);
    }

    if (currentStep === 3 && anglePreviewDragging && anglePreviewStart && anglePreviewCurrent) {
        ctx.save();
        ctx.strokeStyle = "#16a34a";
        ctx.lineWidth = 2;
        ctx.setLineDash([8, 4]);
        ctx.beginPath();
        ctx.moveTo(anglePreviewStart.x, anglePreviewStart.y);
        ctx.lineTo(anglePreviewCurrent.x, anglePreviewCurrent.y);
        ctx.stroke();
        ctx.restore();
    } else if (currentStep === 3 && hoveredPoint != null && points.length >= 2) {
        const idx = hoveredPoint;
        const angDeg = getAngleForPerimeterPoint(idx);
        if (angDeg != null) {
            const rad = (angDeg * Math.PI) / 180;
            const cosA = Math.cos(rad);
            const sinA = Math.sin(rad);

            const formatoSelect = document.getElementById('tileFormat')?.value || "60,60";
            const [selectedW, selectedH] = formatoSelect.split(',').map(Number);
            const tW = selectedW * 0.75;
            const tH = selectedH * 0.75;

            const p = points[idx];

            let ux = cosA;
            let uy = sinA;
            let vx = -sinA;
            let vy =  cosA;

            let cxPoly = 0, cyPoly = 0;
            points.forEach(pt => { cxPoly += pt.x; cyPoly += pt.y; });
            cxPoly /= points.length;
            cyPoly /= points.length;
            const toCenterX = cxPoly - p.x;
            const toCenterY = cyPoly - p.y;
            if (toCenterX * vx + toCenterY * vy < 0) {
                vx = -vx;
                vy = -vy;
            }

            const c0 = { x: p.x,                       y: p.y };
            const c1 = { x: p.x + ux * tW,             y: p.y + uy * tW };
            const c2 = { x: c1.x + vx * tH,            y: c1.y + vy * tH };
            const c3 = { x: p.x + vx * tH,             y: p.y + vy * tH };
            const corners = [c0, c1, c2, c3];

            ctx.save();
            ctx.fillStyle = "rgba(248, 113, 113, 0.25)";
            ctx.strokeStyle = "rgba(220, 38, 38, 0.9)";
            ctx.lineWidth = 1.2;
            ctx.beginPath();
            ctx.moveTo(corners[0].x, corners[0].y);
            for (let i = 1; i < corners.length; i++) {
                ctx.lineTo(corners[i].x, corners[i].y);
            }
            ctx.closePath();
            ctx.fill();
            ctx.stroke();
            ctx.restore();
        }
    }

    let prevHoverDir = directionGizmo && directionGizmo.hoverDir;
    directionGizmo = null;
    if (currentStep === 1 && !isClosed && points.length > 0) {
        const p = points[points.length - 1];
        const size = 86;
        const half = size / 2;

        ctx.save();

        if (dirFrameImg.complete) {
            ctx.drawImage(dirFrameImg, p.x - half, p.y - half, size, size);
        } else {
            ctx.strokeStyle = "#94a3b8";
            ctx.lineWidth = 1.5;
            ctx.strokeRect(p.x - half, p.y - half, size, size);
        }

        const dirs = [-90, 0, 90, 180];
        dirs.forEach((dir) => {
            const dirRad = (dir * Math.PI) / 180;

            let armLen = half;
            if (dir === 180 || dir === 90) {
                armLen = half * 0.85;
            }

            let cx = p.x + Math.cos(dirRad) * armLen;
            let cy = p.y + Math.sin(dirRad) * armLen;

            if (dir === -90) {
                cx -= 23.5;
                cy += 24;
            } else if (dir === 90) {
                cy -= 18;
                cx -= 23.5;
            } else if (dir === 180) {
                cx += 40;
            }

            ctx.save();
            ctx.translate(cx, cy);
            ctx.rotate(dirRad);

            const arrowSize = 14;
            const offsetTowardCenter = -24;
            ctx.translate(Math.cos(dirRad) * offsetTowardCenter, Math.sin(dirRad) * offsetTowardCenter);

            const isHover = (prevHoverDir === dir);
            ctx.strokeStyle = isHover ? "#facc15" : "#ffffff";
            ctx.lineWidth = 2.2;
            ctx.lineCap = "round";
            ctx.beginPath();
            ctx.moveTo(-arrowSize / 2, 0);
            ctx.lineTo(arrowSize / 2, 0);
            ctx.beginPath();
            ctx.moveTo(arrowSize / 2, 0);
            ctx.lineTo(arrowSize / 2 - 6, -6);
            ctx.moveTo(arrowSize / 2, 0);
            ctx.lineTo(arrowSize / 2 - 6, 6);
            ctx.stroke();
            ctx.restore();
        });

        ctx.save();
        ctx.fillStyle = "#111827";
        ctx.font = "600 14px 'Inter Tight', system-ui, sans-serif";
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        ctx.fillText(getLabel(points.length - 1), p.x, p.y);
        ctx.restore();

        ctx.restore();
        directionGizmo = {
            index: points.length - 1,
            cx: p.x,
            cy: p.y,
            size,
            hoverDir: prevHoverDir
        };
    }

    if (isClosed && showSlopes) {
        const allNodes = [...points, ...drainagePoints];

        triangles.forEach((tri) => {
            const p0 = allNodes[tri.v[0]];
            const p1 = allNodes[tri.v[1]];
            const p2 = allNodes[tri.v[2]];
            if (!p0 || !p1 || !p2) return;

            ctx.save(); 
            ctx.setLineDash([4, 4]);
            ctx.strokeStyle = "rgba(150, 150, 150, 0.3)";
            ctx.beginPath();
            ctx.moveTo(p0.x, p0.y);
            ctx.lineTo(p2.x, p2.y);
            ctx.stroke(); 
            ctx.restore();

            drainagePoints.forEach(dp => {
                if (isPointInTriangle(dp, p0, p1, p2)) {
                    [p0, p1, p2].forEach(v => {
                        ctx.save(); 
                        ctx.setLineDash([2, 2]);
                        ctx.strokeStyle = "rgba(0, 74, 142, 0.2)";
                        ctx.beginPath();
                        ctx.moveTo(dp.x, dp.y);
                        ctx.lineTo(v.x, v.y);
                        ctx.stroke(); 
                        ctx.restore();

                        drawSlopeInfo(v, dp, "#f59e0b");
                    });
                }
            });
        });
    }

    points.forEach((p, i) => {
        const isHovered = (hoveredPoint === i);

        if (showPerimeterPoints) {
            const gizmoIndex = directionGizmo ? directionGizmo.index : -1;
            if (!(currentStep === 1 && !isClosed && i === gizmoIndex)) {
                ctx.fillStyle = isHovered ? "#ffcc00" : "#004a8e";
                ctx.beginPath(); ctx.arc(p.x, p.y, 12, 0, Math.PI * 2); ctx.fill();
                ctx.fillStyle = "white";
                ctx.beginPath(); ctx.arc(p.x, p.y, 9, 0, Math.PI * 2); ctx.fill();
            }
            
            if (isHovered && !isDraggingOrigin && (currentStep === 1 || currentStep === 2)) {
                drawTrashIcon(p.x, p.y);
            }

            if (!isClosed && i === 0 && hoverCloseFirst) {
                ctx.save();
                ctx.strokeStyle = "#22c55e";
                ctx.lineWidth = 3;
                ctx.beginPath();
                ctx.arc(p.x, p.y, 16, 0, Math.PI * 2);
                ctx.stroke();
                ctx.restore();
            }
        }
    });
    drainagePoints.forEach((dp, i) => {
        const isHovered = (hoveredDrainage === i);
        ctx.fillStyle = "#facc15";
        ctx.strokeStyle = isHovered ? "#b91c1c" : "#1f2937";
        ctx.lineWidth = 2.5;
        ctx.beginPath();
        ctx.arc(dp.x, dp.y, 11, 0, Math.PI * 2);
        ctx.fill();
        ctx.stroke();
        
        ctx.strokeStyle = "#ffffff";
        ctx.lineWidth = 2;
        ctx.beginPath(); ctx.moveTo(dp.x - 5, dp.y); ctx.lineTo(dp.x + 5, dp.y); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(dp.x, dp.y - 5); ctx.lineTo(dp.x, dp.y + 5); ctx.stroke();

        if (isHovered && (currentStep === 1 || currentStep === 2)) {
            drawTrashIcon(dp.x, dp.y, TRASH_DRAINAGE_OFFSET_X, TRASH_DRAINAGE_OFFSET_Y);
        }
    });

    renderHtmlOverlays();

    const plotTooltip = document.getElementById('pg-plot-tooltip');
    const plotTooltipText = document.getElementById('pg-plot-tooltip-text');
    if (plotTooltip && plotTooltipText) {
        if (currentStep === 3 && hoveredPlot) {
            const altura = calcularAlturaPlotEn(hoveredPlot.x, hoveredPlot.y);
            if (altura !== null) {
                const infoSoporte = getInfoSoporte(altura);
                const textoAltura = `H: ${Math.round(altura)} mm · ${infoSoporte.nombre}`;
                plotTooltipText.textContent = textoAltura;
                plotTooltip.style.display = "block";
                plotTooltip.style.left = `${hoveredPlot.x + 18}px`;
                plotTooltip.style.top = `${hoveredPlot.y - 40}px`;
            } else {
                plotTooltip.style.display = "none";
            }
        } else {
            plotTooltip.style.display = "none";
        }
    }
    if (isClosed) {
        const piezasVal = document.getElementById('piezasVal');
        if (piezasVal) piezasVal.innerText = tempPlots.size;

        const piezasCorteVal = document.getElementById('piezasCorteVal');
        if (piezasCorteVal) piezasCorteVal.innerText = calcularCortesPerimetrales();
    }
    drawProfessionalRulers();
}

function dibujarTextoLegible(contexto, texto, x, y, color, escala = 1) {
    contexto.save();
    const fontSize = Math.max(12, 15 / escala);
    contexto.font = `bold ${fontSize}px Arial`;
    contexto.textAlign = "center";
    const paddingX = 8 / escala;
    const paddingY = 4 / escala;
    const textWidth = contexto.measureText(texto).width;
    contexto.fillStyle = "rgba(255,255,255,0.96)";
    contexto.strokeStyle = "rgba(220,38,38,0.8)";
    contexto.lineWidth = 1.2 / escala;
    contexto.beginPath();
    contexto.roundRect(
        x - textWidth / 2 - paddingX,
        y - fontSize - paddingY,
        textWidth + paddingX * 2,
        fontSize + paddingY * 2,
        8 / escala
    );
    contexto.fill();
    contexto.stroke();
    contexto.fillStyle = color;
    contexto.fillText(texto, x, y - 1);
    contexto.restore();
}

