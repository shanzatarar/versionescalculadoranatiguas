// ========== CANVAS Y ESTADO GLOBAL ==========
const canvas = document.getElementById('pgCanvas');
const ctx = canvas.getContext('2d');
let points = [], drainagePoints = [], triangles = [], isClosed = false, currentStep = 1;
let mousePos = { x: 0, y: 0 }, hoveredPoint = null, hoveredDrainage = null;
let tempPlots = new Set();
let tileWidth = 60, tileHeight = 60, rotationAngle = 0;
let gridOrigin = { x: 500, y: 350 }, isDraggingOrigin = false;
// Replanteo: selección de origen y ángulo interactivo
let pendingTileOriginSelection = false;
let anglePreviewActive = false;
let anglePreviewDragging = false;
let anglePreviewStart = null;    // { x, y } punto del perímetro
let anglePreviewCurrent = null;  // { x, y } posición actual del ratón
let anglePreviewPointIndex = null;
let backgroundImage = null;
let draggingPoint = null, draggingDrainage = null, hoveredPlot = null;
let planMode = 'perimeter';
let isMovingAll = false;
// Grosor de la baldosa en mm (editable desde el panel)
let tileThicknessMm = 20;

// Edición de cotas Z en popup
let zEditIndex = null;

// Zoom propio de la vista (independiente del zoom del navegador)
let viewZoom = 1;

function applyViewZoom(newZoom) {
    const inner = document.getElementById('pg-canvas-inner');
    if (!inner) return;
    viewZoom = newZoom;
    inner.style.transform = `scale(${viewZoom})`;
    // Redibujar para asegurarnos de que overlays y mapas se recalculan correctamente.
    draw();
}

// Ancho de trazo adaptado al zoom interno: al hacer zoom out, engrosamos un poco
// las líneas para que no desaparezcan; al hacer zoom in, las hacemos algo más finas.
function getZoomedLineWidth(baseWidth) {
    const w = baseWidth / Math.sqrt(viewZoom || 1);
    return Math.min(Math.max(w, 0.6), baseWidth * 1.4);
}

// Para que las líneas horizontales/verticales se vean más nítidas en canvas,
// alineamos el trazo al centro del píxel (x.5 / y.5) sin modificar los datos
// geométricos (points[], drainagePoints...). Esto ayuda al antialias.
function snapToPixel(v) {
    return Math.round(v) + 0.5;
}

// Calcula el ángulo (en grados) que se aplicaría a la malla
// si el usuario hace clic rápido en el punto de perímetro idx,
// alineando el lado corto de la baldosa con el tramo hacia el siguiente punto.
function getAngleForPerimeterPoint(idx) {
    if (!points || points.length < 2) return null;
    const p = points[idx];
    const next = points[(idx + 1) % points.length];
    if (!p || !next) return null;
    const dx = next.x - p.x;
    const dy = next.y - p.y;
    if (Math.hypot(dx, dy) <= 0.001) return null;

    let baseAng = (Math.atan2(dy, dx) * 180 / Math.PI);
    if (baseAng < 0) baseAng += 360;

    const formatoSelect = document.getElementById('tileFormat')?.value || "60,60";
    const [selectedW, selectedH] = formatoSelect.split(',').map(Number);
    const ladoCortoEsW = selectedW <= selectedH;

    // En renderReplanteo, el lado de longitud tW va en la dirección rotationAngle,
    // y el de tH va en rotationAngle + 90°. Si W es el lado corto, lo alineamos
    // directamente con el tramo (rotationAngle = baseAng). Si H es el corto,
    // lo alineamos con el tramo usando rotationAngle = baseAng - 90.
    const offset = ladoCortoEsW ? 0 : -90;
    return baseAng + offset;
}

// Capas de visibilidad en el dibujo principal
let showBgImage = true;              // mostrar / ocultar imagen de fondo
let showPerimeterHeights = true;     // mostrar / ocultar cotas Z en los puntos perimetrales
let showSlopes = true;               // mostrar / ocultar pendientes (flechas entre perímetro y sumideros)
let showAngles = true;               // mostrar / ocultar % y distancia en los lados del perímetro
let showPerimeterPoints = true;      // mostrar / ocultar los nodos del perímetro (círculos A, B, C…)

// Hover de cierre del perímetro (snap al primer punto)
let hoverCloseFirst = false;

// Gizmo de direcciones para definir siguiente punto por distancia/ángulo
// directionGizmo: { index, cx, cy, size, hoverDir }
let directionGizmo = null;

// Imágenes para el nuevo gizmo (marco + flecha)
const dirFrameImg = new Image();
dirFrameImg.src = "assets/img/CRUZ.svg";
const dirArrowImg = new Image();
dirArrowImg.src = "assets/img/FLECHA.svg";

// Modo de plots centrales: 'auto' (por tamaño/desnivel) u 'off' (desactivado)
let centralMode = 'auto';
const MAX_HISTORY = 50;
let undoHistory = [], undoIndex = -1;

function getUndoState() {
    return {
        points: JSON.parse(JSON.stringify(points)),
        drainagePoints: JSON.parse(JSON.stringify(drainagePoints)),
        isClosed: isClosed
    };
}

function setUndoState(state) {
    points.length = 0;
    points.push(...state.points);
    drainagePoints.length = 0;
    drainagePoints.push(...state.drainagePoints);
    isClosed = state.isClosed;
    updateTriangulation();
    syncPointsTable();
    draw();
}

function pushUndoState() {
    const state = getUndoState();
    if (undoIndex < undoHistory.length - 1) {
        undoHistory = undoHistory.slice(0, undoIndex + 1);
    }
    undoHistory.push(state);
    if (undoHistory.length > MAX_HISTORY) undoHistory.shift();
    undoIndex = undoHistory.length - 1;
}

function undo() {
    if (undoIndex <= 0) return;
    undoIndex--;
    setUndoState(undoHistory[undoIndex]);
}

function redo() {
    if (undoIndex >= undoHistory.length - 1) return;
    undoIndex++;
    setUndoState(undoHistory[undoIndex]);
}

// Atajos de teclado: deshacer / rehacer
window.addEventListener('keydown', (e) => {
    const key = e.key.toLowerCase();
    const meta = e.metaKey || e.ctrlKey;
    if (!meta) return;

    // Cmd/Ctrl + Z → deshacer
    if (key === 'z' && !e.shiftKey) {
        e.preventDefault();
        undo();
        return;
    }
    // Cmd/Ctrl + Shift + Z o Cmd/Ctrl + Y → rehacer
    if ((key === 'z' && e.shiftKey) || key === 'y') {
        e.preventDefault();
        redo();
    }
});

// ========== CONFIGURACIÓN GAMA ARKIMEDE ==========
const RULER_SIZE = 30;
const SERIES_SOPORTES = {
    // Colores de más bajo a más alto:
    // ffcc00, ff8400, 54c32d, 3b9cff, 4228e0, a200ee, b90039
    "ARK10":  { nombre: "Arkimede 10 (10-20mm)",  max: 20,  color: "#ffcc00" },
    "ARK18":  { nombre: "Arkimede 18 (18-36mm)",  max: 36,  color: "#ff8400" },
    "ARK35":  { nombre: "Arkimede 35 (35-60mm)",  max: 60,  color: "#54c32d" },
    "ARK60":  { nombre: "Arkimede 60 (60-115mm)", max: 115, color: "#3b9cff" },
    "ARK115": { nombre: "Arkimede 115 (115-220mm)", max: 220, color: "#4228e0" },
    // Extensiones / alturas muy altas: morados / rojo oscuro
    "ARK_EXT": { nombre: "ARK 115 + Extensiones", max: 1000, color: "#a200ee" }
};

let PLOTS_SERIES = [];

// Config editable de series (para activar/desactivar gamas)
let SERIES_CONFIG = [
    { id: "ARK10",  enabled: true },
    { id: "ARK18",  enabled: true },
    { id: "ARK35",  enabled: true },
    { id: "ARK60",  enabled: true },
    { id: "ARK115", enabled: true }
];

function cargarSeriesDesdeJson() {
    fetch('plots.json')
        .then(r => r.json())
        .then(data => {
            PLOTS_SERIES = Array.isArray(data) ? data : [];
            PLOTS_SERIES.forEach(item => {
                const serie = SERIES_SOPORTES[item.id];
                if (serie) {
                    if (item.nombre) {
                        const sufijo = item.rango_mm ? ` (${item.rango_mm}mm)` : "";
                        serie.nombre = item.nombre + sufijo;
                    }
                    if (item.altura_max) serie.max = item.altura_max;
                    if (item.color) serie.color = item.color;
                }
            });
        })
        .catch(() => {
            // Si falla el JSON, seguimos con la configuración por defecto.
        });
}

cargarSeriesDesdeJson();

function cargarSeriesConfigDesdeStorage() {
    try {
        const raw = window.localStorage.getItem("dakotaSeriesConfig");
        if (!raw) return;
        const parsed = JSON.parse(raw);
        if (!Array.isArray(parsed)) return;
        SERIES_CONFIG = SERIES_CONFIG.map(def => {
            const found = parsed.find(p => p.id === def.id);
            return found ? { id: def.id, enabled: !!found.enabled } : def;
        });
    } catch (e) {
        // ignorar errores de lectura
    }
}

function guardarSeriesConfigEnStorage() {
    try {
        window.localStorage.setItem("dakotaSeriesConfig", JSON.stringify(SERIES_CONFIG));
    } catch (e) {
        // ignorar
    }
}

function renderSeriesConfigUI() {
    const cont = document.getElementById('ark-config-list');
    if (!cont) return;
    cont.innerHTML = "";

    SERIES_CONFIG.forEach((cfg, idx) => {
        const serie = SERIES_SOPORTES[cfg.id];
        if (!serie) return;
        const row = document.createElement('label');
        row.style.display = "flex";
        row.style.alignItems = "center";
        row.style.gap = "6px";
        row.style.marginBottom = "4px";

        row.innerHTML = `
            <input type="checkbox" data-idx="${idx}" ${cfg.enabled ? "checked" : ""} />
            <span style="width:10px;height:10px;border-radius:999px;background:${serie.color};border:1px solid #94a3b8;"></span>
            <span>${serie.nombre}</span>
        `;
        cont.appendChild(row);
    });

    cont.querySelectorAll('input[type="checkbox"]').forEach(input => {
        input.addEventListener('change', (e) => {
            const idx = parseInt(e.target.dataset.idx, 10);
            if (Number.isNaN(idx) || !SERIES_CONFIG[idx]) return;
            SERIES_CONFIG[idx].enabled = e.target.checked;
            guardarSeriesConfigEnStorage();
            draw();
        });
    });
}

cargarSeriesConfigDesdeStorage();
window.addEventListener('load', renderSeriesConfigUI);

// Mostrar ficha rápida de las series Arkimede (desde plots.json)
window.mostrarInfoSeries = () => {
    let soportes;
    if (Array.isArray(PLOTS_SERIES) && PLOTS_SERIES.length) {
        soportes = PLOTS_SERIES.filter(s => s.categoria === "soporte");
    } else {
        // Fallback local cuando no se puede leer plots.json (p.ej. abriendo el HTML como file://)
        soportes = Object.entries(SERIES_SOPORTES).map(([id, serie]) => ({
            id,
            nombre: serie.nombre,
            rango_mm: serie.max ? `0-${serie.max}` : "",
            refs: []
        }));
    }

    let msg = "Series Arkimede (rangos de altura):\n\n";
    soportes.forEach(s => {
        const refs = (s.refs && s.refs.length) ? ` · refs: ${s.refs.join(', ')}` : "";
        msg += `- ${s.nombre}${s.rango_mm ? ` (${s.rango_mm} mm)` : ""}${refs}\n`;
    });
    alert(msg);
};

// Identificación de soporte según altura (mm)
function getInfoSoporte(altura) {
    if (altura <= 0) return { nombre: "Sin altura", color: "#ecf0f1" };

    // Usamos la configuración editable: series activas ordenadas por altura máxima
    const activas = SERIES_CONFIG
        .filter(cfg => cfg.enabled && SERIES_SOPORTES[cfg.id])
        .map(cfg => ({ id: cfg.id, ...SERIES_SOPORTES[cfg.id] }))
        .sort((a, b) => (a.max || 9999) - (b.max || 9999));

    for (const serie of activas) {
        if (altura <= serie.max) {
            return { id: serie.id, ...serie };
        }
    }

    const numExt = Math.ceil((altura - 220) / 100);
    return { 
        id: "ARK_EXT", 
        nombre: `ARK 115 + ${numExt} Ext. P100`, 
        color: SERIES_SOPORTES.ARK_EXT.color 
    };
}

syncPointsTable();

// ========== IMAGEN DE FONDO ==========
window.loadBackground = (event) => {
    const file = event.target.files[0];
    if (!file) return;

    const bgControls = document.getElementById('bg-controls');
    if (bgControls) bgControls.style.display = "block";

    const reader = new FileReader();
    reader.onload = (e) => {
        const img = new Image();
        img.onload = () => {
            backgroundImage = img;
            showBgImage = true;
            const btnClear = document.getElementById('pg-upload-clear-btn');
            if (btnClear) btnClear.style.display = 'inline-block';
            const btnToggle = document.getElementById('pg-toggle-bg-btn');
            if (btnToggle) {
                btnToggle.style.display = 'inline-block';
                btnToggle.classList.toggle('active', !showBgImage);
                btnToggle.textContent = showBgImage ? 'Ocultar fondo' : 'Mostrar fondo';
            }
            draw();
        };
        img.src = e.target.result;
    };
    reader.readAsDataURL(file);
};

window.clearBackground = () => {
    backgroundImage = null;
    showBgImage = false;
    const clearBtn = document.getElementById('pg-upload-clear-btn');
    if (clearBtn) clearBtn.style.display = 'none';
    const bgToggle = document.getElementById('pg-toggle-bg-btn');
    if (bgToggle) {
        bgToggle.style.display = 'none';
        bgToggle.classList.remove('active');
        bgToggle.textContent = 'Ocultar fondo';
    }
    const bgControls = document.getElementById('bg-controls');
    if (bgControls) bgControls.style.display = "none";
    const bgInput = document.getElementById('bgInput');
    if (bgInput) bgInput.value = "";

    const bgScale = document.getElementById('bgScale');
    const bgPosX = document.getElementById('bgPosX');
    const bgPosY = document.getElementById('bgPosY');
    if (bgScale) bgScale.value = "1";
    if (bgPosX) bgPosX.value = "0";
    if (bgPosY) bgPosY.value = "0";

    draw();
};

// Mostrar / ocultar la imagen de fondo sin perderla
window.toggleBackgroundVisibility = () => {
    if (!backgroundImage) return;
    showBgImage = !showBgImage;
    const btnToggle = document.getElementById('pg-toggle-bg-btn');
    if (btnToggle) {
        btnToggle.classList.toggle('active', !showBgImage);
        btnToggle.textContent = showBgImage ? 'Ocultar fondo' : 'Mostrar fondo';
    }
    draw();
};

const GRID_SIZE = 10;
// Para evitar problemas de zoom/corte en algunos navegadores (iPad, etc.),
// trabajamos en píxeles lógicos y fijamos DPR=1 en todos los canvas.
const DPR = 1;

function setupMainCanvasResolution() {
    if (!canvas) return;
    // Usamos el tamaño real del canvas en la interfaz (responsive)
    const rect = canvas.getBoundingClientRect();
    let logicalWidth = rect.width;
    let logicalHeight = rect.height;
    // Fallback inicial si todavía no tiene tamaño
    if (!logicalWidth || !logicalHeight) {
        logicalWidth = 1500;
        logicalHeight = 1000;
        canvas.style.width = logicalWidth + "px";
        canvas.style.height = logicalHeight + "px";
    }
    canvas.width = logicalWidth * DPR;
    canvas.height = logicalHeight * DPR;
    // Escalado para pantallas HiDPI (Retina). Mantener dibujo nítido.
    ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
    // Mejorar calidad de muestreo al redimensionar imágenes
    if (typeof ctx.imageSmoothingEnabled !== 'undefined') ctx.imageSmoothingEnabled = true;
    try { ctx.imageSmoothingQuality = 'high'; } catch (e) { /* no soportado */ }
}
setupMainCanvasResolution();
const getLabel = (i) => String.fromCharCode(65 + i);
const slopeCanvas = document.getElementById('slopeCanvas');
const sCtx = slopeCanvas ? slopeCanvas.getContext('2d') : null;

function setupSlopeCanvasResolution() {
    if (!slopeCanvas || !sCtx) return;
    const rect = slopeCanvas.getBoundingClientRect();
    const logicalWidth = rect.width || 300;
    const logicalHeight = rect.height || 200;
    slopeCanvas.width = logicalWidth * DPR;
    slopeCanvas.height = logicalHeight * DPR;
    sCtx.setTransform(DPR, 0, 0, DPR, 0, 0);
    if (typeof sCtx.imageSmoothingEnabled !== 'undefined') sCtx.imageSmoothingEnabled = true;
    try { sCtx.imageSmoothingQuality = 'high'; } catch (e) { /* no soportado */ }
}
if (slopeCanvas) {
    setupSlopeCanvasResolution();
}

// Reajustar resolución y re-dibujar en redimensiones (evita que se vea pixelado en pantallas grandes)
let __pg_resize_timer = null;
window.addEventListener('resize', () => {
    if (__pg_resize_timer) clearTimeout(__pg_resize_timer);
    __pg_resize_timer = setTimeout(() => {
        setupMainCanvasResolution();
        setupSlopeCanvasResolution();
        draw();
    }, 150);
});

// Capa HTML para etiquetas nítidas por encima del canvas
function renderHtmlOverlays() {
    const layer = document.getElementById('pg-label-layer');
    if (!layer) return;
    // Vaciar siempre para evitar “fantasmas”
    layer.innerHTML = "";
    if (!points || !points.length) return;

    // 1) Letras de puntos (A, B, C...)
    if (showPerimeterPoints) {
        points.forEach((p, i) => {
            // No dibujar la etiqueta HTML del último punto cuando está activo el gizmo
            if (currentStep === 1 && !isClosed && i === points.length - 1) return;
            const el = document.createElement('div');
            el.className = 'pg-point-label-html';
            el.textContent = getLabel(i);
            el.style.left = `${p.x}px`;
            el.style.top = `${p.y}px`;
            layer.appendChild(el);
        });
    }

    // 2) Cotas Z en pastilla blanca/roja
    if (isClosed && showPerimeterHeights) {
        points.forEach((p) => {
            const el = document.createElement('div');
            el.className = 'pg-z-label-html';
            el.textContent = `${p.z ?? 0} mm`;
            el.style.left = `${p.x}px`;
            el.style.top = `${p.y - 22}px`;
            layer.appendChild(el);
        });
        // Cotas Z de sumideros (mismo estilo pero con clase diferenciada)
        drainagePoints.forEach((dp) => {
            const el = document.createElement('div');
            el.className = 'pg-z-label-html pg-z-label-html--drain';
            el.textContent = `${dp.z ?? 0} mm`;
            el.style.left = `${dp.x}px`;
            el.style.top = `${dp.y - 22}px`;
            layer.appendChild(el);
        });
    }

    // 3) Distancias / pendientes en los lados del perímetro
    if (isClosed && showSlopes) {
        // 3.a) Tramos del perímetro
        for (let i = 0; i < points.length; i++) {
            const p1 = points[i];
            const p2 = points[(i + 1) % points.length];
            const dx = p2.x - p1.x;
            const dy = p2.y - p1.y;
            const distPx = Math.sqrt(dx * dx + dy * dy);
            if (distPx < 15) continue;
            const distM = distPx / ESCALA_PX_METRO;
            const slopeVal = distM > 0.01 ? ((p1.z - p2.z) / (distM * 1000)) * 100 : 0;
            const absSlope = Math.abs(slopeVal).toFixed(1);
            const midX = (p1.x + p2.x) / 2;
            const midY = (p1.y + p2.y) / 2;

            const el = document.createElement('div');
            el.className = 'pg-segment-label-html';
            const textoDist = `${distM.toFixed(2)} m`;
            if (showAngles) {
                el.innerHTML = `<span class="pg-seg-dist">${textoDist}</span><span class="pg-seg-sep">·</span><span class="pg-seg-slope">${absSlope} %</span>`;
            } else {
                el.textContent = textoDist;
            }
            el.style.left = `${midX}px`;
            el.style.top = `${midY - 20}px`;
            layer.appendChild(el);
        }

        // 3.b) Tramos desde sumideros a vértices (diagonales interiores)
        if (drainagePoints && drainagePoints.length && triangles && triangles.length) {
            const allNodes = [...points, ...drainagePoints];
            const yaPintados = new Set();

            triangles.forEach((tri) => {
                const p0 = allNodes[tri.v[0]];
                const p1 = allNodes[tri.v[1]];
                const p2 = allNodes[tri.v[2]];
                if (!p0 || !p1 || !p2) return;

                drainagePoints.forEach(dp => {
                    if (!isPointInTriangle(dp, p0, p1, p2)) return;

                    [p0, p1, p2].forEach(v => {
                        const key = `${v.x},${v.y}|${dp.x},${dp.y}`;
                        if (yaPintados.has(key)) return;
                        yaPintados.add(key);

                        const dx = dp.x - v.x;
                        const dy = dp.y - v.y;
                        const distPx = Math.sqrt(dx * dx + dy * dy);
                        if (distPx < 15) return;
                        const distM = distPx / ESCALA_PX_METRO;
                        const slopeVal = distM > 0.01 ? ((v.z - dp.z) / (distM * 1000)) * 100 : 0;
                        const absSlope = Math.abs(slopeVal).toFixed(1);
                        const midX = (v.x + dp.x) / 2;
                        const midY = (v.y + dp.y) / 2;

                        const el = document.createElement('div');
                        el.className = 'pg-segment-label-html pg-segment-label-html--drain';
                        const textoDist = `${distM.toFixed(2)} m`;
                        if (showAngles) {
                            el.innerHTML = `<span class="pg-seg-dist">${textoDist}</span><span class="pg-seg-sep">·</span><span class="pg-seg-slope">${absSlope} %</span>`;
                        } else {
                            el.textContent = textoDist;
                        }
                        el.style.left = `${midX}px`;
                        el.style.top = `${midY - 20}px`;
                        layer.appendChild(el);
                    });
                });
            });
        }
    }
}

// Reajustar en cambios de tamaño de ventana
window.addEventListener('resize', () => {
    setupMainCanvasResolution();
    setupSlopeCanvasResolution();
    renderHtmlOverlays();
    draw();
});

// ========== INICIALIZACIÓN CONTROLES UI =============
window.addEventListener('load', () => {
    const thickInput = document.getElementById('tileThickness');
    if (thickInput) {
        thickInput.value = String(tileThicknessMm);
        thickInput.addEventListener('change', () => {
            const v = parseFloat(thickInput.value);
            if (Number.isFinite(v) && v >= 0) {
                tileThicknessMm = v;
                draw();
            }
        });
        // Al hacer foco, seleccionar automáticamente el valor para poder sobrescribirlo
        thickInput.addEventListener('focus', () => {
            // pequeño timeout para que funcione bien en todos los navegadores
            setTimeout(() => {
                thickInput.select();
            }, 0);
        });
    }

    // Atajo: en el popup de distancia/ángulo, Enter acepta "Siguiente punto"
    const distInput = document.getElementById('dk-dir-dist');
    const angInput = document.getElementById('dk-dir-angle');
    const handleEnter = (ev) => {
        if (ev.key === 'Enter') {
            ev.preventDefault();
            if (typeof window.aplicarDireccionSiguientePunto === 'function') {
                window.aplicarDireccionSiguientePunto();
            }
        }
    };
    if (distInput) distInput.addEventListener('keydown', handleEnter);
    if (angInput) angInput.addEventListener('keydown', handleEnter);

    // Atajo: en el popup de cota Z, Enter acepta "Guardar"
    const zInput = document.getElementById('dk-z-value');
    if (zInput) {
        zInput.addEventListener('keydown', (ev) => {
            if (ev.key === 'Enter') {
                ev.preventDefault();
                if (typeof window.aplicarPopupZ === 'function') {
                    window.aplicarPopupZ();
                }
            }
        });
    }
});

// ========== TABLA PUNTOS PERIMETRALES (COTAS Z) ==========
function syncPointsTable() {
    const table = document.getElementById('pg-points-table');
    if (!table) return;
    const tbody = table.querySelector('tbody');
    if (!tbody) return;
    tbody.innerHTML = "";
    if (!points || points.length === 0) return;

    points.forEach((p, i) => {
        const tr = document.createElement('tr');
        tr.dataset.index = i;

        const xM = (p.x || 0) / ESCALA_PX_METRO;
        const yM = (p.y || 0) / ESCALA_PX_METRO;

        tr.innerHTML = `
            <td>${getLabel(i)}</td>
            <td>${xM.toFixed(2)}</td>
            <td>${yM.toFixed(2)}</td>
            <td>
                <input type="number" class="pg-point-z-input" value="${p.z ?? 0}" step="1">
            </td>
        `;
        tbody.appendChild(tr);
    });
    if (!table.dataset.bound) {
        table.addEventListener('change', (e) => {
            const input = e.target;
            if (!(input instanceof HTMLInputElement)) return;
            if (!input.classList.contains('pg-point-z-input')) return;

            const tr = input.closest('tr');
            if (!tr) return;
            const idx = parseInt(tr.dataset.index, 10);
            if (Number.isNaN(idx) || !points[idx]) return;

            const val = parseFloat(input.value);
            if (!Number.isFinite(val)) return;

            points[idx].z = val;
            updateTriangulation();
            pushUndoState();
            draw();
        });
        table.dataset.bound = "1";
    }
}

// ========== MÉTRICAS Y CÁLCULOS ==========
// Escala base: 1 m ≈ 75 px a tamaño "normal".
// La usamos como referencia y, si hace falta, aplicamos zoom de vista
// (viewZoom) para ver más o menos metros sin tocar esta relación métrica.
const ESCALA_PX_METRO = 75;

function calcularMetricas() {
    let area = 0, perimetro = 0;
    if (points.length > 2) {
        for (let i = 0; i < points.length; i++) {
            let j = (i + 1) % points.length;
            area += points[i].x * points[j].y;
            area -= points[j].x * points[i].y;
            perimetro += Math.sqrt(
                Math.pow(points[j].x - points[i].x, 2) + Math.pow(points[j].y - points[i].y, 2)
            );
        }
        area = (Math.abs(area) / 2) / (ESCALA_PX_METRO * ESCALA_PX_METRO);
        perimetro = perimetro / ESCALA_PX_METRO;
    }
    if (document.getElementById('areaVal')) {
        document.getElementById('areaVal').innerText = area.toFixed(2);
    }
    
    return { area, perimetro };
}

// Resumen numérico de pendientes en el perímetro
function calcularResumenPendientesPerimetro() {
    if (!isClosed || points.length < 2) {
        return { min: null, max: null, media: null, numTramos: 0 };
    }

    let min = Infinity;
    let max = 0;
    let suma = 0;
    let cuenta = 0;

    for (let i = 0; i < points.length; i++) {
        const j = (i + 1) % points.length;
        const p1 = points[i], p2 = points[j];
        const distM = Math.sqrt((p2.x - p1.x)**2 + (p2.y - p1.y)**2) / ESCALA_PX_METRO;
        if (distM <= 0.05) continue;
        const slope = Math.abs(((p1.z - p2.z) / (distM * 1000)) * 100);
        if (slope <= 0) continue;
        if (slope < min) min = slope;
        if (slope > max) max = slope;
        suma += slope;
        cuenta++;
    }

    if (!Number.isFinite(min)) {
        return { min: null, max: null, media: null, numTramos: 0 };
    }

    return { min, max, media: suma / cuenta, numTramos: cuenta };
}

// ========== NAVEGACIÓN Y PASOS ==========
function updateTopNavActive() {
    document.querySelectorAll('.pg-steps-nav .pg-step').forEach(el => el.classList.remove('active'));
    const activeId = (currentStep === 3) ? 'step3-nav' : (currentStep === 4 ? 'step4-nav' : 'step1-nav');
    const el = document.getElementById(activeId);
    if (el) el.classList.add('active');
}

function updatePlanToolbarUI() {
    const toolbar = document.getElementById('pg-plan-toolbar');
    const isPlan = (currentStep === 1 || currentStep === 2);
    if (toolbar) toolbar.style.display = isPlan ? 'inline-flex' : 'none';

    const b1 = document.getElementById('pg-mode-perimeter');
    const b2 = document.getElementById('pg-mode-drainage');
    const b3 = document.getElementById('pg-mode-move');
    if (b1) b1.classList.toggle('active', planMode === 'perimeter');
    if (b2) b2.classList.toggle('active', planMode === 'drainage');
    if (b3) b3.classList.toggle('active', planMode === 'move');

    const hint = document.getElementById('pg-plan-hint');
    if (hint) {
        if (!isPlan) {
            hint.textContent = "";
        } else if (planMode === 'perimeter') {
            hint.textContent = "Haz clic para dibujar los puntos que delimitan el perímetro y doble clic en cada punto para definir su altura.";
        } else if (planMode === 'drainage') {
            hint.textContent = "Haz clic dentro del área para colocarlos (doble clic para su cota).";
        
        } else {
            hint.textContent = "";
        }
    }

    if (canvas) {
        canvas.style.cursor = (isPlan && planMode === 'move') ? (isMovingAll ? 'grabbing' : 'grab') : 'crosshair';
    }
}

window.setStep = (step) => {
    currentStep = step;
    const slopeCard = document.getElementById('slope-analysis-card');
    if (slopeCard) slopeCard.style.display = (step === 3) ? '' : 'none';
    const visCard = document.getElementById('pg-visibility-card');
    if (visCard) visCard.style.display = (step === 3) ? '' : 'none';
    const arkCard = document.getElementById('pg-ark-series-card');
    if (arkCard) arkCard.style.display = (step === 3) ? '' : 'none';
    const rotSec = document.getElementById('pg-rotation-section');
    if (rotSec) rotSec.style.display = 'none';
    const bgCard = document.getElementById('pg-bg-card');
    if (bgCard) bgCard.style.display = (step === 1 || step === 2) ? '' : 'none';
    const patternSec = document.getElementById('pg-pattern-section');
    // Tipo de colocación visible en los pasos 1, 2 y 3
    if (patternSec) patternSec.style.display = (step === 1 || step === 2 || step === 3) ? '' : 'none';
    const posSec = document.getElementById('pg-position-section');
    if (posSec) posSec.style.display = (step === 3) ? '' : 'none';
    const view3DSec = document.getElementById('pg-3d-section');
    if (view3DSec) view3DSec.style.display = (step === 3) ? '' : 'none';
    const msg = document.getElementById('pg-msg');
    const guides = {
        1: "Haz clic para dibujar los puntos que delimitan el perímetro y doble clic en cada punto para definir su altura.",
        2: "Sumideros: Haz clic dentro del área para colocar cada sumidero. Doble clic para cambiar cota Z. Para borrar: ratón y clic en la papelera roja.",
        3: "Replanteo: Elige formato y, a continuación, haz clic en un punto del perímetro para definir el origen de las baldosas.",
        4: "Informe listo. Puedes imprimir o cerrar."
    };
    if (msg) msg.innerText = guides[step] || "";
        const instBlock = document.getElementById('pg-instructions-content');
        if (instBlock) {
            const steps = {
                1: "• Arriba: elige «Puntos perimetrales».<br>• Haz clic en el lienzo para crear cada esquina.<br>• Cierra el polígono haciendo clic de nuevo en el primer punto.<br>• Con el polígono cerrado: haz clic en medio de un lado para añadir otro punto en ese lado.<br>• Doble clic en un punto para darle cota Z (mm). Para borrar: ratón sobre el punto y clic en la papelera roja.",
                2: "• Arriba: elige «Sumideros».<br>• Haz clic dentro del área para colocar cada sumidero.<br>• Doble clic en un sumidero para editar su cota Z (mm).<br>• Para borrar: pasa el ratón y clic en la papelera roja.",
                3: "• Elige formato de baldosa y tipo (Alineada/Trabada).<br>• Haz clic en un punto del perímetro para definir el origen y la orientación de la malla de baldosas.<br>• Mantén pulsado y arrastra desde un punto del perímetro para ajustar el ángulo con la línea verde.<br>• La calculadora puede añadir plots centrales de refuerzo cuando el formato de baldosa es grande o hay mucho desnivel entre esquinas; puedes quitar estos refuerzos marcando la casilla «Quitar plots centrales sugeridos».",
                4: "• Revisa el informe generado.<br>• Usa «Imprimir» o «Cerrar» según necesites."
            };
            const baseHtml = steps[step] || "";
            const videoHtml = `
                <div class="pg-instructions-video">
                    <div class="pg-instructions-video-embed">
                        <iframe 
                            src="https://www.youtube.com/embed/6KbMwsqiLgQ?si=_p9AmhQfu8RyTX2j" 
                            title="Vídeo informativo Dakota Calculator"
                            frameborder="0"
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                            referrerpolicy="strict-origin-when-cross-origin"
                            allowfullscreen
                            loading="lazy">
                        </iframe>
                    </div>
                    <div class="pg-instructions-video-text">
                        <span class="pg-instructions-video-title">Vídeo informativo de la calculadora Dakota</span>
                        <span class="pg-instructions-video-sub">Guía rápida paso a paso</span>
                    </div>
                </div>
            `;
            if (step === 1) {
                instBlock.innerHTML = baseHtml + videoHtml;
            } else {
                instBlock.innerHTML = baseHtml;
            }
        }
    // En el paso 3 mostramos el mapa de pendientes en el lateral.
    // Reajustamos el canvas cuando se hace visible (especialmente en iPad)
    // para que no aparezca recortado ni exageradamente “zoomeado”.
    if (step === 3 && typeof setupSlopeCanvasResolution === 'function' && slopeCanvas && sCtx) {
        setupSlopeCanvasResolution();
        renderSlopeMap();
    }
    if (step === 1) {
        if (planMode !== 'move') planMode = 'perimeter';
    } else if (step === 2) {
        planMode = 'drainage';
    } else if (step === 3) {
        // Al entrar en replanteo pedimos al usuario que escoja un punto de inicio.
        pendingTileOriginSelection = true;
        anglePreviewActive = false;
        anglePreviewDragging = false;
        anglePreviewStart = null;
        anglePreviewCurrent = null;
        anglePreviewPointIndex = null;
    }

    updateTopNavActive();
    updatePlanToolbarUI();

    if (step === 4) {
        generarInformeDetallado();
    } else {
        const overlay = document.getElementById('pg-report-overlay');
        if (overlay) overlay.style.display = "none";
    }
    draw();
};

window.goToPlan = () => {
    if (planMode === 'drainage') {
        window.setStep(2);
    } else {
        window.setStep(1);
    }
};

window.setPlanMode = (mode) => {
    planMode = mode;
    if (mode === 'perimeter') {
        window.setStep(1);
        return;
    }
    if (mode === 'drainage') {
        window.setStep(2);
        return;
    }
    if (currentStep === 3 || currentStep === 4) {
        window.setStep(1);
        return;
    }
    updateTopNavActive();
    updatePlanToolbarUI();
    draw();
};

window.setPatternType = (type) => {
    const sel = document.getElementById('patternType');
    if (sel) sel.value = type;

    const bGrid = document.getElementById('pattern-grid');
    const bBrick = document.getElementById('pattern-brick');
    if (bGrid) bGrid.classList.toggle('active', type === 'grid');
    if (bBrick) bBrick.classList.toggle('active', type === 'brick');

    draw();
};

// ========== CORTES PERIMETRALES Y REGLAS ==========
function calcularCortesPerimetrales() {
    if (!isClosed) return 0;
    let piezasConCorte = 0;
    const rad = (rotationAngle * Math.PI) / 180;
    const tW = tileWidth * 0.5;
    const tH = tileHeight * 0.5;

    for (let y = -800; y < 800; y += tH) {
        for (let x = -800; x < 800; x += tW) {
            const corners = [{x,y}, {x:x+tW, y}, {x:x+tW, y:y+tH}, {x, y:y+tH}];
            const realC = corners.map(c => ({
                x: c.x * Math.cos(rad) - c.y * Math.sin(rad) + gridOrigin.x,
                y: c.x * Math.sin(rad) + c.y * Math.cos(rad) + gridOrigin.y
            }));
            const adentro = realC.filter(c => isPointInPoly(c.x, c.y)).length;
            if (adentro > 0 && adentro < 4) piezasConCorte++;
        }
    }
    return piezasConCorte;
}


function drawProfessionalRulers() {
    ctx.save();
    ctx.fillStyle = "#f1f3f4";
    ctx.fillRect(0, 0, canvas.width, RULER_SIZE);
    ctx.fillRect(0, 0, RULER_SIZE, canvas.height);
    ctx.strokeStyle = "#dadce0";
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(0, RULER_SIZE); ctx.lineTo(canvas.width, RULER_SIZE);
    ctx.moveTo(RULER_SIZE, 0); ctx.lineTo(RULER_SIZE, canvas.height);
    ctx.stroke();
    ctx.fillStyle = "#70757a";
    ctx.font = "10px Inter, Roboto, Arial";
    ctx.strokeStyle = "#bdc1c6";
    const ESCALA = 75;
    const SUBDIVISION = ESCALA / 5;
    ctx.textAlign = "center";
    for (let x = RULER_SIZE; x < canvas.width; x += SUBDIVISION) {
        let posRelativa = Math.round(x - RULER_SIZE);
        let esMetro = posRelativa % ESCALA === 0;
        let esEtiqueta = posRelativa % (ESCALA * 2) === 0;

        ctx.beginPath();
        ctx.moveTo(x, RULER_SIZE);
        ctx.lineTo(x, esMetro ? (esEtiqueta ? 5 : 12) : 22);
        ctx.stroke();

        if (esEtiqueta) {
            let metros = (posRelativa / ESCALA).toFixed(0);
            ctx.fillText(metros + "m", x, 14);
        }
    }
    ctx.textAlign = "left";
    for (let y = RULER_SIZE; y < canvas.height; y += SUBDIVISION) {
        let posRelativa = Math.round(y - RULER_SIZE);
        let esMetro = posRelativa % ESCALA === 0;
        let esEtiqueta = posRelativa % (ESCALA * 2) === 0;

        ctx.beginPath();
        ctx.moveTo(RULER_SIZE, y);
        ctx.lineTo(esMetro ? (esEtiqueta ? 5 : 12) : 22, y);
        ctx.stroke();

        if (esEtiqueta) {
            let metros = (posRelativa / ESCALA).toFixed(0);
            ctx.save();
            ctx.translate(12, y);
            ctx.rotate(-Math.PI / 2);
            ctx.fillText(metros + "m", 0, 0);
            ctx.restore();
        }
    }
    if (mousePos.x > RULER_SIZE && mousePos.y > RULER_SIZE) {
        ctx.strokeStyle = "#1a73e8";
        ctx.lineWidth = 1;

        // Línea X
        ctx.beginPath();
        ctx.moveTo(mousePos.x, 0);
        ctx.lineTo(mousePos.x, RULER_SIZE);
        ctx.stroke();
        ctx.beginPath();
        ctx.moveTo(0, mousePos.y);
        ctx.lineTo(RULER_SIZE, mousePos.y);
        ctx.stroke();
        let mX = ((mousePos.x - RULER_SIZE) / ESCALA).toFixed(2);
        let mY = ((mousePos.y - RULER_SIZE) / ESCALA).toFixed(2);
        ctx.fillStyle = "#1a73e8";
        ctx.fillText(`${mX}, ${mY} m`, mousePos.x + 10, mousePos.y - 10);
    }
    ctx.fillStyle = "#fff";
    ctx.fillRect(0, 0, RULER_SIZE, RULER_SIZE);
    ctx.strokeRect(0, 0, RULER_SIZE, RULER_SIZE);

    ctx.restore();
}

// Interpola cota Z en (x,y) usando triangulación baricéntrica
function getZAt(x, y) {
    if (!isClosed || !triangles || triangles.length === 0) return null;
    const todosLosPuntos = [...points, ...drainagePoints];
    for (let tri of triangles) {
        const p0 = todosLosPuntos[tri.v[0]];
        const p1 = todosLosPuntos[tri.v[1]];
        const p2 = todosLosPuntos[tri.v[2]];
        if (!p0 || !p1 || !p2) continue;
        if (isPointInTriangle({x, y}, p0, p1, p2)) {
            let det = (p1.y - p2.y) * (p0.x - p2.x) + (p2.x - p1.x) * (p0.y - p2.y);
            if (Math.abs(det) < 0.0001) continue;
            let l1 = ((p1.y - p2.y) * (x - p2.x) + (p2.x - p1.x) * (y - p2.y)) / det;
            let l2 = ((p2.y - p0.y) * (x - p2.x) + (p0.x - p2.x) * (y - p2.y)) / det;
            let l3 = 1 - l1 - l2;
            return l1 * p0.z + l2 * p1.z + l3 * p2.z;
        }
    }
    return null;
}

// ========== INFORME DETALLADO (PASO 4) ==========
function generarInformeDetallado() {
    const metricas = calcularMetricas();
    const overlay = document.getElementById('pg-report-overlay');
    const numPlots = document.getElementById('piezasVal').innerText;
    const serieById = {};
    if (Array.isArray(PLOTS_SERIES)) {
        PLOTS_SERIES.forEach(s => { serieById[s.id] = s; });
    }

    const DB_ARK = {
        ARK10:  { 
            ref: (serieById.ARK10 && serieById.ARK10.refs && serieById.ARK10.refs[0]) || "TER09-1147/4A4M",
            nom: serieById.ARK10 ? (serieById.ARK10.nombre + (serieById.ARK10.rango_mm ? ` (${serieById.ARK10.rango_mm}mm)` : "")) : "ARKIMEDE 10 (10-20mm)",
            precio: 2.84,
            caja: 30
        },
        ARK18:  { 
            ref: (serieById.ARK18 && serieById.ARK18.refs && serieById.ARK18.refs[0]) || "TER09-1145/4A4M",
            nom: serieById.ARK18 ? (serieById.ARK18.nombre + (serieById.ARK18.rango_mm ? ` (${serieById.ARK18.rango_mm}mm)` : "")) : "ARKIMEDE 18 (18-36mm)",
            precio: 2.95,
            caja: 30
        },
        ARK35:  { 
            ref: (serieById.ARK35 && serieById.ARK35.refs && serieById.ARK35.refs[0]) || "TER09-1143/4A4M",
            nom: serieById.ARK35 ? (serieById.ARK35.nombre + (serieById.ARK35.rango_mm ? ` (${serieById.ARK35.rango_mm}mm)` : "")) : "ARKIMEDE 35 (35-60mm)",
            precio: 2.60,
            caja: 30
        },
        ARK60:  { 
            ref: (serieById.ARK60 && serieById.ARK60.refs && serieById.ARK60.refs[0]) || "TER09-1163/4A4M",
            nom: serieById.ARK60 ? (serieById.ARK60.nombre + (serieById.ARK60.rango_mm ? ` (${serieById.ARK60.rango_mm}mm)` : "")) : "ARKIMEDE 60 (60-115mm)",
            precio: 3.85,
            caja: 30
        },
        ARK115: { 
            ref: (serieById.ARK115 && serieById.ARK115.refs && serieById.ARK115.refs[0]) || "TER09-1173/4A4M",
            nom: serieById.ARK115 ? (serieById.ARK115.nombre + (serieById.ARK115.rango_mm ? ` (${serieById.ARK115.rango_mm}mm)` : "")) : "ARKIMEDE 115 (115-220mm)",
            precio: 5.36,
            caja: 15
        },
        P100:   { 
            ref: (serieById.P100 && serieById.P100.refs && serieById.P100.refs[0]) || "TER09-1143/P100",
            nom: serieById.P100 ? (serieById.P100.nombre + (serieById.P100.rango_mm ? ` (${serieById.P100.rango_mm}mm)` : "")) : "Extensión P100 (100mm)",
            precio: 2.15,
            caja: 30
        }
    };

    let resumen = { ARK10:0, ARK18:0, ARK35:0, ARK60:0, ARK115:0, ARK_EXT:0, EXT_P100:0, totalEuros:0 };
    const grosorBaldosa = 20;
    const margen = parseFloat(document.getElementById('alturaExtra')?.value) || 50;
    const maxZActual = Math.max(...points.map(p => p.z), ...drainagePoints.map(p => p.z));
    const nivelAcabadoSuperior = drainagePoints.length > 0
        ? Math.max(...drainagePoints.map(dp => (dp.z != null ? Number(dp.z) : 0) + margen))
        : maxZActual + margen;

    if (typeof tempPlots !== 'undefined') {
        tempPlots.forEach(pStr => {
            const [px, py] = pStr.split(',').map(Number);
            const h = calcularAlturaPlotEn(px, py);
            if (h !== null) {
                const infoSop = getInfoSoporte(h);
                if (infoSop.id === "ARK10") { resumen.ARK10++; resumen.totalEuros += DB_ARK.ARK10.precio; }
                else if (infoSop.id === "ARK18") { resumen.ARK18++; resumen.totalEuros += DB_ARK.ARK18.precio; }
                else if (infoSop.id === "ARK35") { resumen.ARK35++; resumen.totalEuros += DB_ARK.ARK35.precio; }
                else if (infoSop.id === "ARK60") { resumen.ARK60++; resumen.totalEuros += DB_ARK.ARK60.precio; }
                else if (infoSop.id === "ARK115") { resumen.ARK115++; resumen.totalEuros += DB_ARK.ARK115.precio; }
                else if (infoSop.id === "ARK_EXT") {
                    resumen.ARK_EXT++;
                    resumen.totalEuros += DB_ARK.ARK115.precio;
                    const nExt = Math.ceil((h - 220) / 100);
                    resumen.EXT_P100 += nExt;
                    resumen.totalEuros += (nExt * DB_ARK.P100.precio);
                }
            }
        });
    }

    // Función segura para capturar imágenes de los canvas (evita errores de seguridad en file:// o imágenes externas)
    const safeToDataURL = (cv) => {
        try {
            return cv.toDataURL("image/png");
        } catch (e) {
            console.warn("No se pudo generar imagen para el informe (restricciones del navegador):", e);
            return "";
        }
    };

    const imgPrincipal = safeToDataURL(canvas);
    // Imagen del mapa de pendientes para el informe (si existe el canvas lateral).
    let imgMapaPendientes = "";
    if (typeof renderSlopeMap === "function" && slopeCanvas && sCtx) {
        // Guardar tamaño actual del canvas lateral
        const prevWidth = slopeCanvas.width;
        const prevHeight = slopeCanvas.height;

        try {
            // Renderizar una versión de alta resolución solo para el informe
            const exportLogicalWidth = 1200;
            const exportLogicalHeight = 800;
            slopeCanvas.width = exportLogicalWidth * DPR;
            slopeCanvas.height = exportLogicalHeight * DPR;
            sCtx.setTransform(DPR, 0, 0, DPR, 0, 0);
            if (typeof sCtx.imageSmoothingEnabled !== "undefined") sCtx.imageSmoothingEnabled = true;
            try { sCtx.imageSmoothingQuality = "high"; } catch (e) {}

            renderSlopeMap();
            imgMapaPendientes = safeToDataURL(slopeCanvas);
        } finally {
            // Restaurar tamaño y redibujar el mapa en el panel lateral
            slopeCanvas.width = prevWidth;
            slopeCanvas.height = prevHeight;
            setupSlopeCanvasResolution();
            renderSlopeMap();
        }
    }
    const numCortes = calcularCortesPerimetrales();

    const areasPorSumidero = (() => {
        if (!isClosed || drainagePoints.length === 0 || triangles.length === 0) return [];
        const allNodes = [...points, ...drainagePoints];
        const areas = new Array(drainagePoints.length).fill(0);

        triangles.forEach(tri => {
            const p0 = allNodes[tri.v[0]];
            const p1 = allNodes[tri.v[1]];
            const p2 = allNodes[tri.v[2]];
            if (!p0 || !p1 || !p2) return;
            const areaPx2 = Math.abs(
                p0.x * (p1.y - p2.y) +
                p1.x * (p2.y - p0.y) +
                p2.x * (p0.y - p1.y)
            ) / 2;
            const areaM2 = areaPx2 / (ESCALA_PX_METRO * ESCALA_PX_METRO);

            drainagePoints.forEach((dp, idx) => {
                if (isPointInTriangle(dp, p0, p1, p2)) {
                    areas[idx] += areaM2;
                }
            });
        });

        return areas.map((a, idx) => ({ index: idx, area: a }));
    })();

    const drenajesHTML = drainagePoints.length > 0  
        ? drainagePoints.map((d, i) => {
            const areaInfo = areasPorSumidero.find(a => a.index === i);
            const areaTxt = areaInfo && areaInfo.area > 0 ? `${areaInfo.area.toFixed(2)} m²` : "-";
            return `<tr>
                <td style="padding:5px 0;">Sumidero ${i+1}</td>
                <td style="text-align:right;"><strong>${d.z} mm</strong></td>
                <td style="text-align:right; color:#004a8e;">${areaTxt}</td>
            </tr>`;
        }).join('')
        : '<tr><td colspan="3" style="padding:10px 0; color:#999;">No se han definido sumideros</td></tr>';
    const serieSelect = document.getElementById('pedestal-series');
    const serieKey = serieSelect ? serieSelect.value : "ARK115";
    const infoSerie = SERIES_SOPORTES[serieKey] || { nombre: "Gama Arkimede", max: 1000 };
    const todasLasZ = [...points.map(p => p.z), ...drainagePoints.map(p => p.z)];
    const maxZProyecto = Math.max(...todasLasZ);
    const esValido = maxZProyecto <= infoSerie.max;
    const projectName = document.getElementById('projectName')?.value || "Proyecto sin nombre";
    const projectClient = document.getElementById('projectClient')?.value || "";
    const projectLocation = document.getElementById('projectLocation')?.value || "";
    const projectRef = document.getElementById('projectRef')?.value || "";
    
    const keys = [
        {k:'ARK10', d:DB_ARK.ARK10}, {k:'ARK18', d:DB_ARK.ARK18}, 
        {k:'ARK35', d:DB_ARK.ARK35}, {k:'ARK60', d:DB_ARK.ARK60}, 
        {k:'ARK115', d:DB_ARK.ARK115}
    ];

    let filasHTML = keys.map(item => {
        const cant = (item.k === 'ARK115') ? resumen.ARK115 + resumen.ARK_EXT : resumen[item.k];
        if (cant === 0) return '';
        const nCajas = Math.ceil(cant / item.d.caja);
        return `
            <tr style="border-bottom: 1px solid #eee;">
                <td style="padding:8px 0; font-size:11px; color:#666;">${item.d.ref}</td>
                <td style="padding:8px 0;"><strong>${item.d.nom}</strong></td>
                <td style="padding:8px 0; text-align:center;">${cant} ud</td>
                <td style="padding:8px 0; text-align:center; color:#004a8e;">${nCajas} cjas</td>
                <td style="padding:8px 0; text-align:right;">${(cant * item.d.precio).toFixed(2)} €</td>
            </tr>`;
    }).join('');

    if (resumen.EXT_P100 > 0) {
        filasHTML += `
            <tr style="border-bottom: 1px solid #eee; background:#fff9f0;">
                <td style="padding:8px 0; font-size:11px; color:#666;">${DB_ARK.P100.ref}</td>
                <td style="padding:8px 0;"><strong>${DB_ARK.P100.nom}</strong></td>
                <td style="padding:8px 0; text-align:center;">${resumen.EXT_P100} ud</td>
                <td style="padding:8px 0; text-align:center; color:#004a8e;">${Math.ceil(resumen.EXT_P100/30)} cjas</td>
                <td style="padding:8px 0; text-align:right;">${(resumen.EXT_P100 * DB_ARK.P100.precio).toFixed(2)} €</td>
            </tr>`;
    }
    const reportId = Math.random().toString(36).substr(2, 9).toUpperCase();
    const totalEuros = resumen.totalEuros.toFixed(2);
    const totalRow = `<tr class="pg-report-total-row"><td colspan="4" style="text-align:right;">Total estimado</td><td style="text-align:right;">${totalEuros} €</td></tr>`;

    overlay.style.display = "flex";
    overlay.innerHTML = `
    <div class="pg-report-card">
        <header class="pg-report-header">
            <div style="display:flex; align-items:center; justify-content:space-between; gap:16px;">
                <div>
                    <h1>Informe técnico de obra</h1>
                    <p class="report-subtitle">Calculator ® — Análisis de pavimento elevado Dakota Arkimede</p>
                </div>
                <div style="background:#ffffff; padding:6px 10px; border-radius:6px;">
                    <img src="assets/LOGO-DAKOTA.svg" alt="Dakota" style="height:32px; width:auto; display:block;">
                </div>
            </div>
            <div class="pg-report-meta">
                <div>
                    ${projectName ? `<strong>Obra:</strong> ${projectName}<br>` : ""}
                    ${projectClient ? `<strong>Cliente:</strong> ${projectClient}<br>` : ""}
                    ${projectLocation ? `<strong>Ubicación:</strong> ${projectLocation}<br>` : ""}
                    ${projectRef ? `<strong>Ref.:</strong> ${projectRef}` : ""}
                </div>
                <div style="text-align: right;">
                    <strong>Fecha:</strong> ${new Date().toLocaleDateString('es-ES', { day: '2-digit', month: 'short', year: 'numeric' })}<br>
                    <span style="opacity: 0.9;">ID ${reportId}</span>
                </div>
            </div>
        </header>

        <div class="pg-report-body">
            <section class="pg-report-section">
                <h2 class="pg-report-section-title">1. Resumen de pedido</h2>
                <div class="pg-report-box">
                    <table>
                        <thead>
                            <tr>
                                <th>Ref.</th>
                                <th>Modelo</th>
                                <th style="text-align:center;">Cant.</th>
                                <th style="text-align:center;">Cajas</th>
                                <th style="text-align:right;">Subtotal</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${filasHTML}
                            ${totalRow}
                        </tbody>
                    </table>
                    <p style="font-size:11px; color:#64748b; margin:12px 0 0 0;">* Precios según tarifa. IVA no incluido. Cajas con redondeo al alza.</p>
                </div>
            </section>

            <section class="pg-report-section">
                <h2 class="pg-report-section-title">2. Planos</h2>
                <div class="pg-report-box" style="margin-bottom:18px;">
                    <h3>Planta de replanteo</h3>
                    <img src="${imgPrincipal}" alt="Planta de replanteo" style="width:100%; max-height:650px; object-fit:contain;">
                </div>
                ${imgMapaPendientes ? `
                <div class="pg-report-box">
                    <h3>Mapa de pendientes</h3>
                    <img src="${imgMapaPendientes}" alt="Mapa de pendientes" style="width:100%; max-height:400px; object-fit:contain;">
                </div>` : ``}
            </section>

            <section class="pg-report-section">
                <h2 class="pg-report-section-title">3. Datos técnicos</h2>
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                    <div class="pg-report-box">
                        <h3>Desglose gama Arkimede</h3>
                        <table>
                            <tbody>
                                <tr><td>Arkimede 10 (10-20 mm)</td><td style="text-align:right; font-weight:600;">${resumen.ARK10} uds.</td></tr>
                                <tr><td>Arkimede 18 (18-36 mm)</td><td style="text-align:right; font-weight:600;">${resumen.ARK18} uds.</td></tr>
                                <tr><td>Arkimede 35 (35-60 mm)</td><td style="text-align:right; font-weight:600;">${resumen.ARK35} uds.</td></tr>
                                <tr><td>Arkimede 60 (60-115 mm)</td><td style="text-align:right; font-weight:600;">${resumen.ARK60} uds.</td></tr>
                                <tr><td>Arkimede 115 (115-220 mm)</td><td style="text-align:right; font-weight:600;">${resumen.ARK115} uds.</td></tr>
                                ${resumen.ARK_EXT > 0 ? `<tr style="color:#b45309;"><td>ARK 115 + Extensiones P100</td><td style="text-align:right; font-weight:600;">${resumen.ARK_EXT} uds.</td></tr>` : ''}
                                ${resumen.FUERA_DE_RANGO > 0 ? `<tr style="color:#b91c1c; font-weight:700;"><td>⚠ Fuera de rango (&gt;1000 mm)</td><td style="text-align:right;">${resumen.FUERA_DE_RANGO} uds.</td></tr>` : ''}
                            </tbody>
                        </table>
                    </div>
                    <div class="pg-report-box">
                        <h3>Cotas y zonas de sumideros</h3>
                        <table>
                            <thead><tr><th>Sumidero</th><th style="text-align:right;">Cota Z (mm)</th><th style="text-align:right;">Superficie (m²)</th></tr></thead>
                            <tbody>${drenajesHTML}</tbody>
                        </table>
                    </div>
                </div>
            </section>

            <section class="pg-report-section">
                <h2 class="pg-report-section-title">4. Validación</h2>
                <div class="pg-report-validation ${esValido ? 'ok' : 'alert'}">
                    <h4 style="margin:0 0 12px 0; font-size:14px;">${esValido ? '✅ Validación técnica correcta' : '⚠ Revisar compatibilidad'}</h4>
                    <div style="display: grid; grid-template-columns: 1.5fr 1fr; gap: 24px;">
                        <div>
                            <p style="margin:0 0 8px 0;">Proyecto según gama <strong>Dakota Arkimede</strong>, baldosa <strong>${tileWidth}×${tileHeight} cm</strong>.</p>
                            <ul style="margin:0; padding-left:18px;">
                                <li>Cota máx. suelo: <strong>${maxZProyecto} mm</strong></li>
                                <li>Altura acabado (sup.): <strong>${nivelAcabadoSuperior} mm</strong></li>
                                <li>Estado: <strong>${esValido ? 'Apto para instalación' : 'Revisar limitaciones'}</strong></li>
                            </ul>
                        </div>
                        <div style="border-left:2px solid currentColor; padding-left:16px; font-size:13px;">
                            <strong>Resumen</strong><br>
                            Soportes: <strong>${numPlots}</strong> uds.<br>
                            Corte perimetral: <strong>${numCortes}</strong> uds.<br>
                            Superficie: <strong>${metricas.area.toFixed(2)} m²</strong><br>
                            Densidad: <strong>${(numPlots / metricas.area).toFixed(2)}</strong> plots/m²
                        </div>
                    </div>
                </div>
            </section>

            <div class="pg-report-actions no-print">
                <a href="${imgPrincipal}" download="dakota-planta-replanteo.png" style="background:#0f766e; color:#fff;">Descargar planta (PNG)</a>
                ${imgMapaPendientes ? `<a href="${imgMapaPendientes}" download="dakota-mapa-pendientes.png" style="background:#2563eb; color:#fff;">Descargar mapa pendientes (PNG)</a>` : ``}
                <button type="button" onclick="window.print()" style="background:#004a8e; color:#fff; border:none;">Imprimir</button>
                <button type="button" onclick="document.getElementById('pg-report-overlay').style.display='none';" style="background:#fff; color:#475569; border:1px solid #cbd5e1;">Cerrar</button>
            </div>

            <footer class="pg-report-footer">
                Informe generado con Dakota Calculator · ID ${reportId} · ${new Date().toLocaleDateString('es-ES')}
            </footer>
        </div>
    </div>
    `;
}

// ========== GEOMETRÍA: TRIÁNGULOS Y POLÍGONO ==========
function isPointInTriangle(p, p0, p1, p2) {
    const A = 0.5 * (-p1.y * p2.x + p0.y * (-p1.x + p2.x) + p0.x * (p1.y - p2.y) + p1.x * p2.y);
    const sign = A < 0 ? -1 : 1;
    const s = (p0.y * p2.x - p0.x * p2.y + (p2.y - p0.y) * p.x + (p0.x - p2.x) * p.y) * sign;
    const t = (p0.x * p1.y - p0.y * p1.x + (p0.y - p1.y) * p.x + (p1.x - p0.x) * p.y) * sign;
    const area2 = 2 * Math.abs(A);
    const eps = 1e-6;
    return s >= -eps && t >= -eps && (s + t) <= area2 + eps;
}

function distToSegment(p, v, w) {
    const l2 = (v.x - w.x)**2 + (v.y - w.y)**2;
    if (l2 === 0) return Math.sqrt((p.x - v.x)**2 + (p.y - v.y)**2);
    let t = ((p.x - v.x) * (w.x - v.x) + (p.y - v.y) * (w.y - v.y)) / l2;
    t = Math.max(0, Math.min(1, t));
    return Math.sqrt((p.x - (v.x + t * (w.x - v.x)))**2 + (p.y - (v.y + t * (w.y - v.y)))**2);
}

// Delaunay: perímetro + sumideros, filtrado por polígono
function updateTriangulation() {
    triangles = [];
    const N = points.length;
    if (N < 3) return;
    let vertices = points.map((p, i) => ({ x: p.x, y: p.y, z: p.z, id: i }));
    drainagePoints.forEach((p, i) => {
        vertices.push({ x: p.x, y: p.y, z: p.z, id: N + i });
    });
    const minX = Math.min(...vertices.map(p => p.x)) - 1000;
    const minY = Math.min(...vertices.map(p => p.y)) - 1000;
    const maxX = Math.max(...vertices.map(p => p.x)) + 1000;
    const maxY = Math.max(...vertices.map(p => p.y)) + 1000;

    const superTriangle = [
        { x: minX, y: minY, id: -1 },
        { x: maxX + (maxX - minX), y: minY, id: -2 },
        { x: minX, y: maxY + (maxY - minY), id: -3 }
    ];
    let tempTriangles = [superTriangle];
    for (let point of vertices) {
        let badTriangles = [];
        for (let tri of tempTriangles) {
            if (isPointInCircumcircle(point, tri[0], tri[1], tri[2])) {
                badTriangles.push(tri);
            }
        }

        let polygon = [];
        for (let tri of badTriangles) {
            for (let i = 0; i < 3; i++) {
                let edge = { a: tri[i], b: tri[(i + 1) % 3] };
                let isShared = false;
                for (let otherTri of badTriangles) {
                    if (tri === otherTri) continue;
                    for (let j = 0; j < 3; j++) {
                        let otherEdge = { a: otherTri[j], b: otherTri[(j + 1) % 3] };
                        if ((edge.a.id === otherEdge.a.id && edge.b.id === otherEdge.b.id) ||
                            (edge.a.id === otherEdge.b.id && edge.b.id === otherEdge.a.id)) {
                            isShared = true;
                            break;
                        }
                    }
                    if (isShared) break;
                }
                if (!isShared) polygon.push(edge);
            }
        }
        tempTriangles = tempTriangles.filter(t => !badTriangles.includes(t));
        for (let edge of polygon) {
            tempTriangles.push([edge.a, edge.b, point]);
        }
    }
    triangles = [];
    for (let tri of tempTriangles) {
        if (tri[0].id < 0 || tri[1].id < 0 || tri[2].id < 0) continue;
        const cx = (tri[0].x + tri[1].x + tri[2].x) / 3;
        const cy = (tri[0].y + tri[1].y + tri[2].y) / 3;
        const sumideroCount = tri.filter(v => v.id >= N).length;
        if (sumideroCount >= 2 || isPointInPoly(cx, cy)) {
             triangles.push({ v: [tri[0].id, tri[1].id, tri[2].id] });
        }
    }
}

function isPointInCircumcircle(p, a, b, c) {
    const adx = a.x - p.x;
    const ady = a.y - p.y;
    const bdx = b.x - p.x;
    const bdy = b.y - p.y;
    const cdx = c.x - p.x;
    const cdy = c.y - p.y;

    const abdet = adx * bdy - bdx * ady;
    const bcdet = bdx * cdy - cdx * bdy;
    const cadet = cdx * ady - adx * cdy;
    const alift = adx * adx + ady * ady;
    const blift = bdx * bdx + bdy * bdy;
    const clift = cdx * cdx + cdy * cdy;

    return (alift * bcdet + blift * cadet + clift * abdet) > 0;
}

function isPointInPolyOrBorder(x, y) {
    if (isPointInPoly(x, y)) return true;
    const tol = 2; 
    for (let i = 0, j = points.length - 1; i < points.length; j = i++) {
        const a = points[j];
        const b = points[i];
        if (distToSegment({x, y}, a, b) <= tol) return true;
    }
    return false;
}

function isPointInPoly(x, y) {
    let inside = false;
    for (let i = 0, j = points.length - 1; i < points.length; j = i++) {
        const xi = points[i].x, yi = points[i].y;
        const xj = points[j].x, yj = points[j].y;
        const intersect = ((yi > y) !== (yj > y)) && (x < (xj - xi) * (y - yi) / (yj - yi) + xi);
        if (intersect) inside = !inside;
    }
    return inside;
}

// ========== MAPA DE PENDIENTES
// Azul = altura más baja, rojo = altura más alta (misma lógica que la altura de plots).
function renderSlopeMap() {
    if (!sCtx || !slopeCanvas || !isClosed || points.length < 3) return;

    // Trabajamos en “píxeles lógicos” (CSS px). Con pantallas HiDPI (DPR>1),
    // canvas.width/height están en device px, así que normalizamos dividiendo por DPR.
    const cw = slopeCanvas.width / DPR;
    const ch = slopeCanvas.height / DPR;

    const minX = Math.min(...points.map(p => p.x));
    const maxX = Math.max(...points.map(p => p.x));
    const minY = Math.min(...points.map(p => p.y));
    const maxY = Math.max(...points.map(p => p.y));
    // Paso de muestreo fino para que el degradado no se vea a “bloques”
    const paso = 4;
    let minH = Infinity;
    let maxH = -Infinity;
    const muestras = [];
    for (let x = minX; x <= maxX; x += paso) {
        for (let y = minY; y <= maxY; y += paso) {
            if (!isPointInPoly(x, y)) continue;
            const h = calcularAlturaPlotEn(x, y);
            if (h != null && typeof h === 'number') {
                minH = Math.min(minH, h);
                maxH = Math.max(maxH, h);
                muestras.push({ x, y, h });
            }
        }
    }
    if (muestras.length === 0) return;
    const escala = Math.min(
        (cw - 100) / (maxX - minX || 1),
        (ch - 100) / (maxY - minY || 1)
    );

    // Limpiar en coordenadas físicas (device px), luego dibujar en coordenadas lógicas.
    sCtx.setTransform(1, 0, 0, 1, 0, 0);
    sCtx.clearRect(0, 0, slopeCanvas.width, slopeCanvas.height);
    sCtx.setTransform(DPR, 0, 0, DPR, 0, 0);

    sCtx.save();
    sCtx.translate(cw / 2, ch / 2);
    sCtx.scale(escala, escala);
    sCtx.translate(-(minX + (maxX - minX) / 2), -(minY + (maxY - minY) / 2));

    sCtx.beginPath();
    points.forEach((p, i) => i === 0 ? sCtx.moveTo(p.x, p.y) : sCtx.lineTo(p.x, p.y));
    sCtx.closePath();
    sCtx.clip();

    // Mapa solo por altura global minH → maxH,
    // usando h = calcularAlturaPlotEn(x,y), igual que la lógica de altura de plots.
    const rangoH = Math.max(1, maxH - minH);
    muestras.forEach(({ x, y, h }) => {
        const t = Math.min(1, Math.max(0, (h - minH) / rangoH)); // 0 = más bajo, 1 = más alto
        const r = Math.round(0 + t * (239 - 0));
        const g = Math.round(106 + t * (68 - 106));
        const b = Math.round(255 + t * (68 - 255));
        sCtx.fillStyle = `rgb(${r},${g},${b})`;
        sCtx.fillRect(x, y, paso + 1, paso + 1);
    });

    sCtx.beginPath();
    points.forEach((p, i) => i === 0 ? sCtx.moveTo(p.x, p.y) : sCtx.lineTo(p.x, p.y));
    sCtx.closePath();
    sCtx.strokeStyle = "#1e293b";
    sCtx.lineWidth = 2 / escala;
    sCtx.stroke();

    drainagePoints.forEach((dp) => {
        const rOuter = 4 / escala;
        const rInner = 2 / escala;

        // Aro exterior blanco con borde amarillo
        sCtx.fillStyle = "#ffffff";
        sCtx.strokeStyle = "#facc15";
        sCtx.lineWidth = 1.5 / escala;
        sCtx.beginPath();
        sCtx.arc(dp.x, dp.y, rOuter, 0, Math.PI * 2);
        sCtx.fill();
        sCtx.stroke();

        // Punto interior amarillo
        sCtx.fillStyle = "#facc15";
        sCtx.beginPath();
        sCtx.arc(dp.x, dp.y, rInner, 0, Math.PI * 2);
        sCtx.fill();
    });

    sCtx.restore();

    // Leyenda compacta (degradado azul → rojo por altura)
    const pad = 8;
    const legW = 170;
    const legH = 40;
    const x0 = pad;
    const y0 = ch - legH - pad;

    sCtx.fillStyle = "rgba(255,255,255,0.96)";
    sCtx.strokeStyle = "#cbd5e1";
    sCtx.lineWidth = 1;
    sCtx.strokeRect(x0, y0, legW, legH);
    sCtx.fillRect(x0, y0, legW, legH);

    sCtx.textAlign = "left";
    sCtx.font = "9px Arial";
    sCtx.fillStyle = "#0f172a";
    sCtx.fillText("Altura más baja → más alta", x0 + 8, y0 + 14);

    const gradX = x0 + 10;
    const gradY = y0 + 20;
    const gradW = legW - 20;
    const gradH = 8;
    const grad = sCtx.createLinearGradient(gradX, gradY, gradX + gradW, gradY);
    grad.addColorStop(0, "rgb(0,106,255)");
    grad.addColorStop(1, "rgb(239,68,68)");
    sCtx.fillStyle = grad;
    sCtx.fillRect(gradX, gradY, gradW, gradH);
}

// ========== REPLANTEO (PASO 3): BALDOSAS Y PLOTS ==========
function renderReplanteo() {
    if (!isClosed) return;
    // Mientras el usuario aún no ha definido el origen/ángulo de inicio,
    // no generamos plots ni rejilla de baldosas.
    // Después de fijar el primer origen, mantenemos visibles las baldosas
    // incluso si se está arrastrando la línea verde de previsualización,
    // para que el usuario use esa línea solo como guía sin mover la malla
    // hasta soltar el botón.
    if (pendingTileOriginSelection) {
        tempPlots = new Set();
        return;
    }
    const rad = (rotationAngle * Math.PI) / 180;
    const formatoSelect = document.getElementById('tileFormat')?.value || "60,60";
    const [selectedW, selectedH] = formatoSelect.split(',').map(Number);

    const tW = selectedW * 0.75; 
    const tH = selectedH * 0.75;
    const patternType = document.getElementById('patternType')?.value || 'grid';
    const todosLosPuntos = [...points, ...drainagePoints];
    const maxZProyectada = todosLosPuntos.length > 0 ? Math.max(...todosLosPuntos.map(p => p.z || 0)) : 0;
    const margenCliente = parseFloat(document.getElementById('alturaExtra')?.value) || 50;
    const nivelAcabado = maxZProyectada + margenCliente;
    tempPlots = new Set();
    let rowIndex = 0;
    let contadorRefuerzosDesnivel = 0;
    ctx.save();

    // Queremos que el origen de la malla (gridOrigin) coincida exactamente
    // con la intersección de líneas de la rejilla (esquina de baldosa)
    // para TODOS los formatos. Para ello, generamos la malla en coordenadas
    // locales donde (0,0) es SIEMPRE un nodo de la rejilla, y luego
    // trasladamos todo a gridOrigin.
    const alcance = 3000; // alcance aproximado que cubre el plano
    const numFilas = Math.ceil(alcance / tH);
    const numCols = Math.ceil(alcance / tW);
    const yInicio = -numFilas * tH;
    const yFin    =  numFilas * tH;
    const xInicio = -numCols * tW;
    const xFin    =  numCols * tW;

    for (let y = yInicio; y <= yFin; y += tH) {
        rowIndex++;
        for (let x = xInicio; x <= xFin; x += tW) {
            let offsetX = 0;
            let offsetY = 0;
            if (patternType === 'brick') {
                if (selectedW >= selectedH) {
                    if (rowIndex % 2 === 0) offsetX = tW / 2;
                } else {
                    let colIndex = Math.round(x / tW);
                    if (colIndex % 2 === 0) offsetY = tH / 2;
                }
            }

            const curX = x + offsetX;
            const curY = y + offsetY;
            
            const corners = [
                {x: curX, y: curY}, {x: curX + tW, y: curY}, 
                {x: curX + tW, y: curY + tH}, {x: curX, y: curY + tH}
            ];
            
            const realC = corners.map(c => ({
                x: c.x * Math.cos(rad) - c.y * Math.sin(rad) + gridOrigin.x,
                y: c.x * Math.sin(rad) + c.y * Math.cos(rad) + gridOrigin.y
            }));
            const adentro = realC.filter(c => isPointInPoly(c.x, c.y)).length;
            const insideCorners = realC.filter(c => isPointInPolyOrBorder(c.x, c.y));
            const outsideCorners = realC.filter(c => !isPointInPolyOrBorder(c.x, c.y));

            if (realC.some(c => isPointInPolyOrBorder(c.x, c.y))) {
                ctx.strokeStyle = "rgba(0, 74, 142, 0.2)";
                ctx.beginPath();
                ctx.moveTo(realC[0].x, realC[0].y);
                realC.forEach(c => ctx.lineTo(c.x, c.y));
                ctx.closePath();
                ctx.stroke();
                const zEsquinas = realC.map(c => getZAt(c.x, c.y) || 0);
                const diferenciaZ = Math.max(...zEsquinas) - Math.min(...zEsquinas);
                const desnivelCritico = diferenciaZ > 5;
                const apoyosRelativos = [{rx: 0, ry: 0}, {rx: 1, ry: 0}, {rx: 1, ry: 1}, {rx: 0, ry: 1}];
                if (selectedW > 60) apoyosRelativos.push({rx: 0.5, ry: 0}, {rx: 0.5, ry: 1});
                if (selectedH > 60) apoyosRelativos.push({rx: 0, ry: 0.5}, {rx: 1, ry: 0.5});

                const centralPorTam = (selectedW >= 60 && selectedH >= 60);
                const centralPorDesnivel = desnivelCritico;

                let usarCentral = false;
                if (centralMode === 'off') {
                    usarCentral = false;
                } else {
                    usarCentral = centralPorTam || centralPorDesnivel;
                }

                if (usarCentral) {
                    apoyosRelativos.push({rx: 0.5, ry: 0.5});
                    if (centralPorDesnivel && centralMode === 'auto' && (selectedW < 60 || selectedH < 60)) {
                        contadorRefuerzosDesnivel++;
                    }
                }

                apoyosRelativos.forEach(p => {
                    const px = (curX + p.rx * tW) * Math.cos(rad) - (curY + p.ry * tH) * Math.sin(rad) + gridOrigin.x;
                    const py = (curX + p.rx * tW) * Math.sin(rad) + (curY + p.ry * tH) * Math.cos(rad) + gridOrigin.y;
                    if (isPointInPolyOrBorder(px, py)) {
                        tempPlots.add(`${Math.round(px)},${Math.round(py)}`);
                    }
                });
                if (insideCorners.length > 0 && outsideCorners.length > 0) {
                    const addedCorte = new Set();
                    for (let i = 0; i < 4; i++) {
                        const a = realC[i];
                        const b = realC[(i + 1) % 4];
                        const aIn = isPointInPolyOrBorder(a.x, a.y);
                        const bIn = isPointInPolyOrBorder(b.x, b.y);
                        if (aIn === bIn) continue;
                        const from = aIn ? a : b;
                        const to = aIn ? b : a;
                        let t0 = 0, t1 = 1;
                        for (let k = 0; k < 14; k++) {
                            const tm = (t0 + t1) / 2;
                            const mx = from.x + (to.x - from.x) * tm;
                            const my = from.y + (to.y - from.y) * tm;
                            if (isPointInPolyOrBorder(mx, my)) t0 = tm;
                            else t1 = tm;
                        }
                        const tIn = Math.min(0.85, t0 * 0.9);
                        const bx = from.x + (to.x - from.x) * tIn;
                        const by = from.y + (to.y - from.y) * tIn;
                        const key = `${Math.round(bx)},${Math.round(by)}`;
                        if (!addedCorte.has(key)) {
                            addedCorte.add(key);
                            tempPlots.add(key);
                        }
                    }
                }
            }
        }
    }
    ctx.restore();
    const divAlertas = document.getElementById('contenedor-alertas');
    if (divAlertas) {
        if (contadorRefuerzosDesnivel > 0) {
            divAlertas.style.display = "block";
            divAlertas.innerHTML = `<div style="background: #fff3cd; color: #856404; padding: 12px; border-left: 5px solid #ffc107;">
                <strong>⚠️ NOTA TÉCNICA DAKOTA:</strong> Desniveles críticos en ${contadorRefuerzosDesnivel} puntos. Refuerzo central aplicado.</div>`;
        } else {
            divAlertas.style.display = "none";
        }
    }
    // Info global sobre plots centrales
    const centralInfo = document.getElementById('central-info');
        if (centralInfo) {
            if (centralMode === 'off') {
                centralInfo.textContent = "Plots centrales desactivados manualmente.";
            } else if (contadorRefuerzosDesnivel > 0 || (selectedW >= 60 && selectedH >= 60)) {
                const motivos = [];
                if (selectedW >= 60 && selectedH >= 60) motivos.push("formato de baldosa ≥ 60×60 cm");
                if (contadorRefuerzosDesnivel > 0) motivos.push("desnivel > 5 mm entre esquinas");
                centralInfo.textContent = "Plots centrales de refuerzo añadidos automáticamente por " + motivos.join(" y ") + ".";
            } else {
                centralInfo.textContent = "Sin plots centrales añadidos automáticamente en modo AUTO.";
            }
    }
    const todosLosPuntosZ = [...points, ...drainagePoints].map(p => p.z || 0);
    const zMedio = todosLosPuntosZ.length ? todosLosPuntosZ.reduce((a, b) => a + b, 0) / todosLosPuntosZ.length : 0;
    const offsets = [[0,0], [2,0], [-2,0], [0,2], [0,-2], [3,3], [-3,-3]];
    tempPlots.forEach(p => {
        const [px, py] = p.split(',').map(Number);
        let zSuelo = getZAt(px, py);
        if (zSuelo === null) {
            for (const [dx, dy] of offsets) {
                zSuelo = getZAt(px + dx, py + dy);
                if (zSuelo !== null) break;
            }
        }
        if (zSuelo === null) zSuelo = zMedio;
        const alturaRealPlot = calcularAlturaPlotEn(px, py);
        const infoSoporte = getInfoSoporte(alturaRealPlot);

        ctx.save();
        ctx.fillStyle = infoSoporte.color;
        ctx.strokeStyle = "white";
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.arc(px, py, 5, 0, Math.PI * 2);
        ctx.fill();
        ctx.stroke();
        ctx.restore();
    });
}

// Resumen de pendientes en panel lateral
function updateSlopeSummary() {
    const box = document.getElementById('slope-summary');
    if (!box) return;

    if (!isClosed || points.length < 2) {
        box.textContent = "Dibuja el perímetro y define las cotas para analizar las pendientes.";
        return;
    }

    const resumen = calcularResumenPendientesPerimetro();
    if (resumen.numTramos === 0 || resumen.min === null) {
        box.textContent = "No hay tramos de perímetro suficientes para analizar la pendiente.";
        return;
    }

    const min = resumen.min.toFixed(1);
    const max = resumen.max.toFixed(1);
    const media = resumen.media.toFixed(1);

    let estado;
    if (resumen.min < 1) {
        estado = "RIESGO de estancamiento (mín. < 1%)";
    } else if (resumen.min < 2) {
        estado = "Pendiente baja, revisar (mín. entre 1% y 2%)";
    } else {
        estado = "Pendiente OK (mín. ≥ 2%)";
    }

    box.innerHTML = `
        <strong>Pendiente mínima:</strong> ${min}% · 
        <strong>máxima:</strong> ${max}% · 
        <strong>media:</strong> ${media}%<br>
        <span style="color:${resumen.min < 1 ? '#b91c1c' : (resumen.min < 2 ? '#b45309' : '#166534')}; font-weight:600;">
            ${estado}
        </span>
    `;
}
function getNivelAcabadoSuperior() {
    const todos = [...points, ...drainagePoints];
    if (!todos.length) return 0;

    const maxZ = Math.max(...todos.map(p => p.z || 0));
    const margen = parseFloat(document.getElementById('alturaExtra')?.value) || 50;
    return maxZ + margen;
}

// Lógica de pendiente (sin triangulación, solo distancia al punto central).
// 1. Si punto sumidero y perímetro están todos a 0 mm → no se calcula pendiente (superficie plana).
// 2. Si hay puntos perimetrales con altura y sumidero a 0 → se calcula pendiente hacia el sumidero.
// 3. Se tiene en cuenta la altura de los puntos perimetrales (getZAt / suelo local).
// 4. Si el punto es más alto que el perímetro → es punto alto, agua a los bordes por todos los lados.
const PENDIENTE_DRENAJE_MM_M = 20;

// Distancia máxima desde un punto (dx,dy) hasta el perímetro (para pendiente hasta el borde).
function maxDistPxHastaPerimetro(dx, dy) {
    if (points.length === 0) return 0;
    let max = 0;
    points.forEach(p => {
        const d = Math.hypot(p.x - dx, p.y - dy);
        if (d > max) max = d;
    });
    return max;
}

function getNivelAcabadoEn(x, y) {
    const margen = parseFloat(document.getElementById('alturaExtra')?.value) || 50;
    const grosorBaldosa = 20;
    const todos = [...points, ...drainagePoints].filter(p => p.z != null && p.z !== '');
    const minZ = todos.length ? Math.min(...todos.map(p => Number(p.z) || 0)) : 0;
    const nivelBase = minZ + grosorBaldosa;
    const maxZ = todos.length ? Math.max(...todos.map(p => Number(p.z) || 0)) : 0;

    const maxZPerimetro = points.length ? Math.max(...points.map(p => Number(p.z) || 0)) : 0;
    const minZPerimetro = points.length ? Math.min(...points.map(p => Number(p.z) || 0)) : 0;
    const perimetroTodoCero = points.length === 0 || (minZPerimetro === 0 && maxZPerimetro === 0);
    const sumiderosTodosCero = drainagePoints.length > 0 && drainagePoints.every(dp => (dp.z != null ? Number(dp.z) : 0) === 0);

    if (drainagePoints.length === 0) {
        return maxZ + margen;
    }

    // 1. Sumidero(s) a 0 mm y perímetro todo a 0 mm → no pendiente, superficie plana.
    if (sumiderosTodosCero && perimetroTodoCero) {
        return nivelBase;
    }

    // Varios puntos: cada uno aporta un nivel según su lógica; se combinan con peso por distancia.
    let sumPeso = 0;
    let sumNivelPeso = 0;
    const eps = 50;

    for (const dp of drainagePoints) {
        const distPx = Math.hypot(x - dp.x, y - dp.y);
        const distM = distPx / ESCALA_PX_METRO;
        const z = dp.z != null ? Number(dp.z) : 0;

        // 4. Si el punto es más alto que el perímetro → punto alto (agua a los bordes). Si no → sumidero.
        const esPuntoAlto = z > maxZPerimetro;

        let nivelI;
        if (esPuntoAlto) {
            // Punto alto: baja hasta el borde.
            const nivelCentro = 2 * z + grosorBaldosa;
            const maxDistPx = maxDistPxHastaPerimetro(dp.x, dp.y);
            const maxDistM = Math.max(maxDistPx / ESCALA_PX_METRO, 0.01);
            let pendiente = (nivelCentro - nivelBase) / maxDistM;
            pendiente = Math.max(pendiente, 2);
            nivelI = nivelCentro - pendiente * distM;
            nivelI = Math.max(nivelI, nivelBase);
        } else {
            // Sumidero (z <= maxZPerimetro): sube desde este punto hacia fuera.
            nivelI = nivelBase + PENDIENTE_DRENAJE_MM_M * distM;
        }

        const peso = 1 / (distPx * distPx + eps);
        sumNivelPeso += nivelI * peso;
        sumPeso += peso;
    }

    let nivel = sumPeso > 0 ? sumNivelPeso / sumPeso : nivelBase;
    nivel = Math.max(nivel, nivelBase);

    // 3. Respetar altura de los puntos perimetrales: no bajar del suelo local + baldosa.
    const zSueloLocal = getZAt(x, y);
    const sueloLocal = zSueloLocal != null ? Number(zSueloLocal) : minZ;
    nivel = Math.max(nivel, sueloLocal + grosorBaldosa);

    return nivel;
}

// Interpolación RADIAL entre punto central (drainagePoint) y perímetro:
// Zacabado(x,y) = Zc + t * (Zborde_dir - Zc), donde t = dist(C, P) / dist(C, borde_en_esa_dirección).
function getZRadialAt(x, y) {
    if (drainagePoints.length !== 1 || points.length < 3) return null;
    const c = drainagePoints[0];
    const cx = c.x, cy = c.y, zc = Number(c.z) || 0;
    const dx = x - cx, dy = y - cy;
    const distP = Math.hypot(dx, dy);
    if (distP < 1e-3) return zc;

    let minT = Infinity;
    let edgeI = -1;
    let edgeU = 0;

    for (let i = 0; i < points.length; i++) {
        const j = (i + 1) % points.length;
        const x1 = points[i].x, y1 = points[i].y;
        const x2 = points[j].x, y2 = points[j].y;

        const sx = x2 - x1;
        const sy = y2 - y1;
        const rxs = dx * sy - dy * sx;
        if (Math.abs(rxs) < 1e-6) continue; // paralelos

        const qpx = x1 - cx;
        const qpy = y1 - cy;

        const t = (qpx * sy - qpy * sx) / rxs;         // parámetro sobre el rayo
        const u = (qpx * dy - qpy * dx) / rxs;         // parámetro sobre el segmento [0,1]

        if (t > 0 && u >= 0 && u <= 1 && t < minT) {
            minT = t;
            edgeI = i;
            edgeU = u;
        }
    }

    if (!isFinite(minT) || edgeI < 0) return null;

    const j = (edgeI + 1) % points.length;
    const z1 = Number(points[edgeI].z) || 0;
    const z2 = Number(points[j].z) || 0;
    const zborde = z1 + edgeU * (z2 - z1);

    const distBorde = minT * distP;
    if (distBorde < 1e-3) return zborde;
    const tRad = Math.max(0, Math.min(1, distP / distBorde));

    return zc + tRad * (zborde - zc);
}

// Altura del plot:
// - Con 1 punto central: superficie RADIAL entre Z del centro y Z del perímetro (piramidal).
//   H(x,y) = Zacabado_radial(x,y) (la altura que has definido como “suelo→baldosa”).
// - En otros casos: Zacabado via triangulación (getZAt).
function calcularAlturaPlotEn(x, y) {
    let zAcabado = null;

    // Caso 1: un solo punto central → usamos interpolación radial tipo “pirámide”.
    if (drainagePoints.length === 1 && points.length >= 3) {
        zAcabado = getZRadialAt(x, y);
    }

    // Fallback: sin punto central (o más de uno), usamos la triangulación clásica.
    if (zAcabado == null) {
        zAcabado = getZAt(x, y);
    }
    if (zAcabado == null) return null;

    // Interpretamos Zacabado como la altura total desde el forjado hasta la cara superior de la baldosa.
    const alturaSoporte = Number(zAcabado);
    return Math.max(0, alturaSoporte);
}

// Distancia de un punto a un segmento; devuelve dist, punto más cercano y t (0..1) sobre el segmento
function distanceToSegment(px, py, x1, y1, x2, y2) {
    const vx = x2 - x1, vy = y2 - y1;
    const wx = px - x1, wy = py - y1;
    const v2 = vx * vx + vy * vy;
    if (v2 < 1e-6) return { dist: Math.hypot(wx, wy), closestX: x1, closestY: y1, t: 0 };
    let t = (wx * vx + wy * vy) / v2;
    t = Math.max(0, Math.min(1, t));
    const closestX = x1 + t * vx, closestY = y1 + t * vy;
    const dist = Math.hypot(px - closestX, py - closestY);
    return { dist, closestX, closestY, t };
}

// ========== EVENTOS CANVAS (ratón / táctil) ==========
function getCanvasCoordsFromEvent(e) {
    const rect = canvas.getBoundingClientRect();
    const point = (e.touches && e.touches[0]) || (e.changedTouches && e.changedTouches[0]) || e;
    // El contenedor interno pg-canvas-inner se escala con transform: scale(viewZoom).
    // getBoundingClientRect devuelve coordenadas ya escaladas, así que para volver
    // a las coordenadas "lógicas" en las que dibujamos (las mismas que usan points[],
    // drainagePoints, etc.), tenemos que dividir por viewZoom.
    const rawX = point.clientX - rect.left;
    const rawY = point.clientY - rect.top;
    const x = rawX / viewZoom;
    const y = rawY / viewZoom;
    return { x, y };
}

canvas.addEventListener('mousedown', (e) => {
    const { x, y } = getCanvasCoordsFromEvent(e);

    const isPlanStep = (currentStep === 1 || currentStep === 2);

    // Click en el gizmo de direcciones (solo paso 1):
    // solo se acepta cuando estamos exactamente sobre una flecha (estado hover amarillo)
    if (currentStep === 1 && directionGizmo && typeof directionGizmo.hoverDir === "number") {
        const bestDir = directionGizmo.hoverDir;
        const popup = document.getElementById('dk-direction-popup');
        const angInput = document.getElementById('dk-dir-angle');
        const distInput = document.getElementById('dk-dir-dist');
        if (popup) popup.style.display = 'flex';
        if (angInput) angInput.value = String(bestDir);
        // Preseleccionar el valor de distancia para que puedas escribir directamente.
        // Lo hacemos en un timeout corto para asegurar que el popup ya está pintado.
        if (distInput) {
            setTimeout(() => {
                distInput.focus();
                distInput.select();
            }, 0);
        }
        directionGizmo.selectedDir = bestDir;
        return;
    }

    // Eliminar puntos/sumideros solo en pasos de plano (1 y 2)
    if (isPlanStep) {
        for (let i = 0; i < drainagePoints.length; i++) {
        if (isClickOnTrash(x, y, drainagePoints[i].x, drainagePoints[i].y, TRASH_DRAINAGE_OFFSET_X, TRASH_DRAINAGE_OFFSET_Y)) {
            drainagePoints.splice(i, 1);
            updateTriangulation();
            pushUndoState();
            draw();
            return;
        }
        }
        for (let i = 0; i < points.length; i++) {
        if (isClickOnTrash(x, y, points[i].x, points[i].y)) {
            points.splice(i, 1);
            if (points.length < 3) isClosed = false;
            updateTriangulation();
            syncPointsTable();
            pushUndoState();
            draw();
            return;
        }
        }
    }

    // Arrastrar puntos solo en pasos de plano
    if (isPlanStep) {
        for (let i = 0; i < drainagePoints.length; i++) {
        const dp = drainagePoints[i];
        const dist = Math.hypot(x - dp.x, y - dp.y);
        if (dist < POINT_HIT_RADIUS) {
            draggingDrainage = i;
            return;
        }
    }

        for (let i = 0; i < points.length; i++) {
        const p = points[i];
        const dist = Math.hypot(x - p.x, y - p.y);
        if (dist < POINT_HIT_RADIUS) {
            if (i === 0 && !isClosed && points.length > 2) {
                isClosed = true;
                updateTriangulation();
                syncPointsTable();
                pushUndoState();
                draw();
            } else {
                draggingPoint = i;
                draw();
            }
            return;
        }
        }
    }

    if (currentStep === 3) {
        // En replanteo, al pulsar cerca de un punto del perímetro (A, B, C...),
        // activamos la selección de origen/ángulo (primera vez o posteriores).
        let bestIdx = -1;
        let bestDist = Infinity;
        for (let i = 0; i < points.length; i++) {
            const p = points[i];
            const dist = Math.hypot(x - p.x, y - p.y);
            if (dist < bestDist) {
                bestDist = dist;
                bestIdx = i;
            }
        }
        if (bestIdx >= 0 && bestDist <= POINT_HIT_RADIUS * 1.5) {
            const p = points[bestIdx];
            anglePreviewStart = { x: p.x, y: p.y };
            anglePreviewCurrent = { x: p.x, y: p.y };
            anglePreviewPointIndex = bestIdx;
            anglePreviewDragging = true;
            anglePreviewActive = false; // se activará al mover
            return;
        }

        // Desactivamos el arrastre manual del origen de la malla con el ratón:
        // el usuario no quiere que la malla se mueva con el cursor en este paso.
        if (Math.hypot(x - gridOrigin.x, y - gridOrigin.y) < 20) {
            // ignoramos arrastre de origen en este paso
            return;
        }
    }

    if ((currentStep === 1 || currentStep === 2) && planMode === 'move') {
        draw();
        return;
    }

    if (currentStep === 1 && isClosed && points.length >= 3) {
        const SEGMENT_HIT = 18;
        for (let i = 0; i < points.length; i++) {
            const j = (i + 1) % points.length;
            const A = points[i], B = points[j];
            const r = distanceToSegment(x, y, A.x, A.y, B.x, B.y);
            if (r.dist < SEGMENT_HIT && r.t > 0.05 && r.t < 0.95) {
                const z = Math.round((1 - r.t) * (A.z ?? 0) + r.t * (B.z ?? 0));
                points.splice(j, 0, { x: Math.round(r.closestX), y: Math.round(r.closestY), z });
                updateTriangulation();
                syncPointsTable();
                pushUndoState();
                draw();
                return;
            }
        }
    }

    if (currentStep === 1 && !isClosed) {
        // Snap al primer punto si estamos cerca y ya hay al menos 3 puntos
        if (points.length > 2 && points[0] && Math.hypot(x - points[0].x, y - points[0].y) < 18) {
            isClosed = true;
            updateTriangulation();
            syncPointsTable();
            pushUndoState();
        } else {
            const sx = Math.round(x / GRID_SIZE) * GRID_SIZE;
            const sy = Math.round(y / GRID_SIZE) * GRID_SIZE;
            points.push({ x: sx, y: sy, z: 0 });
            pushUndoState();
        }
    } else if (currentStep === 2 && isPointInPoly(x, y)) {
        drainagePoints.push({ x: x, y: y, z: 0 });
        updateTriangulation();
        pushUndoState();
    }

    draw();
});

canvas.addEventListener('contextmenu', (e) => {
    e.preventDefault();
    const { x, y } = getCanvasCoordsFromEvent(e);
    // Borrado con botón derecho solo en pasos 1 y 2
    if (!(currentStep === 1 || currentStep === 2)) return;
    for (let i = drainagePoints.length - 1; i >= 0; i--) {
        if (Math.hypot(x - drainagePoints[i].x, y - drainagePoints[i].y) < POINT_HIT_RADIUS) {
            drainagePoints.splice(i, 1);
            updateTriangulation();
            pushUndoState();
            draw();
            return;
        }
    }
    for (let i = points.length - 1; i >= 0; i--) {
        if (Math.hypot(x - points[i].x, y - points[i].y) < POINT_HIT_RADIUS) {
            points.splice(i, 1);
            if (points.length < 3) isClosed = false;
            updateTriangulation();
            syncPointsTable();
            pushUndoState();
            draw();
            return;
        }
    }
});

canvas.addEventListener('dblclick', (e) => {
    const { x, y } = getCanvasCoordsFromEvent(e);

    // Editar cotas solo en pasos 1 y 2
    if (!(currentStep === 1 || currentStep === 2)) return;
    
    for (let i = 0; i < points.length; i++) {
        const p = points[i];
        if (Math.hypot(x - p.x, y - p.y) < 20) {
            zEditIndex = i;
            const popup = document.getElementById('dk-z-popup');
            const input = document.getElementById('dk-z-value');
            const chk = document.getElementById('dk-z-apply-all');
            if (popup && input && chk) {
                input.value = p.z ?? 0;
                chk.checked = false;
                popup.style.display = "flex";
                // Enfocar y seleccionar automáticamente el valor para editar rápido
                setTimeout(() => {
                    input.focus();
                    input.select();
                }, 0);
            }
            return;
        }
    }

    drainagePoints.forEach((dp, i) => {
        if (Math.sqrt((x - dp.x) ** 2 + (y - dp.y) ** 2) < 20) {
            let h = prompt(`Nueva cota Z para el sumidero ${i + 1} (en mm):`, dp.z);
            if (h !== null && h !== "") {
                dp.z = parseFloat(h);
                updateTriangulation();
                pushUndoState();
                draw();
            }
        }
    });
});
canvas.addEventListener('mousemove', (e) => {
    const { x, y } = getCanvasCoordsFromEvent(e);
    mousePos = {x, y};

    if (currentStep === 3 && anglePreviewDragging) {
        anglePreviewCurrent = { x, y };
        anglePreviewActive = true;
        draw();
        return;
    }

    if (isDraggingOrigin) { 
        gridOrigin = {x, y}; 
    } else {
        hoveredPoint = null;
        points.forEach((p, i) => {
            const d = Math.hypot(x - p.x, y - p.y);
            const dTrash = Math.hypot(x - (p.x + TRASH_OFFSET_X), y - (p.y + TRASH_OFFSET_Y));
            if (d < POINT_HIT_RADIUS || dTrash < TRASH_HIT_RADIUS + 6) hoveredPoint = i;
        });
        hoveredDrainage = null;
        drainagePoints.forEach((dp, i) => {
            const d = Math.hypot(x - dp.x, y - dp.y);
            const dTrash = Math.hypot(x - (dp.x + TRASH_DRAINAGE_OFFSET_X), y - (dp.y + TRASH_DRAINAGE_OFFSET_Y));
            if (d < POINT_HIT_RADIUS || dTrash < TRASH_HIT_RADIUS + 6) hoveredDrainage = i;
        });
    }

    // Hover sobre las flechas del gizmo (solo paso 1)
    if (currentStep === 1 && directionGizmo) {
        const { cx, cy, size } = directionGizmo;
        const dx = x - cx;
        const dy = y - cy;
        const dist = Math.hypot(dx, dy);
        const maxR = size * 0.7;
        const minR = 8;
        let hover = null;
        if (dist >= minR && dist <= maxR) {
            if (Math.abs(dx) >= Math.abs(dy)) {
                hover = dx >= 0 ? 0 : 180;
            } else {
                hover = dy >= 0 ? 90 : -90;
            }
        }
        directionGizmo.hoverDir = hover;
    }

    // Cuando estamos dibujando el perímetro, detectar si el ratón está "sobre" el primer punto
    if (currentStep === 1 && !isClosed && points.length > 2 && points[0]) {
        hoverCloseFirst = Math.hypot(x - points[0].x, y - points[0].y) < 18;
    } else {
        hoverCloseFirst = false;
    }
    hoveredPlot = null;
    if (currentStep === 3) {
        const threshold = 8;
        for (let p of tempPlots) {
            const [px, py] = p.split(',').map(Number);
            if (Math.hypot(x - px, y - py) < threshold) {
                hoveredPlot = { x: px, y: py };
                break;
            }
        }
    }
    draw();
    if (draggingPoint !== null) {
        points[draggingPoint].x = Math.round(x/GRID_SIZE)*GRID_SIZE;
        points[draggingPoint].y = Math.round(y/GRID_SIZE)*GRID_SIZE;
        updateTriangulation();
    } else if (draggingDrainage !== null) {
        drainagePoints[draggingDrainage].x = x;
        drainagePoints[draggingDrainage].y = y;
        updateTriangulation();
    }

});

window.addEventListener('mouseup', () => {
    // Finalizar selección de ángulo/origen en replanteo
    if (currentStep === 3 && anglePreviewDragging && anglePreviewStart) {
        const start = anglePreviewStart;
        const current = anglePreviewCurrent || anglePreviewStart;
        const dx = current.x - start.x;
        const dy = current.y - start.y;

        if (anglePreviewActive && Math.hypot(dx, dy) > 5) {
            // Caso arrastre: usar la línea verde como referencia de ángulo
            let angDeg = (Math.atan2(dy, dx) * 180 / Math.PI);
            if (angDeg < 0) angDeg += 360;
            rotationAngle = Math.round(angDeg);
            const angleInput = document.getElementById('tileAngle');
            if (angleInput) angleInput.value = rotationAngle;
            const angleVal = document.getElementById('angleVal');
            if (angleVal) angleVal.innerText = rotationAngle + "°";
        } else if (anglePreviewPointIndex != null) {
            // Caso clic rápido: alinear con el tramo del perímetro (punto → siguiente),
            // haciendo que el lado corto de la baldosa quede sobre ese tramo.
            const idx = anglePreviewPointIndex;
            const angDeg = getAngleForPerimeterPoint(idx);
            if (angDeg != null) {
                rotationAngle = Math.round(angDeg);
                const angleInput = document.getElementById('tileAngle');
                if (angleInput) angleInput.value = rotationAngle;
                const angleVal = document.getElementById('angleVal');
                if (angleVal) angleVal.innerText = rotationAngle + "°";
            }
        }

        // Fijar origen en el punto elegido y desbloquear replanteo
        gridOrigin = { x: start.x, y: start.y };
        pendingTileOriginSelection = false;
        anglePreviewDragging = false;
        anglePreviewActive = false;
        anglePreviewStart = null;
        anglePreviewCurrent = null;
        anglePreviewPointIndex = null;
        draw();
        return;
    }

    if (draggingPoint !== null || draggingDrainage !== null) pushUndoState();
    draggingPoint = null;
    draggingDrainage = null;
    isMovingAll = false;
    updatePlanToolbarUI();
});

// Popup edición cota Z
window.cerrarPopupZ = () => {
    const popup = document.getElementById('dk-z-popup');
    if (popup) popup.style.display = "none";
    zEditIndex = null;
};

window.aplicarPopupZ = () => {
    const popup = document.getElementById('dk-z-popup');
    const input = document.getElementById('dk-z-value');
    const chk = document.getElementById('dk-z-apply-all');
    if (!popup || !input || !chk) return;
    if (zEditIndex == null || !points[zEditIndex]) {
        window.cerrarPopupZ();
        return;
    }
    const val = parseFloat(input.value);
    if (!Number.isFinite(val)) {
        return;
    }
    const aplicarATodos = chk.checked;
    if (aplicarATodos) {
        points.forEach(pt => { pt.z = val; });
    } else {
        points[zEditIndex].z = val;
    }

    updateTriangulation();
    pushUndoState();
    draw();
    syncPointsTable();
    window.cerrarPopupZ();
};

// Control del zoom de vista (botones +/−). factor > 1 acerca, < 1 aleja.
window.ajustarZoomVista = (factor) => {
    const nuevoZoom = Math.min(4, Math.max(0.25, viewZoom * factor));
    applyViewZoom(nuevoZoom);
};

// Ajusta el zoom para que el polígono actual se vea grande y centrado.
window.ajustarVistaPlano = () => {
    if (!points || points.length === 0) return;
    const holder = document.getElementById('pg-canvas-layer');
    const inner = document.getElementById('pg-canvas-inner');
    if (!holder || !inner) return;

    // Bounding box del perímetro
    let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;
    points.forEach(p => {
        minX = Math.min(minX, p.x);
        maxX = Math.max(maxX, p.x);
        minY = Math.min(minY, p.y);
        maxY = Math.max(maxY, p.y);
    });
    if (!Number.isFinite(minX) || !Number.isFinite(maxX)) return;

    const bboxW = Math.max(100, maxX - minX);
    const bboxH = Math.max(100, maxY - minY);

    const rect = holder.getBoundingClientRect();
    const padding = 80; // margen visual alrededor
    const availableW = Math.max(100, rect.width - padding * 2);
    const availableH = Math.max(100, rect.height - padding * 2);

    // Zoom que hace que el polígono quepa dentro del área disponible
    const zoomW = availableW / bboxW;
    const zoomH = availableH / bboxH;
    const targetZoom = Math.min(4, Math.max(0.25, Math.min(zoomW, zoomH)));
    applyViewZoom(targetZoom);

    // Centrar el polígono dentro del área visible desplazando el scroll del contenedor
    const holderScroll = document.getElementById('canvas-main-holder');
    if (!holderScroll) return;
    const centerX = (minX + maxX) / 2 * viewZoom;
    const centerY = (minY + maxY) / 2 * viewZoom;
    const viewportW = holderScroll.clientWidth;
    const viewportH = holderScroll.clientHeight;
    holderScroll.scrollLeft = Math.max(0, centerX - viewportW / 2);
    holderScroll.scrollTop = Math.max(0, centerY - viewportH / 2);
};

// Soporte táctil básico (iPad, tablets): reutiliza la misma lógica de ratón
canvas.addEventListener('touchstart', (e) => {
    e.preventDefault();
    const touch = e.touches[0] || e.changedTouches[0];
    if (!touch) return;
    const synthetic = new MouseEvent('mousedown', {
        clientX: touch.clientX,
        clientY: touch.clientY,
        button: 0,
        bubbles: true
    });
    canvas.dispatchEvent(synthetic);
}, { passive: false });

canvas.addEventListener('touchmove', (e) => {
    e.preventDefault();
    const touch = e.touches[0] || e.changedTouches[0];
    if (!touch) return;
    const synthetic = new MouseEvent('mousemove', {
        clientX: touch.clientX,
        clientY: touch.clientY,
        bubbles: true
    });
    canvas.dispatchEvent(synthetic);
}, { passive: false });

canvas.addEventListener('touchend', (e) => {
    e.preventDefault();
    const synthetic = new MouseEvent('mouseup', {
        clientX: 0,
        clientY: 0,
        bubbles: true
    });
    window.dispatchEvent(synthetic);
}, { passive: false });

// ========== DIBUJO AUXILIAR ==========
const TRASH_OFFSET_X = 28, TRASH_OFFSET_Y = -26;
const TRASH_DRAINAGE_OFFSET_X = 0, TRASH_DRAINAGE_OFFSET_Y = -28;
const TRASH_HIT_RADIUS = 22;
const POINT_HIT_RADIUS = 28;

function isClickOnTrash(clickX, clickY, pointX, pointY, offsetX = TRASH_OFFSET_X, offsetY = TRASH_OFFSET_Y) {
    return Math.hypot(clickX - (pointX + offsetX), clickY - (pointY + offsetY)) < TRASH_HIT_RADIUS;
}

function drawTrashIcon(x, y, offsetX = TRASH_OFFSET_X, offsetY = TRASH_OFFSET_Y) {
    const tx = x + offsetX, ty = y + offsetY;
    ctx.save();
    ctx.fillStyle = "#cc0000"; ctx.beginPath();
    ctx.arc(tx, ty, 12, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = "white"; ctx.lineWidth = 2; ctx.beginPath();
    ctx.moveTo(tx - 5, ty - 5); ctx.lineTo(tx + 5, ty + 5);
    ctx.moveTo(tx + 5, ty - 5); ctx.lineTo(tx - 5, ty + 5);
    ctx.stroke(); ctx.restore();
}

const drawSlopeInfo = (p1, p2, color = "#666") => {
    const dx = p2.x - p1.x;
    const dy = p2.y - p1.y;
    const distPx = Math.sqrt(dx * dx + dy * dy);
    if (distPx < 15) return;
    const distM = distPx / ESCALA_PX_METRO;
    const slopeVal = distM > 0.01 ? ((p1.z - p2.z) / (distM * 1000)) * 100 : 0;
    const absSlope = Math.abs(slopeVal).toFixed(1);
    const midX = (p1.x + p2.x) / 2;
    const midY = (p1.y + p2.y) / 2;
    // En canvas solo dejamos una flecha pequeña indicando sentido de caída.
    // El texto (distancia y %) ya se dibuja en la capa HTML.
    if (Math.abs(slopeVal) <= 0.1) return;

    const angle = Math.atan2(dy, dx);
    const direction = slopeVal > 0 ? angle : angle + Math.PI;
    const len = 12;

    ctx.save();
    ctx.translate(midX, midY);
    ctx.rotate(direction);
    ctx.strokeStyle = (color === "#004a8e") ? "rgba(0, 74, 142, 0.9)" : "rgba(245, 158, 11, 0.92)";
    ctx.lineWidth = 2.2;
    ctx.lineCap = "round";
    ctx.beginPath();
    ctx.moveTo(-len / 2, 0);
    ctx.lineTo(len / 2, 0);
    ctx.moveTo(len / 2, 0);
    ctx.lineTo(len / 2 - 4, -4);
    ctx.moveTo(len / 2, 0);
    ctx.lineTo(len / 2 - 4, 4);
    ctx.stroke();
    ctx.restore();
};

// Flechas grandes de pendiente (inspiradas en la captura de referencia)
function drawBigSlopeArrows() {
    if (!isClosed || !points.length || !showSlopes) return;

    // Centro geométrico del perímetro
    let sumX = 0, sumY = 0;
    points.forEach(p => { sumX += p.x; sumY += p.y; });
    const cx = sumX / points.length;
    const cy = sumY / points.length;

    // Bounding box para escalar tamaño de las flechas
    let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
    points.forEach(p => {
        minX = Math.min(minX, p.x);
        maxX = Math.max(maxX, p.x);
        minY = Math.min(minY, p.y);
        maxY = Math.max(maxY, p.y);
    });
    const ancho = maxX - minX;
    const alto  = maxY - minY;
    const baseLen = Math.max(60, Math.min(ancho, alto) * 0.25);

    // Decide si el agua va hacia dentro (sumidero bajo) o hacia fuera (punto alto)
    let modo = "none";
    if (drainagePoints.length === 1 && points.length >= 3) {
        const dp = drainagePoints[0];
        const zPerimetroMedio = points.reduce((a, p) => a + (p.z || 0), 0) / points.length;
        modo = (dp.z || 0) <= zPerimetroMedio ? "inward" : "outward";
    }
    if (modo === "none") return;

    // Flecha rellena tipo "flecha gorda"
    const drawArrowShape = (x1, y1, x2, y2) => {
        const dx = x2 - x1;
        const dy = y2 - y1;
        const len = Math.hypot(dx, dy);
        if (len < 30) return;
        const angle = Math.atan2(dy, dx);

        ctx.save();
        ctx.translate(x1, y1);
        ctx.rotate(angle);

        const cuerpo = len * 0.6;
        const altoF = 18;
        const cabeza = len - cuerpo;

        ctx.beginPath();
        ctx.moveTo(0, -altoF / 2);
        ctx.lineTo(cuerpo, -altoF / 2);
        ctx.lineTo(cuerpo, -altoF);
        ctx.lineTo(len, 0);
        ctx.lineTo(cuerpo, altoF);
        ctx.lineTo(cuerpo, altoF / 2);
        ctx.lineTo(0, altoF / 2);
        ctx.closePath();
        ctx.fill();

        ctx.restore();
    };

    ctx.save();
    ctx.globalAlpha = 0.22;
    ctx.fillStyle = "rgba(245, 158, 11, 1)"; // naranja

    // Cuatro direcciones principales (como las grandes flechas de la imagen)
    const dirs = [
        { dx:  1, dy:  0 }, // derecha
        { dx: -1, dy:  0 }, // izquierda
        { dx:  0, dy:  1 }, // abajo
        { dx:  0, dy: -1 }  // arriba
    ];

    dirs.forEach(d => {
        const ux = d.dx;
        const uy = d.dy;
        const offset = baseLen * 0.3;

        let tailX, tailY, headX, headY;
        if (modo === "outward") {
            tailX = cx;
            tailY = cy;
            headX = cx + ux * baseLen;
            headY = cy + uy * baseLen;
        } else { // inward: de fuera hacia dentro
            tailX = cx + ux * (baseLen + offset);
            tailY = cy + uy * (baseLen + offset);
            headX = cx + ux * offset;
            headY = cy + uy * offset;
        }
        drawArrowShape(tailX, tailY, headX, headY);
    });

    ctx.restore();
}

// ========== DIBUJO PRINCIPAL (CANVAS) ==========
function draw() {
    if (!ctx) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    if (isClosed) {
        calcularMetricas();
        renderSlopeMap();
    } else if (sCtx && slopeCanvas) {
        sCtx.clearRect(0, 0, slopeCanvas.width, slopeCanvas.height);
    }

    // Antes uníamos los sumideros con una línea discontinua para visualizar
    // la trama, pero generaba una figura geométrica confusa junto a los plots.
    // Eliminamos ese trazado para dejar solo el perímetro y las pendientes.
    if (backgroundImage && showBgImage) {
        ctx.save();
        ctx.globalAlpha = 0.4;
        const imgScale = parseFloat(document.getElementById('bgScale')?.value) || 1;
        const offX = parseFloat(document.getElementById('bgPosX')?.value) || 0;
        const offY = parseFloat(document.getElementById('bgPosY')?.value) || 0;
        const imgW = backgroundImage.width * imgScale;
        const imgH = backgroundImage.height * imgScale;
        const x = (canvas.width - imgW) / 2 + offX;
        const y = (canvas.height - imgH) / 2 + offY;
        ctx.drawImage(backgroundImage, x, y, imgW, imgH);
        ctx.restore();
    }
    ctx.strokeStyle = "rgba(238, 238, 238, 0.5)"; 
    ctx.lineWidth = getZoomedLineWidth(0.9);
    for(let i=0; i<canvas.width; i+=GRID_SIZE){
        const x = snapToPixel(i);
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, canvas.height);
        ctx.stroke();
    }
    for(let i=0; i<canvas.height; i+=GRID_SIZE){
        const y = snapToPixel(i);
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(canvas.width, y);
        ctx.stroke();
    }
    ctx.save();
    ctx.setLineDash([5, 5]); 
    ctx.strokeStyle = "rgba(0, 74, 142, 0.3)";
    const mx = snapToPixel(mousePos.x);
    const my = snapToPixel(mousePos.y);
    ctx.beginPath(); ctx.moveTo(mx, 0); ctx.lineTo(mx, canvas.height); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(0, my); ctx.lineTo(canvas.width, my); ctx.stroke();
    ctx.restore();
    if (currentStep >= 3) renderReplanteo();

    if (!points.length) {
        drawProfessionalRulers();
        renderHtmlOverlays();
        return;
    }
    ctx.save();
    if(isClosed) {
        ctx.shadowColor = "rgba(0,0,0,0.2)";
        ctx.shadowBlur = 10;
        ctx.shadowOffsetY = 5;
    }
    ctx.beginPath();
    ctx.strokeStyle = "#004a8e"; ctx.lineWidth = getZoomedLineWidth(2);
    points.forEach((p, i) => {
        const x = snapToPixel(p.x);
        const y = snapToPixel(p.y);
        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
    });
    if (isClosed) {
        ctx.closePath(); ctx.stroke();
        ctx.restore();
        // Etiquetas de ángulo/distancia en el perímetro (controladas por showAngles dentro de drawSlopeInfo)
        for (let i = 0; i < points.length; i++) {
            drawSlopeInfo(points[i], points[(i + 1) % points.length], "#004a8e");
        }
    } else { ctx.stroke(); ctx.restore(); }
    
    if (points.length > 0 && !isClosed) {
        const lastP = points[points.length - 1];
        let target = (hoverCloseFirst && points[0]) ? points[0] : mousePos;

        // Snap de previsualización: primero a dirección del gizmo si hay hover,
        // si no, a la cardinal más cercana (0, 90, 180, -90) si estamos cerca.
        let snapDir = null;
        if (currentStep === 1 && directionGizmo && typeof directionGizmo.hoverDir === "number") {
            snapDir = directionGizmo.hoverDir;
        } else {
            const dx = target.x - lastP.x;
            const dy = target.y - lastP.y;
            if (Math.hypot(dx, dy) > 10) {
                let ang = (Math.atan2(dy, dx) * 180 / Math.PI); // 0 derecha, 90 abajo, -90 arriba
                // normalizar a [-180,180]
                if (ang > 180) ang -= 360;
                const candidatos = [0, 90, 180, -90];
                let best = null;
                let bestDiff = 999;
                candidatos.forEach(a => {
                    const d = Math.abs(ang - a);
                    if (d < bestDiff) { bestDiff = d; best = a; }
                });
                const umbral = 5; // grados
                if (best !== null && bestDiff <= umbral) {
                    snapDir = best;
                }
            }
        }

        if (snapDir !== null) {
            const dx = target.x - lastP.x;
            const dy = target.y - lastP.y;
            const angRad = (snapDir * Math.PI) / 180;
            // proyectamos el vector ratón sobre la dirección elegida
            let dist = dx * Math.cos(angRad) + dy * Math.sin(angRad);
            if (dist < 0) dist = 0;
            target = {
                x: lastP.x + dist * Math.cos(angRad),
                y: lastP.y + dist * Math.sin(angRad)
            };
        }

        ctx.save();
        ctx.beginPath();
        ctx.setLineDash([5, 5]);
        ctx.strokeStyle = "rgba(0, 74, 142, 0.5)";
        ctx.lineWidth = 2;
        ctx.moveTo(lastP.x, lastP.y);
        ctx.lineTo(target.x, target.y);
        ctx.stroke();
        ctx.restore();

        // Guía ortogonal desde la primera vertical para ayudarte a cerrar rectángulos:
        // a partir de 2 puntos (A, B) ya mostramos el punto D sugerido usando la posición de previsualización.
        if (points.length >= 2) {
            const p0 = points[0];          // primer punto (A)
            const preview = target;        // punto que estás previsualizando ahora (puede ser C)
            const sugerido = { x: p0.x, y: preview.y }; // intersección de la vertical de A con la horizontal actual

            ctx.save();
            ctx.setLineDash([4, 4]);
            ctx.strokeStyle = "rgba(148, 163, 184, 0.9)";
            ctx.lineWidth = 1;
            // Línea horizontal desde el punto actual (preview) hasta la proyección
            ctx.beginPath();
            ctx.moveTo(preview.x, preview.y);
            ctx.lineTo(sugerido.x, sugerido.y);
            ctx.stroke();
            // Línea vertical desde A hasta el punto sugerido
            ctx.beginPath();
            ctx.moveTo(p0.x, p0.y);
            ctx.lineTo(sugerido.x, sugerido.y);
            ctx.stroke();
            // Marca del punto sugerido
            ctx.fillStyle = "#0f172a";
            ctx.beginPath();
            ctx.arc(sugerido.x, sugerido.y, 4, 0, Math.PI * 2);
            ctx.fill();
            ctx.restore();
        }

        const distM = Math.sqrt((target.x - lastP.x)**2 + (target.y - lastP.y)**2) / ESCALA_PX_METRO;
        
        ctx.fillStyle = "#004a8e";
        ctx.font = "bold 12px Arial";
        ctx.textAlign = "left";
        ctx.fillText(distM.toFixed(2) + " m", target.x + 15, target.y - 15);
    }

    // Línea verde de previsualización de ángulo/origen en replanteo (Paso 3)
    if (currentStep === 3 && anglePreviewDragging && anglePreviewStart && anglePreviewCurrent) {
        ctx.save();
        ctx.strokeStyle = "#16a34a";
        ctx.lineWidth = 2;
        ctx.setLineDash([8, 4]);
        ctx.beginPath();
        ctx.moveTo(anglePreviewStart.x, anglePreviewStart.y);
        ctx.lineTo(anglePreviewCurrent.x, anglePreviewCurrent.y);
        ctx.stroke();
        ctx.restore();
    } else if (currentStep === 3 && hoveredPoint != null && points.length >= 2) {
        // Previsualización rápida: al pasar el ratón por un punto del perímetro,
        // mostramos una "baldosa fantasma" con el mismo tamaño y orientación que
        // la primera baldosa apoyada en ese punto: una esquina en el punto A/B/C,
        // el lado corto alineado con el tramo del perímetro y la pieza entrando
        // hacia el interior del polígono.
        const idx = hoveredPoint;
        const angDeg = getAngleForPerimeterPoint(idx);
        if (angDeg == null) return;

        const rad = (angDeg * Math.PI) / 180;
        const cosA = Math.cos(rad);
        const sinA = Math.sin(rad);

        const formatoSelect = document.getElementById('tileFormat')?.value || "60,60";
        const [selectedW, selectedH] = formatoSelect.split(',').map(Number);
        const tW = selectedW * 0.75;
        const tH = selectedH * 0.75;

        const p = points[idx];

        // Ejes locales: u = dirección del lado corto (sobre el tramo),
        // v = perpendicular que empuja la baldosa hacia dentro del polígono.
        let ux = cosA;
        let uy = sinA;
        let vx = -sinA;
        let vy =  cosA;

        // Comprobamos si v apunta hacia el interior (aprox. hacia el centro)
        let cxPoly = 0, cyPoly = 0;
        points.forEach(pt => { cxPoly += pt.x; cyPoly += pt.y; });
        cxPoly /= points.length;
        cyPoly /= points.length;
        const toCenterX = cxPoly - p.x;
        const toCenterY = cyPoly - p.y;
        if (toCenterX * vx + toCenterY * vy < 0) {
            vx = -vx;
            vy = -vy;
        }

        // Esquinas: tomamos el punto de perímetro como una esquina de la baldosa
        const c0 = { x: p.x,                       y: p.y };
        const c1 = { x: p.x + ux * tW,             y: p.y + uy * tW };
        const c2 = { x: c1.x + vx * tH,            y: c1.y + vy * tH };
        const c3 = { x: p.x + vx * tH,             y: p.y + vy * tH };
        const corners = [c0, c1, c2, c3];

        ctx.save();
        ctx.fillStyle = "rgba(248, 113, 113, 0.25)";
        ctx.strokeStyle = "rgba(220, 38, 38, 0.9)";
        ctx.lineWidth = 1.2;
        ctx.beginPath();
        ctx.moveTo(corners[0].x, corners[0].y);
        for (let i = 1; i < corners.length; i++) {
            ctx.lineTo(corners[i].x, corners[i].y);
        }
        ctx.closePath();
        ctx.fill();
        ctx.stroke();
        ctx.restore();
    }

    // Gizmo de direcciones alrededor del último punto (solo en paso 1)
    let prevHoverDir = directionGizmo && directionGizmo.hoverDir;
    directionGizmo = null;
    if (currentStep === 1 && !isClosed && points.length > 0) {
        const p = points[points.length - 1];
        const size = 86; // tamaño del marco cruz (un poco más grande)
        const half = size / 2;

        ctx.save();

        // Dibujar el marco de cruz centrado en el punto
        if (dirFrameImg.complete) {
            ctx.drawImage(dirFrameImg, p.x - half, p.y - half, size, size);
        } else {
            ctx.strokeStyle = "#94a3b8";
            ctx.lineWidth = 1.5;
            ctx.strokeRect(p.x - half, p.y - half, size, size);
        }

        // Dibujar SIEMPRE las 4 flechas; la que está en hover se pinta en amarillo
        const dirs = [-90, 0, 90, 180];
        dirs.forEach((dir) => {
            const dirRad = (dir * Math.PI) / 180;

            // Longitud desde el centro hasta el extremo del brazo donde colocamos la flecha
            let armLen = half;
            if (dir === 180 || dir === 90) {
                armLen = half * 0.85;
            }

            let cx = p.x + Math.cos(dirRad) * armLen;
            let cy = p.y + Math.sin(dirRad) * armLen;

            // Ajuste fino por brazo:
            if (dir === -90) {
                // Arriba: un poco más hacia la izquierda
                cx -= 23.5;
                cy += 24;
            } else if (dir === 90) {
                // Abajo: un poco más hacia la derecha y hacia el centro
                cy -= 18;
                cx -= 23.5;
            } else if (dir === 180) {
                cx += 40;
            }

            ctx.save();
            ctx.translate(cx, cy);
            ctx.rotate(dirRad);

            const arrowSize = 14; // flecha un poco más larga y fina
            const offsetTowardCenter = -24; // un poco más cerca del centro
            ctx.translate(Math.cos(dirRad) * offsetTowardCenter, Math.sin(dirRad) * offsetTowardCenter);

            const isHover = (prevHoverDir === dir);
            ctx.strokeStyle = isHover ? "#facc15" : "#ffffff"; // amarillo en hover, blanco resto
            ctx.lineWidth = 2.2;
            ctx.lineCap = "round";
            ctx.beginPath();
            ctx.moveTo(-arrowSize / 2, 0);
            ctx.lineTo(arrowSize / 2, 0);
            ctx.moveTo(arrowSize / 2, 0);
            ctx.lineTo(arrowSize / 2 - 6, -6);
            ctx.moveTo(arrowSize / 2, 0);
            ctx.lineTo(arrowSize / 2 - 6, 6);
            ctx.stroke();
            ctx.restore();
        });

        // Letra del punto (A, B, C...) centrada dentro del marco, en negro
        ctx.save();
        ctx.fillStyle = "#111827";
        ctx.font = "600 14px 'Inter Tight', system-ui, sans-serif";
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        ctx.fillText(getLabel(points.length - 1), p.x, p.y);
        ctx.restore();

        ctx.restore();
        directionGizmo = {
            index: points.length - 1,
            cx: p.x,
            cy: p.y,
            size,
            hoverDir: prevHoverDir
        };
    }

    if (isClosed && showSlopes) {
        const allNodes = [...points, ...drainagePoints];

        triangles.forEach((tri) => {
            const p0 = allNodes[tri.v[0]];
            const p1 = allNodes[tri.v[1]];
            const p2 = allNodes[tri.v[2]];
            if (!p0 || !p1 || !p2) return;

            ctx.save(); 
            ctx.setLineDash([4, 4]);
            ctx.strokeStyle = "rgba(150, 150, 150, 0.3)";
            ctx.beginPath();
            ctx.moveTo(p0.x, p0.y);
            ctx.lineTo(p2.x, p2.y);
            ctx.stroke(); 
            ctx.restore();

            drainagePoints.forEach(dp => {
                if (isPointInTriangle(dp, p0, p1, p2)) {
                    [p0, p1, p2].forEach(v => {
                        ctx.save(); 
                        ctx.setLineDash([2, 2]);
                        ctx.strokeStyle = "rgba(0, 74, 142, 0.2)";
                        ctx.beginPath();
                        ctx.moveTo(dp.x, dp.y);
                        ctx.lineTo(v.x, v.y);
                        ctx.stroke(); 
                        ctx.restore();

                        drawSlopeInfo(v, dp, "#f59e0b");
                    });
                }
            });
        });
    }

    points.forEach((p, i) => {
        const isHovered = (hoveredPoint === i);

        if (showPerimeterPoints) {
            const gizmoIndex = directionGizmo ? directionGizmo.index : -1;
            // No dibujar el círculo azul antiguo justo en el punto del gizmo
            if (!(currentStep === 1 && !isClosed && i === gizmoIndex)) {
                ctx.fillStyle = isHovered ? "#ffcc00" : "#004a8e";
                ctx.beginPath(); ctx.arc(p.x, p.y, 12, 0, Math.PI * 2); ctx.fill();
                ctx.fillStyle = "white";
                ctx.beginPath(); ctx.arc(p.x, p.y, 9, 0, Math.PI * 2); ctx.fill();
            }
            
            // Icono de borrar solo en pasos de plano (1 y 2)
            if (isHovered && !isDraggingOrigin && (currentStep === 1 || currentStep === 2)) {
                drawTrashIcon(p.x, p.y);
            }

            // Resalte especial del primer punto cuando vamos a cerrar el perímetro
            if (!isClosed && i === 0 && hoverCloseFirst) {
                ctx.save();
                ctx.strokeStyle = "#22c55e";
                ctx.lineWidth = 3;
                ctx.beginPath();
                ctx.arc(p.x, p.y, 16, 0, Math.PI * 2);
                ctx.stroke();
                ctx.restore();
            }
        }
        
        // Cotas Z pasan a la capa HTML (pg-z-label-html)
    });
    drainagePoints.forEach((dp, i) => {
        const isHovered = (hoveredDrainage === i);
        // Círculo bien visible en amarillo, con borde oscuro; en hover, borde rojo.
        ctx.fillStyle = "#facc15";
        ctx.strokeStyle = isHovered ? "#b91c1c" : "#1f2937";
        ctx.lineWidth = 2.5;
        ctx.beginPath();
        ctx.arc(dp.x, dp.y, 11, 0, Math.PI * 2);
        ctx.fill();
        ctx.stroke();
        
        // Cruz interior en blanco para diferenciarlo de los puntos de perímetro.
        ctx.strokeStyle = "#ffffff";
        ctx.lineWidth = 2;
        ctx.beginPath(); ctx.moveTo(dp.x - 5, dp.y); ctx.lineTo(dp.x + 5, dp.y); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(dp.x, dp.y - 5); ctx.lineTo(dp.x, dp.y + 5); ctx.stroke();

        // Icono de borrar sumidero solo en pasos 1 y 2
        if (isHovered && (currentStep === 1 || currentStep === 2)) {
            drawTrashIcon(dp.x, dp.y, TRASH_DRAINAGE_OFFSET_X, TRASH_DRAINAGE_OFFSET_Y);
        }
        
        // La etiqueta Z de sumidero pasa a la capa HTML (pg-z-label-html--drain),
        // para que el texto sea nítido en pantallas retina.
    });

    // Actualizar capa HTML de etiquetas una vez dibujado todo
    renderHtmlOverlays();

    // Tooltip HTML para plots (altura / serie) en Replanteo
    const plotTooltip = document.getElementById('pg-plot-tooltip');
    const plotTooltipText = document.getElementById('pg-plot-tooltip-text');
    if (plotTooltip && plotTooltipText) {
        if (currentStep === 3 && hoveredPlot) {
            const altura = calcularAlturaPlotEn(hoveredPlot.x, hoveredPlot.y);
            if (altura !== null) {
                const infoSoporte = getInfoSoporte(altura);
                const textoAltura = `H: ${Math.round(altura)} mm · ${infoSoporte.nombre}`;
                plotTooltipText.textContent = textoAltura;
                plotTooltip.style.display = "block";
                plotTooltip.style.left = `${hoveredPlot.x + 18}px`;
                plotTooltip.style.top = `${hoveredPlot.y - 40}px`;
            } else {
                plotTooltip.style.display = "none";
            }
        } else {
            plotTooltip.style.display = "none";
        }
    }
    if (isClosed) {
        const piezasVal = document.getElementById('piezasVal');
        if (piezasVal) piezasVal.innerText = tempPlots.size;

        const piezasCorteVal = document.getElementById('piezasCorteVal');
        if (piezasCorteVal) piezasCorteVal.innerText = calcularCortesPerimetrales();
    }
    drawProfessionalRulers();
}
function dibujarTextoLegible(contexto, texto, x, y, color, escala = 1) {
    contexto.save();
    const fontSize = Math.max(12, 15 / escala);
    contexto.font = `bold ${fontSize}px Arial`;
    contexto.textAlign = "center";
    const paddingX = 8 / escala;
    const paddingY = 4 / escala;
    const textWidth = contexto.measureText(texto).width;
    contexto.fillStyle = "rgba(255,255,255,0.96)";
    contexto.strokeStyle = "rgba(220,38,38,0.8)"; // rojo borde
    contexto.lineWidth = 1.2 / escala;
    contexto.beginPath();
    contexto.roundRect(
        x - textWidth / 2 - paddingX,
        y - fontSize - paddingY,
        textWidth + paddingX * 2,
        fontSize + paddingY * 2,
        8 / escala
    );
    contexto.fill();
    contexto.stroke();
    contexto.fillStyle = color;
    contexto.fillText(texto, x, y - 1);
    contexto.restore();
}

// ========== ACCIONES GLOBALES (window) ==========
window.centrarReplanteo = () => {
    if (!isClosed || points.length === 0) return;
    let sumX = 0, sumY = 0;
    points.forEach(p => { sumX += p.x; sumY += p.y; });
    gridOrigin = { x: sumX / points.length, y: sumY / points.length };
    const btnCentrar = document.getElementById('btn-centrar');
    const btnDescentrar = document.getElementById('btn-descentrar');
    if (btnCentrar) btnCentrar.classList.add('active');
    if (btnDescentrar) btnDescentrar.classList.remove('active');
    draw();
};

window.descentrarReplanteo = () => {
    gridOrigin = { x: canvas.width / 2, y: canvas.height / 2 };
    const btnCentrar = document.getElementById('btn-centrar');
    const btnDescentrar = document.getElementById('btn-descentrar');
    if (btnDescentrar) btnDescentrar.classList.add('active');
    if (btnCentrar) btnCentrar.classList.remove('active');
    draw();
};

// ====== Toggles de visibilidad de capas ======
window.togglePerimeterPoints = () => {
    showPerimeterPoints = !showPerimeterPoints;
    const btn = document.getElementById('btn-vis-points');
    if (btn) btn.classList.toggle('active', showPerimeterPoints);
    draw();
};

window.togglePerimeterHeights = () => {
    showPerimeterHeights = !showPerimeterHeights;
    const btn = document.getElementById('btn-vis-heights');
    if (btn) btn.classList.toggle('active', showPerimeterHeights);
    draw();
};

window.toggleSlopes = () => {
    showSlopes = !showSlopes;
    const btn = document.getElementById('btn-vis-slopes');
    if (btn) btn.classList.toggle('active', showSlopes);
    draw();
};

window.toggleAngles = () => {
    showAngles = !showAngles;
    const btn = document.getElementById('btn-vis-angles');
    if (btn) btn.classList.toggle('active', showAngles);
    draw();
};

// Abrir vista 3D en nueva pestaña
window.abrirVista3D = () => {
    if (!isClosed) {
        alert("Primero cierra el perímetro y genera los plots (Paso 3).");
        return;
    }
    if (!tempPlots || tempPlots.size === 0) {
        renderReplanteo();
        if (!tempPlots || tempPlots.size === 0) {
            alert("No hay plots generados para mostrar en 3D.");
            return;
        }
    }

    const plots = [];
    tempPlots.forEach(pStr => {
        const [px, py] = pStr.split(',').map(Number);
        const h = calcularAlturaPlotEn(px, py);
        if (h == null || h <= 0) return;
        const info = getInfoSoporte(h);
        plots.push({
            x: px,
            y: py,
            h,
            color: info && info.color ? info.color : "#0070c0"
        });
    });

    if (!plots.length) {
        alert("No hay alturas de plots positivas para mostrar en 3D.");
        return;
    }

    const perimeter = points.map(p => ({
        x: p.x,
        y: p.y,
        z: p.z || 0
    }));
    const center = drainagePoints.map(dp => ({
        x: dp.x,
        y: dp.y,
        z: dp.z || 0
    }));

    const payload = {
        plots,
        perimeter,
        center,
        tileSize: { w: tileWidth, h: tileHeight },
        rotation: rotationAngle,
        origin: gridOrigin
    };

    // Guardamos en localStorage (cuando el navegador lo permite)
    try {
        window.localStorage.setItem("dakota3dData", JSON.stringify(payload));
    } catch (e) {
        // ignore
    }

    // Y también colgamos los datos del window actual para que 3d.html pueda leerlos vía window.opener
    window.__dakota3dData = payload;

    window.open("3d.html", "_blank");
};

function analizarSeguridadPendientes() {
    let alertas = [];
    for (let i = 0; i < points.length; i++) {
        let j = (i + 1) % points.length;
        const p1 = points[i], p2 = points[j];
        const distM = Math.sqrt((p2.x - p1.x)**2 + (p2.y - p1.y)**2) / ESCALA_PX_METRO;
        const slope = distM > 0.05 ? Math.abs(((p1.z - p2.z) / (distM * 1000)) * 100) : 0;

        if (slope > 4) alertas.push(`Tramo ${getLabel(i)}-${getLabel(j)}: Pendiente excesiva (${slope.toFixed(1)}%). Riesgo de deslizamiento.`);
        if (slope < 1 && slope > 0) alertas.push(`Tramo ${getLabel(i)}-${getLabel(j)}: Pendiente escasa (${slope.toFixed(1)}%). Riesgo de estancamiento.`);
    }
    return alertas;
}

window.generarPresupuestoSoportes = () => {
    if (!isClosed || tempPlots.size === 0) {
        alert("Primero completa el replanteo (Paso 3) para generar el desglose.");
        return;
    }

    let desglose = {};
    let totalExtensiones = 0;
    const grosorBaldosa = 20;
    const margen = parseFloat(document.getElementById('alturaExtra')?.value) || 50;
    const maxZ = Math.max(...points.map(p => p.z), ...drainagePoints.map(p => p.z));
    const nivelAcabadoSuperior = drainagePoints.length > 0
        ? Math.max(...drainagePoints.map(dp => (dp.z != null ? Number(dp.z) : 0) + margen))
        : maxZ + margen;

    tempPlots.forEach(pStr => {
        const [px, py] = pStr.split(',').map(Number);
        const alturaNecesaria = calcularAlturaPlotEn(px, py);
        const info = getInfoSoporte(alturaNecesaria);
        const modelo = info.nombre;
        desglose[modelo] = (desglose[modelo] || 0) + 1;
        if (info.id === "ARK_EXT") {
            const numExt = Math.ceil((alturaNecesaria - 220) / 100);
            totalExtensiones += numExt;
        }
    });
    if (totalExtensiones > 0) {
        desglose["Extensión ARK P100 (100mm)"] = totalExtensiones;
    }
    console.log("%c--- DESGLOSE DE MATERIALES DAKOTA ARKIMEDE ---", "color: #004a8e; font-weight: bold; font-size: 12px;");
    console.table(desglose);
    let mensaje = `📦 RESUMEN DE PEDIDO ARKIMEDE\n`;
    mensaje += `Nivel de acabado: ${nivelAcabadoSuperior} mm\n`;
    mensaje += `-------------------------------------------\n`;
    
    for (const [modelo, cantidad] of Object.entries(desglose)) {
        mensaje += `${cantidad.toString().padEnd(5)} x  ${modelo}\n`;
    }
    
    mensaje += `-------------------------------------------\n`;
    mensaje += `Total puntos de apoyo: ${tempPlots.size} uds.`;

    alert(mensaje);
    
    return desglose;
};


window.actualizarFormatoDakota = function() {
    const select = document.getElementById('tileFormat');
    const [w, h] = select.value.split(',').map(Number);
    tileWidth = w;
    tileHeight = h;
    draw();
};
window.updateAngle = (val) => { rotationAngle = val; const el = document.getElementById('angleVal'); if (el) el.innerText = val + '°'; draw(); };

// Popup de dirección/distancia para siguiente punto
window.cerrarPopupDireccion = () => {
    const popup = document.getElementById('dk-direction-popup');
    if (popup) popup.style.display = 'none';
};

window.aplicarDireccionSiguientePunto = () => {
    if (!directionGizmo || directionGizmo.index == null || !points[directionGizmo.index]) {
        window.cerrarPopupDireccion();
        return;
    }
    const base = points[directionGizmo.index];
    const distInput = document.getElementById('dk-dir-dist');
    const angInput = document.getElementById('dk-dir-angle');
    if (!(distInput instanceof HTMLInputElement) || !(angInput instanceof HTMLInputElement)) {
        window.cerrarPopupDireccion();
        return;
    }
    const distM = parseFloat(distInput.value);
    const angDeg = parseFloat(angInput.value);
    if (!Number.isFinite(distM) || !Number.isFinite(angDeg)) {
        window.cerrarPopupDireccion();
        return;
    }
    const distPx = distM * ESCALA_PX_METRO;
    const angRad = (angDeg * Math.PI) / 180;
    const nx = base.x + distPx * Math.cos(angRad);
    // Y hacia abajo debe ser positivo en canvas, por eso sumamos
    const ny = base.y + distPx * Math.sin(angRad);
    points.push({ x: Math.round(nx), y: Math.round(ny), z: 0 });
    updateTriangulation();
    syncPointsTable();
    pushUndoState();
    window.cerrarPopupDireccion();
    draw();
};

// Pantalla de bienvenida: entrar en calculadora Arkimede
window.iniciarCalculadora = (sistema) => {
    // Por ahora solo usamos 'ARKIMEDE', pero dejamos el parámetro por si se amplía.
    const landing = document.getElementById('dakota-landing');
    const app = document.getElementById('dakota-app');
    if (landing) landing.style.display = 'none';
    if (app) app.style.display = 'flex';
};

// Modo plots centrales (auto / nunca) controlado por checkbox
window.toggleCentralPlots = () => {
    const chk = document.getElementById('chk-central-disable');
    const off = chk ? chk.checked : false;
    centralMode = off ? 'off' : 'auto';
    // Recalcular replanteo para aplicar el nuevo modo
    if (isClosed) {
        renderReplanteo();
        draw();
    }
};

window.resetCanvas = () => {
    points = [];
    drainagePoints = [];
    triangles = [];
    isClosed = false;
    planMode = 'perimeter';
    isMovingAll = false;
    setStep(1);
    syncPointsTable();
    undoHistory = [];
    undoIndex = -1;
    pushUndoState();
};

setStep(1);
pushUndoState();

(function initInstructionsPanel() {
    const wrap = document.getElementById('pg-instructions-wrap');
    const panel = document.getElementById('pg-instructions-panel');
    const tab = document.getElementById('pg-instructions-tab');
    const closeBtn = document.getElementById('pg-instructions-close');
    if (!wrap || !panel || !tab || !closeBtn) return;
    closeBtn.addEventListener('click', () => {
        wrap.classList.add('pg-instructions--closed');
    });
    tab.addEventListener('click', () => {
        wrap.classList.remove('pg-instructions--closed');
    });
})();

(function initProjectPanel() {
    const wrap = document.getElementById('pg-project-wrap');
    const card = document.getElementById('pg-project-card');
    const tab = document.getElementById('pg-project-tab');
    const closeBtn = document.getElementById('pg-project-close');
    if (!wrap || !card || !tab || !closeBtn) return;
    closeBtn.addEventListener('click', () => {
        wrap.classList.add('pg-project--closed');
    });
    tab.addEventListener('click', () => {
        wrap.classList.remove('pg-project--closed');
    });
})();

window.addEventListener('keydown', (e) => {
    if (e.ctrlKey && e.key === 'z') {
        e.preventDefault();
        if (e.shiftKey) redo();
        else undo();
    }
    if (e.ctrlKey && e.key === 'y') {
        e.preventDefault();
        redo();
    }
});
