(function () {
  let data = null;
  const dataRaw = window.localStorage.getItem("dakota3dData");
  if (dataRaw) {
    try {
      data = JSON.parse(dataRaw);
    } catch (e) {
      console.error("Error parseando dakota3dData desde localStorage", e);
    }
  }

  if (!data && window.opener && window.opener.__dakota3dData) {
    data = window.opener.__dakota3dData;
  }

  if (!data) {
    alert("No hay datos de replanteo para mostrar en 3D.\nVuelve a la calculadora y pulsa el botón 3D después de generar los plots.");
    return;
  }

  const { plots, perimeter, center, tileSize, rotation = 0, origin } = data;
  if (!plots || !plots.length || !perimeter || !perimeter.length) {
    alert("Datos 3D incompletos.");
    return;
  }

  const scene = new THREE.Scene();
  scene.background = new THREE.Color(0xf4f4f4);

  const camera = new THREE.PerspectiveCamera(
    45,
    window.innerWidth / window.innerHeight,
    0.1,
    10000
  );

  const renderer = new THREE.WebGLRenderer({ antialias: true });
  renderer.setSize(window.innerWidth, window.innerHeight);
  document.body.appendChild(renderer.domElement);

  const light = new THREE.DirectionalLight(0xffffff, 1);
  light.position.set(1000, 2000, 1000);
  scene.add(light);
  scene.add(new THREE.AmbientLight(0xffffff, 0.4));

  const PX_TO_M = 1 / 75;      // 1 px  ~= 0.01333 m
  const SCALE = PX_TO_M;       // para X,Z
  const HEIGHT_SCALE = 0.001;  // 1 mm = 0.001 m para Y

  const xs = perimeter.map((p) => p.x * SCALE);
  const ys = perimeter.map((p) => p.y * SCALE);
  const minX = Math.min(...xs);
  const maxX = Math.max(...xs);
  const minY = Math.min(...ys);
  const maxY = Math.max(...ys);

  const width = maxX - minX;
  const depth = maxY - minY;

  const floorGeom = new THREE.PlaneGeometry(width, depth);
  const floorMat = new THREE.MeshPhongMaterial({
    color: 0xd4d4d8,        // gris hormigón claro
    side: THREE.DoubleSide,
    specular: 0x9ca3af,
    shininess: 35,
  });
  const floor = new THREE.Mesh(floorGeom, floorMat);
  floor.rotation.x = -Math.PI / 2;
  floor.position.set(
    (minX + maxX) / 2,
    0,
    (minY + maxY) / 2
  );
  scene.add(floor);

  // Dibujo del perímetro proyectado sobre el plano, para que se lea bien
  // la forma de la terraza por debajo de los plots.
  if (perimeter && perimeter.length >= 2) {
    const perimPoints = perimeter.map((p) => new THREE.Vector3(p.x * SCALE, 0.002, p.y * SCALE));
    // Cerramos el lazo manualmente para asegurar contorno continuo
    perimPoints.push(new THREE.Vector3(perimeter[0].x * SCALE, 0.002, perimeter[0].y * SCALE));
    const perimGeom = new THREE.BufferGeometry().setFromPoints(perimPoints);
    const perimMat = new THREE.LineBasicMaterial({
      color: 0x004a8e,
      linewidth: 2
    });
    const perimLine = new THREE.Line(perimGeom, perimMat);
    scene.add(perimLine);
  }

  const HEAD_DIAM_MM = 120;
  const HEAD_RADIUS_M = (HEAD_DIAM_MM / 1000) / 2; // 0.06 m
  const baseRadius = HEAD_RADIUS_M;

  plots.forEach((p) => {
    const h = p.h || 0;
    if (h <= 0) return;
    // h viene en mm; lo convertimos con HEIGHT_SCALE para que no parezcan centímetros exagerados
    const altura = h * HEIGHT_SCALE;
    // Mismo color que en 2D (serie por altura: ARK10, ARK18, etc.)
    const colorHex = (typeof p.color === "string" && p.color.startsWith("#"))
      ? parseInt(p.color.slice(1), 16)
      : (p.color || 0x0070c0);

    // Grupo para representar mejor la forma del plot (cuerpo + "pico")
    const plotGroup = new THREE.Group();

    const cuerpoAltura = Math.max(altura * 0.85, 0.02);
    const discoAltura = 0.008;

    // Cuerpo cilíndrico (base más ancha) — mismo color que en 2D
    const cuerpoGeom = new THREE.CylinderGeometry(baseRadius * 0.85, baseRadius * 0.95, cuerpoAltura, 24);
    const cuerpoMat = new THREE.MeshPhongMaterial({
      color: colorHex,
      specular: 0x444444,
      shininess: 40,
      emissive: colorHex,
      emissiveIntensity: 0.12,
    });
    const cuerpo = new THREE.Mesh(cuerpoGeom, cuerpoMat);
    cuerpo.position.y = cuerpoAltura / 2;
    plotGroup.add(cuerpo);

    // Placa superior (mismo color que en 2D, un poco más clara)
    const discoGeom = new THREE.CylinderGeometry(baseRadius * 0.95, baseRadius * 0.95, discoAltura, 32);
    const discoMat = new THREE.MeshPhongMaterial({
      color: colorHex,
      specular: 0x6688aa,
      shininess: 55,
      emissive: colorHex,
      emissiveIntensity: 0.25,
    });
    const disco = new THREE.Mesh(discoGeom, discoMat);
    disco.position.y = cuerpoAltura + discoAltura / 2;
    plotGroup.add(disco);

    const totalAltura = cuerpoAltura + discoAltura;
    const wx = p.x * SCALE;
    const wy = altura / 2;
    const wz = p.y * SCALE;
    plotGroup.position.set(wx, wy - totalAltura / 2, wz);
    scene.add(plotGroup);
  });

  if (center && center.length) {
    center.forEach((c) => {
      const zCentro = c.z ?? 0;
      const diskHeight = 0.02;
      const sumideroRadius = baseRadius * 1.35;

      // Disco principal del sumidero: más grande y muy visible (naranja/amarillo)
      const g = new THREE.CylinderGeometry(sumideroRadius, sumideroRadius, diskHeight, 32);
      const m = new THREE.MeshPhongMaterial({
        color: 0xffa500,
        emissive: 0xff8c00,
        emissiveIntensity: 0.7,
        specular: 0xffffff,
        shininess: 80,
      });
      const s = new THREE.Mesh(g, m);
      const y = zCentro * HEIGHT_SCALE + diskHeight / 2;
      s.position.set(c.x * SCALE, y, c.y * SCALE);
      scene.add(s);

      // Aro blanco alrededor para que destaque sobre los plots
      const ringRadius = sumideroRadius + 0.008;
      const ringGeom = new THREE.RingGeometry(sumideroRadius, ringRadius, 32);
      const ringMat = new THREE.MeshBasicMaterial({
        color: 0xffffff,
        side: THREE.DoubleSide,
      });
      const ring = new THREE.Mesh(ringGeom, ringMat);
      ring.rotation.x = -Math.PI / 2;
      ring.position.set(c.x * SCALE, y + diskHeight / 2 + 0.001, c.y * SCALE);
      scene.add(ring);
    });
  }

  const target = new THREE.Vector3(
    (minX + maxX) / 2,
    0,
    (minY + maxY) / 2
  );
  // Acercamos un poco la cámara para que el modelo se vea más grande
  let radius = Math.max(width, depth) * 1.2;
  let azimuth = Math.PI / 4;  // giro horizontal
  let polar = Math.PI / 3;    // inclinación vertical

  function updateCamera() {
    const sinPolar = Math.sin(polar);
    camera.position.set(
      target.x + radius * sinPolar * Math.cos(azimuth),
      target.y + radius * Math.cos(polar),
      target.z + radius * sinPolar * Math.sin(azimuth)
    );
    camera.lookAt(target);
  }
  updateCamera();

  // Controles sencillos de ratón: arrastrar para orbitar, rueda para zoom
  const dom = renderer.domElement;
  let dragging = false;
  let lastX = 0;
  let lastY = 0;

  dom.addEventListener("mousedown", (e) => {
    dragging = true;
    lastX = e.clientX;
    lastY = e.clientY;
  });
  window.addEventListener("mouseup", () => {
    dragging = false;
  });
  window.addEventListener("mousemove", (e) => {
    if (!dragging) return;
    const dx = e.clientX - lastX;
    const dy = e.clientY - lastY;
    lastX = e.clientX;
    lastY = e.clientY;
    azimuth -= dx * 0.005;
    polar -= dy * 0.005;
    const eps = 0.1;
    const maxPolar = Math.PI - eps;
    if (polar < eps) polar = eps;
    if (polar > maxPolar) polar = maxPolar;
    updateCamera();
  });

  dom.addEventListener(
    "wheel",
    (e) => {
      e.preventDefault();
      const zoomFactor = 1 + (e.deltaY > 0 ? 0.1 : -0.1);
      radius *= zoomFactor;
      const minR = Math.max(width, depth) * 0.3;
      const maxR = Math.max(width, depth) * 5;
      if (radius < minR) radius = minR;
      if (radius > maxR) radius = maxR;
      updateCamera();
    },
    { passive: false }
  );

  // Atajos de teclado para vistas predefinidas
  window.addEventListener("keydown", (e) => {
    if (e.key === "1") {
      // Vista superior
      polar = Math.PI / 2.05;
      azimuth = 0;
      radius = Math.max(width, depth) * 1.1;
      updateCamera();
    } else if (e.key === "2") {
      // Vista isométrica
      polar = Math.PI / 3;
      azimuth = Math.PI / 4;
      radius = Math.max(width, depth) * 1.2;
      updateCamera();
    }
  });

  window.addEventListener("resize", () => {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
    updateCamera();
  });

  function animate() {
    requestAnimationFrame(animate);
    renderer.render(scene, camera);
  }
  animate();
})();

